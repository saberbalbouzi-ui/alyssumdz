/* الصفحة الرئيسية للوحة (Dashboard): ترحيب + فترة (اليوم/7/30) + 4 بطاقات + مخطط المبيعات والطلبات + حلقة الحالات
   + «يحتاج انتباهك» + آخر الطلبات + أفضل المنتجات. تُحسب كلها محلياً من Admin.orders/products (لا طلبات شبكة جديدة)، فتعمل
   على كل الأنظمة (GitHub/Supabase/PHP/محلي). مخططات SVG بلا مكتبات؛ ألوان الحلقة مُتحقَّق منها بـ validate_palette (dark) وتحمل وسيلة إيضاح بالأرقام. */
const AdminHome = (() => {
  const $ = id => document.getElementById(id);
  const A = () => (typeof Admin !== "undefined" ? Admin : {});
  const S = { days: 7, from: "", to: "", metric: "sales", table: false, shown: false };
  const MINT = "#e2fe17", INK = "#ffffff", MUT = "rgba(255,255,255,.72)", GRID = "rgba(255,255,255,.1)";
  /* ترتيب ثابت للألوان الفئوية (dark): أزرق، برتقالي، تركوازي، أصفر، وردي — يتبع تدفّق الحالة */
  const ST = [
    { k: "nouvelle", g: 0, t: "في انتظار التأكيد", c: "#3987e5" },
    { k: "confirmee", g: 1, t: "قيد التجهيز", c: "#d95926" },
    { k: "expediee", g: 2, t: "في الطريق", c: "#199e70" },
    { k: "livree", g: 3, t: "تم التسليم", c: "#c98500" },
    { k: "annulee", g: 4, t: "ملغاة / فشل", c: "#d55181" }, { k: "echec", g: 4 },
  ];
  const GROUPS = [0, 1, 2, 3, 4].map(g => ST.find(s => s.g === g && s.t));
  const num = n => Number(n || 0).toLocaleString("fr-DZ");
  const money = n => num(Math.round(n)) + " دج";
  const day0 = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };
  const DAY = 864e5;
  const css = () => {
    if ($("ahome-css")) return;
    const st = document.createElement("style"); st.id = "ahome-css";
    st.textContent = `body.ah-on #stats{display:none!important}#ahome{display:grid;gap:16px}#ahome *{box-sizing:border-box}
#ahome .ah-hd{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}#ahome .ah-hd h2{margin:0;font-size:1.5rem;color:#fff}#ahome .ah-hd p{margin:.2rem 0 0;color:${MUT};font-size:.92rem}
#ahome .ah-act{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
#ahome .ah-seg{display:inline-flex;padding:3px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14)}#ahome .ah-seg button{border:0;background:transparent;color:${MUT};padding:7px 14px;border-radius:999px;font:inherit;font-size:.85rem;font-weight:800;cursor:pointer;transition:background .2s,color .2s}#ahome .ah-seg button.on{background:rgba(226,254,23,.2);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.2)}
#ahome .ah-btn{padding:9px 16px;border-radius:12px;font:inherit;font-weight:800;color:#fff;cursor:pointer;background:rgba(226,254,23,.2);border:1px solid rgba(226,254,23,.45);box-shadow:inset 0 1px 0 rgba(255,255,255,.2),inset 0 -6px 10px rgba(0,0,0,.2),0 6px 16px rgba(0,0,0,.25);backdrop-filter:blur(8px);transition:transform .2s,background .2s}#ahome .ah-btn:hover{transform:translateY(-2px);background:rgba(226,254,23,.32)}#ahome .ah-btn.gh{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.22)}
#ahome .ah-pay{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:10px}#ahome .ah-pc{padding:12px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);display:flex;flex-direction:column;gap:3px}#ahome .ah-pc strong{font-size:1.15rem;color:var(--g-mint,#e2fe17)}#ahome .ah-pc span{font-size:.8rem;opacity:.75}#ahome .ah-pc span.w{color:#fde047;opacity:1}#ahome .ah-pc span.r{color:#fdba74;opacity:1}#ahome .ah-ads{display:flex;flex-direction:column;gap:8px}#ahome .ah-ad{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05)}#ahome .ah-ad.off{opacity:.65}#ahome .ah-adt{flex:1;min-width:0;display:flex;flex-direction:column}#ahome .ah-adt b{font-size:1.05rem}#ahome .ah-adt span{font-size:.85rem;opacity:.7}#ahome .ah-adp{font-weight:800;font-size:.9rem;padding:3px 10px;border-radius:999px;background:rgba(226,254,23,.2);white-space:nowrap}#ahome .ah-ad.off .ah-adp{background:rgba(255,255,255,.12)}#ahome .ah-ad .ah-btn{flex:none;min-width:84px}#ahome .ah-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}#ahome .ah-quick{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 14px}#ahome .ah-quick .ah-btn,#ahome .ah-rqb .ah-btn{flex:0 1 auto;text-align:center;font-size:.88rem!important;padding:6px 12px!important;min-height:36px!important;height:auto!important;line-height:1.3!important;border-radius:11px!important}#ahome .ah-rqs{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin:0 0 12px}#ahome .ah-rqs>div{padding:8px 10px!important;min-height:0!important;height:auto!important;line-height:1.35;border-radius:14px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12)}#ahome .ah-rqs b{display:block;font-size:1.3rem;font-weight:900;color:#fff;line-height:1.3}#ahome .ah-rqs span{font-size:.82rem;color:${MUT}}#ahome .ah-rqb{display:flex;flex-wrap:wrap;gap:8px}
#ahome .ah-card{padding:16px;border-radius:20px;background:linear-gradient(145deg,rgba(255,255,255,.07),rgba(255,255,255,.02));border:1px solid rgba(255,255,255,.14);box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 14px 34px rgba(0,0,0,.35);color:#fff;min-width:0}
#ahome .ah-card h3{margin:0 0 10px;font-size:1rem;color:#fff;display:flex;justify-content:space-between;align-items:center;gap:8px}#ahome .ah-card h3 small{font-weight:600;color:${MUT};font-size:.78rem}
#ahome .kpi{position:relative;overflow:hidden}#ahome .kpi .lb{display:flex;align-items:center;gap:8px;color:${MUT};font-size:.88rem}#ahome .kpi .ic{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16)}#ahome .kpi .ic svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
#ahome .kpi .v{font-size:1.65rem;font-weight:900;margin:8px 0 2px;letter-spacing:-.01em;color:#fff}#ahome .kpi .d{font-size:.8rem;font-weight:800;display:inline-flex;gap:4px;align-items:center}#ahome .kpi .d.up{color:#e2fe17}#ahome .kpi .d.dn{color:#ff9aa2}#ahome .kpi .d.eq{color:${MUT}}#ahome .kpi .d span{font-weight:600;color:${MUT}}
#ahome .kpi svg.sp{display:block;width:100%;height:34px;margin-top:8px}
#ahome .ah-row{display:grid;grid-template-columns:1.7fr 1fr;gap:14px}#ahome .ah-row2{display:grid;grid-template-columns:1.5fr 1fr;gap:14px}
#ahome .ch{position:relative}#ahome .ch svg{display:block;width:100%;height:auto;overflow:visible}#ahome .ch text{fill:${MUT};font-size:11px;font-family:inherit}
#ahome .tip{position:absolute;pointer-events:none;z-index:4;min-width:130px;padding:8px 10px;border-radius:12px;background:rgba(9,24,18,.985);border:1px solid rgba(255,255,255,.2);box-shadow:0 10px 26px rgba(0,0,0,.5);font-size:.8rem;opacity:0;transition:opacity .12s}#ahome .tip.on{opacity:1}#ahome .tip b{display:block;color:#fff;font-size:1rem}#ahome .tip span{color:${MUT}}#ahome .tip i{display:inline-block;width:14px;height:3px;border-radius:2px;background:${MINT};margin-inline-end:6px;vertical-align:middle}
#ahome .dn-w{display:flex;gap:16px;align-items:center;flex-wrap:wrap;justify-content:center}#ahome .dn-w svg{width:170px;height:170px;flex:none}#ahome .lg{display:grid;gap:7px;flex:1;min-width:150px}#ahome .lg div{display:flex;align-items:center;gap:8px;font-size:.88rem;color:#fff}#ahome .lg i{width:12px;height:12px;border-radius:3px;flex:none}#ahome .lg b{margin-inline-start:auto;color:#fff}#ahome .lg span{color:${MUT}}
#ahome table{width:100%;border-collapse:collapse;font-size:.88rem}#ahome th{text-align:start;color:${MUT};font-weight:700;padding:8px 6px;border-bottom:1px solid rgba(255,255,255,.12)}#ahome td{padding:9px 6px;border-bottom:1px solid rgba(255,255,255,.07);color:#fff;white-space:nowrap;max-width:190px;overflow:hidden;text-overflow:ellipsis}#ahome tr.cl{cursor:pointer}#ahome tr.cl:hover td{background:rgba(255,255,255,.05)}
#ahome .bd{display:inline-block;padding:3px 10px;border-radius:999px;font-size:.76rem;font-weight:800;color:#fff;border:1px solid}
#ahome .tp{display:grid;gap:10px}#ahome .tp .r{display:grid;grid-template-columns:22px 1fr auto;gap:4px 10px;align-items:center}#ahome .tp .n{width:22px;height:22px;border-radius:7px;display:grid;place-items:center;font-size:.75rem;font-weight:900;background:rgba(255,255,255,.1);color:#fff}#ahome .tp .t{color:#fff;font-size:.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#ahome .tp .q{color:${MUT};font-size:.8rem}#ahome .tp .bar{grid-column:2/4;height:6px;border-radius:6px;background:rgba(255,255,255,.08);overflow:hidden}#ahome .tp .bar i{display:block;height:100%;border-radius:6px;background:${MINT}}
#ahome .at{display:grid;gap:8px}#ahome .at button{display:flex;align-items:center;gap:10px;text-align:start;padding:11px 13px;border-radius:14px;font:inherit;color:#fff;cursor:pointer;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.14);transition:transform .2s,background .2s}#ahome .at button:hover{transform:translateY(-2px);background:rgba(255,255,255,.1)}#ahome .at b{font-size:1.15rem;min-width:30px}#ahome .at span{color:${MUT};font-size:.86rem}#ahome .at .w{border-color:rgba(251,146,60,.5)}#ahome .at .w b{color:#fdba74}#ahome .at .ok b{color:#e2fe17}
#ahome .em{padding:24px;text-align:center;color:${MUT}}
#ahome .ah-lnk{all:unset;display:inline;border:0!important;box-shadow:none!important;background:none!important;padding:0!important;min-height:0!important;cursor:pointer;color:#ffd45e;font-weight:800;text-decoration:underline;text-underline-offset:3px}#ahome .ah-lnk:hover{opacity:.85}#ahome .ah-lnk:focus-visible{outline:2px solid currentColor;outline-offset:2px;border-radius:4px}
#ahome .ah-dr{display:inline-flex;align-items:center;gap:6px}#ahome .ah-dr input{font:inherit;padding:7px 9px;border-radius:10px;color:#fff;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color-scheme:dark}
#ahome .rt-bar{display:flex;height:12px;border-radius:999px;overflow:hidden;background:rgba(255,255,255,.08);gap:2px;margin:6px 0 14px}#ahome .rt-bar i{display:block;min-width:4px}
#ahome .rt-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}#ahome .rt-c{display:grid;gap:3px}#ahome .rt-c span{color:${MUT};font-size:.86rem;display:flex;align-items:center;gap:6px}#ahome .rt-c u{width:9px;height:9px;border-radius:3px;display:inline-block}#ahome .rt-c b{font-size:1.6rem;font-weight:900;color:#fff}#ahome .rt-c small{color:${MUT};font-size:.76rem}
#ahome .rt-m{height:6px;border-radius:999px;background:rgba(255,255,255,.1);overflow:hidden}#ahome .rt-m i{display:block;height:100%;border-radius:999px}#ahome .rt-n{margin:8px 0 0;color:${MUT};font-size:.78rem}
#ahome .pf-v{font-size:2rem;font-weight:900;margin:4px 0}
@media(max-width:1100px){#ahome .ah-kpis{grid-template-columns:repeat(2,1fr)}#ahome .ah-row,#ahome .ah-row2{grid-template-columns:1fr}}
@media(max-width:520px){#ahome .ah-kpis{grid-template-columns:1fr 1fr;gap:10px}#ahome .kpi .v{font-size:1.25rem}#ahome .ah-card{padding:12px}}
#ahome .ah-quick{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}#ahome .ah-quick .ah-btn,#ahome .ah-rqb .ah-btn{min-height:44px;display:inline-flex;align-items:center;justify-content:center;text-align:center;line-height:1.25}
@media(max-width:700px){
#ahome .ah-hd{flex-direction:column;align-items:stretch;gap:10px}
#ahome .ah-act{display:grid;grid-template-columns:1fr 1fr;gap:8px;width:100%}
#ahome .ah-act .ah-seg{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,1fr);gap:3px}#ahome .ah-act .ah-seg button{padding:9px 6px;text-align:center}
#ahome .ah-act>.ah-btn{width:100%;display:inline-flex;align-items:center;justify-content:center;min-height:46px}
#ahome .ah-quick{display:grid;grid-template-columns:1fr 1fr;gap:8px}#ahome .ah-quick+.ah-quick{margin-top:-2px}#ahome .ah-quick .ah-btn{width:100%;padding:8px 10px;font-size:.9rem}
#ahome .ah-rqb{display:grid;grid-template-columns:1fr 1fr;gap:8px}#ahome .ah-rqb .ah-btn{width:100%;padding:8px 10px;font-size:.9rem}
}
`;
    document.head.appendChild(st);
  };
  const ICONS = {
    sales: '<path d="M3 17l6-6 4 4 7-8"/><path d="M14 7h6v6"/>', orders: '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
    wait: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', avg: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  };
  const stOf = s => (GROUPS.find(g => g.k === s) || (s === "echec" ? GROUPS[4] : GROUPS[0]));
  /* الحالة الحقيقية عند الشركة: حالة الطرد من قائمة الشركة ثم آخر حالة خام مزامَنة، وإلا حالة الطلب المحلية (والجديد/المؤكَّد غير المرسَل بوسم صريح) */
  function realSt(o) {
    const a = A(), g = stOf(o.status); let t = null; try { t = a.trackingOf && a.trackingOf(o); } catch (e) { }
    if (!t) return o.status === "nouvelle" || !o.status ? { t: "🆕 جديد — في انتظار التأكيد", c: g.c } : o.status === "confirmee" ? { t: "مؤكَّد — لم يُرسل للشركة", c: g.c } : { t: g.t, c: g.c };
    let raw = "", gone = false; try {
      const Y = typeof AdminYd !== "undefined" ? AdminYd : null, rows = (Y && Y.S.rows) || [], r = rows.find(x => String(x.tracking) === String(t.tracking)); raw = (r && r.status) || "";
      /* طرد مسجَّل محلياً لكنه غير موجود في قائمة الشركة (حُذف هناك) ⟵ لا نعرض حالة قديمة محفوظة */
      if (!r && rows.length && (!t.company || t.company === "yalidine") && ["confirmee", "nouvelle", "expediee"].includes(o.status)) {
        const tm = d => { const x = new Date(String(d || "").replace(" ", "T")).getTime(); return isFinite(x) ? x : 0; }, oldest = Math.min.apply(null, rows.map(x => tm(x.date)).filter(Boolean).concat([Infinity]));
        if (tm(o.date) >= oldest) gone = true;
      }
    } catch (e) { }
    if (gone) return { t: "⚠️ الطرد غير موجود عند الشركة (حُذف)", c: "#f87171" };
    if (!raw) { try { raw = ((a.shipRaw || {})[o.id] || {}).raw || ""; } catch (e) { } }
    try { if (a.coStale && a.coStale(o)) return { t: "⚠️ لا حالة من الشركة بعد", c: "#e08a1a" }; } catch (e) { }
    return { t: raw || (g.t + " (بانتظار الشركة)"), c: g.c };
  }
  let _soft = 0; function refreshSoft() { clearTimeout(_soft); _soft = setTimeout(() => { const r = $("ahome"); if (r && r.offsetParent !== null) { try { render(); } catch (e) { } } }, 600); }
  function orders() { return (A().orders || []).filter(o => o && o.date && !isNaN(new Date(o.date))); }
  const okOrder = o => !["annulee", "echec"].includes(o.status);
  function range(days, back) { /* [from, to) بمنتصف الليل المحلي */
    const end = day0(Date.now()) + DAY - back * days * DAY, start = end - days * DAY; return [start, end];
  }
  function bucket(list, from, to, step, key) {
    const n = Math.round((to - from) / step), v = Array(n).fill(0);
    list.forEach(o => { const t = new Date(o.date).getTime(); if (t >= from && t < to) { const i = Math.min(n - 1, Math.floor((t - from) / step)); v[i] += key(o); } });
    return v;
  }
  const sum = a => a.reduce((s, x) => s + x, 0);
  function delta(cur, prev) {
    if (!prev && !cur) return { c: "eq", t: "—", p: "" };
    if (!prev) return { c: "up", t: "جديد", p: "" };
    const p = Math.round((cur - prev) / prev * 100);
    return { c: p > 0 ? "up" : p < 0 ? "dn" : "eq", t: (p > 0 ? "▲ " : p < 0 ? "▼ " : "") + Math.abs(p) + "%", p: "" };
  }
  function spark(vals, color) {
    const W = 120, H = 34, m = Math.max(1, ...vals), n = vals.length;
    if (n < 2) return "";
    const pts = vals.map((v, i) => [i * W / (n - 1), H - 3 - (v / m) * (H - 8)]);
    const d = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
    return `<svg class="sp" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><path d="${d} L${W} ${H} L0 ${H}Z" fill="${color}" opacity=".14"/><path d="${d}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
  }
  function kpi(ic, label, value, dl, vals, color) {
    return `<div class="ah-card kpi"><div class="lb"><span class="ic" style="color:${color}"><svg viewBox="0 0 24 24">${ICONS[ic]}</svg></span>${label}</div><div class="v">${value}</div>${dl ? `<div class="d ${dl.c}">${dl.t} <span>عن الفترة السابقة</span></div>` : '<div class="d eq">&nbsp;</div>'}${spark(vals, color)}</div>`;
  }
  const dateLabel = (t, hourly) => { const d = new Date(t); return hourly ? d.getHours() + ":00" : d.toLocaleDateString("ar-DZ", { day: "numeric", month: "short" }); };

  function chartSvg(vals, labels, fmt) {
    const W = 720, H = 250, L = 8, R = 8, T = 14, B = 26, n = vals.length, m = Math.max(1, ...vals);
    const nice = (() => { const e = Math.pow(10, Math.floor(Math.log10(m))), f = m / e; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * e; })();
    const x = i => L + (n === 1 ? (W - L - R) / 2 : i * (W - L - R) / (n - 1)), y = v => T + (H - T - B) * (1 - v / nice);
    const line = vals.map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1)).join(" ");
    let g = ""; for (let k = 0; k <= 4; k++) { const v = nice * k / 4, yy = y(v); g += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" stroke="${GRID}" stroke-width="1"/>`; if (k) g += `<text x="${W - R}" y="${yy - 4}" text-anchor="end">${fmt(v)}</text>`; }
    const every = Math.ceil(n / 7); let xl = ""; labels.forEach((t, i) => { if (i % every === 0 || i === n - 1) xl += `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="${i === 0 ? "start" : i === n - 1 ? "end" : "middle"}">${t}</text>`; });
    const dots = n <= 31 ? vals.map((v, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="${n > 14 ? 2.5 : 3.5}" fill="${MINT}" stroke="#0a1f15" stroke-width="2"/>`).join("") : "";
    return { svg: `<svg style="direction:ltr" viewBox="0 0 ${W} ${H}" role="img" aria-label="مخطط ${S.metric === "sales" ? "المبيعات" : "الطلبات"}"><defs><linearGradient id="ah-g" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${MINT}" stop-opacity=".32"/><stop offset="1" stop-color="${MINT}" stop-opacity="0"/></linearGradient></defs>${g}<path d="${line} L${x(n - 1)} ${y(0)} L${x(0)} ${y(0)}Z" fill="url(#ah-g)"/><path d="${line}" fill="none" stroke="${MINT}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>${dots}${xl}<line id="ah-cx" y1="${T}" y2="${H - B}" stroke="rgba(255,255,255,.5)" stroke-width="1" stroke-dasharray="3 3" opacity="0"/></svg>`, x, y, W, n };
  }
  function donut(counts) {
    const total = sum(counts), R = 66, r = 44, C = 85;
    if (!total) return `<svg viewBox="0 0 170 170" aria-hidden="true"><circle cx="${C}" cy="${C}" r="${(R + r) / 2}" fill="none" stroke="rgba(255,255,255,.1)" stroke-width="${R - r}"/></svg>`;
    let a0 = -Math.PI / 2, out = "";
    counts.forEach((c, i) => {
      if (!c) return; const a1 = a0 + c / total * 2 * Math.PI, gap = Math.min(.04, (a1 - a0) / 3), s = a0 + gap, e = a1 - gap, large = e - s > Math.PI ? 1 : 0;
      const P = (rad, a) => (C + rad * Math.cos(a)).toFixed(2) + " " + (C + rad * Math.sin(a)).toFixed(2);
      out += `<path d="M${P(R, s)} A${R} ${R} 0 ${large} 1 ${P(R, e)} L${P(r, e)} A${r} ${r} 0 ${large} 0 ${P(r, s)}Z" fill="${GROUPS[i].c}"><title>${GROUPS[i].t}: ${c}</title></path>`; a0 = a1;
    });
    return `<svg viewBox="0 0 170 170" role="img" aria-label="توزيع الطلبات حسب الحالة">${out}<text x="${C}" y="${C - 2}" text-anchor="middle" style="fill:#fff;font-size:24px;font-weight:900">${num(total)}</text><text x="${C}" y="${C + 16}" text-anchor="middle" style="fill:${MUT};font-size:11px">طلب</text></svg>`;
  }
  const hasTab = k => [...document.querySelectorAll(".nav-btn")].some(b => (b.getAttribute("onclick") || "").includes("'" + k + "'")), hasRuqya = () => typeof AdminRuqya !== "undefined" && hasTab("ruqya");   /* مواعيد الرقية خاصة بموقع البائع فقط */
  /* وصول سريع إلى ما يُستعمل كل يوم (يُخفى ما ليس له قسم في هذه النسخة/الصلاحية) */
  function quickBar(waiting) {
    let toPack = 0; try { if (typeof AdminPack !== "undefined" && AdminPack.count && hasTab("pack")) { toPack = S.packN || 0; AdminPack.count().then(n => { if (n !== null && n !== S.packN) { S.packN = n; refreshSoft(); } }); } } catch (e) { }   /* العدد من قائمة التجهيز نفسها (دالة الخادم) لا من حالة الطلبات */
    /* ترتيب الاختصارات (طلب صاحب المتجر): الطلبات معاً ثم المنتج والعملاء (الأرباح والمسجلة والرقية تُفتح من القائمة/البطاقة)؛ كل مجموعة في صفها وما لا قسم له في هذه النسخة يُخفى */
    let nPre = 0; try { nPre = typeof AdminPreSend !== "undefined" ? AdminPreSend.pending().length : 0; } catch (e) { }
    const G = [
      [["neword", "+ طلب", hasTab("orders"), 1], ["orders", "كل الطلبات", hasTab("orders"), 0], ["orders-new", "الطلبات الجديدة" + (waiting ? " (" + num(waiting) + ")" : ""), 1, 0], ["pack", "تجهيز الطلبات" + (toPack ? " (" + num(toPack) + ")" : ""), hasTab("pack"), 0], ["presend", "قبل الإرسال" + (nPre ? " (" + num(nPre) + ")" : ""), hasTab("orders") && typeof AdminPreSend !== "undefined", 0], ["sent", "المرسَلة اليوم", hasTab("shipped") && typeof AdminSent !== "undefined", 0]],
      [["newp", "+ منتج", 1, 1], ["customers", "العملاء", hasTab("customers"), 0]]
    ];      /* أزرار الرقية حُذفت من الاختصارات (طلب صاحب المتجر): تبقى في بطاقة «مواعيد الرقية» أسفلها */
    return G.map(g => g.filter(q => q[2])).filter(g => g.length).map(g => '<div class="ah-quick">' + g.map(q => '<button type="button" class="ah-btn' + (q[3] ? "" : " gh") + '" data-go="' + q[0] + '">' + q[1] + '</button>').join("") + '</div>').join("");
  }
  function ruqyaCard() {
    if (!hasRuqya()) return "";
    const r = AdminRuqya.summary();
    if (!r.loaded) { AdminRuqya.warm(refreshSoft); return '<div class="ah-card" style="margin:0 0 14px"><h3>مواعيد الرقية <small>جارٍ التحميل…</small></h3></div>'; }
    if (r.err) return "";
    const nd = r.nextDay ? new Date(r.nextDay + "T12:00:00").toLocaleDateString("ar-DZ", { weekday: "long", day: "numeric", month: "long" }) : "لا مواعيد قادمة";
    return '<div class="ah-card" style="margin:0 0 14px"><h3>مواعيد الرقية <small>' + nd + '</small></h3><div class="ah-rqs">' +
      '<div><b>' + num(r.pending) + '</b><span>بانتظار التأكيد</span></div><div><b>' + num(r.today) + '</b><span>مواعيد اليوم</span></div>' +
      '<div><b>' + num(r.am) + '/' + r.cap + '</b><span>جلسات صباحاً</span></div><div><b>' + num(r.pm) + '/' + r.cap + '</b><span>جلسات مساءً</span></div></div>' +
      '<div class="ah-rqb"><button type="button" class="ah-btn" data-go="ruqya-new">حجز موعد يدوي</button><button type="button" class="ah-btn gh" data-go="ruqya-pending">بانتظار التأكيد</button>' + (r.uv ? '<button type="button" class="ah-btn" data-go="ruqya-uv">واتساب غير مؤكَّد (' + num(r.uv) + ')</button>' : '') + '<button type="button" class="ah-btn gh" data-go="ruqya">كل المواعيد</button></div></div>';
  }
  /* صافي كل شركة توصيل (ما يخصّك بعد العمولة والتوصيل والإرجاع) كما في «تفاصيل الدفع» */
  function payCard() {
    if (typeof AdminPayments === "undefined" || !hasTab("payments")) return "";
    const P = AdminPayments;
    if (!P.S.loaded) { if (!P.S.loading) { try { P.load().then(refreshSoft).catch(() => { }); } catch (e) { } } return '<div class="ah-card" style="margin:0 0 14px"><h3>صافي الشركات <small>جارٍ التحميل…</small></h3></div>'; }
    let L; try { L = P.coNets(); } catch (e) { return ""; }
    try { const en = A().enabledCompanyKeys ? A().enabledCompanyKeys() : null; if (Array.isArray(en)) { L = L.filter(g => en.indexOf(g.k) >= 0); en.forEach(k => { if (!L.some(g => g.k === k)) L.push({ k, net: 0, got: 0, nDone: 0, nRet: 0, nExp: 0, netExp: 0 }); }); } } catch (e) { }      /* كل الشركات المفعّلة تظهر؛ التي لا مستحقات لها تُكتب «لا مستحقات» فلا يُظنّ أنها حُذفت */
    if (!L.length) return "";
    const nm = k => (typeof AdminCoStats !== "undefined" ? AdminCoStats.nameOf(k) : k), esc = x => String(x == null ? "" : x).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    const tot = L.reduce((t, g) => t + g.net, 0);
    return '<div class="ah-card" style="margin:0 0 14px"><h3>صافي الشركات <small>المجموع ' + money(tot) + '</small></h3><div class="ah-pay">' + L.map(g => '<div class="ah-pc" data-noco><b>' + esc(nm(g.k)) + '</b>' + (!g.net && !g.got && !g.nExp ? '<strong style="opacity:.6;font-size:1rem">لا مستحقات</strong></div>' : '<strong' + (g.net < 0 ? ' style="color:#fca5a5"' : "") + '>' + money(g.net) + '</strong><span>الصافي · ' + num(g.nDone) + ' مسلَّم' + (g.nRet ? ' · ' + num(g.nRet) + ' مرتجع' : "") + '</span><span>لم يُستلم بعد (عند الشركة) ' + money(g.got) + '</span>' + (g.nExp ? '<span class="w">في الطريق ' + num(g.nExp) + ' · ' + money(g.gotExp) + ' · الصافي المتوقع ' + money(g.netExp) + '</span>' : "") + '</div>')).join("") + '</div><div class="ah-rqb"><button type="button" class="ah-btn gh" data-go="payments">تفاصيل الدفع</button></div></div>';
  }
  /* الحملات الإعلانية الحالية (حملة لكل منتج) مع تفعيل/تعطيل مباشر؛ المنتهية بتاريخ «إلى» لا تظهر */
  function adsCard() {
    const a = A(); if (!a || !a.fin || !a.fin.ads || typeof a.adAllCamps !== "function") return "";
    const today = a.isoDay ? a.isoDay() : new Date().toISOString().slice(0, 10), esc = x => String(x == null ? "" : x).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    let L; try { L = a.adAllCamps(); } catch (e) { return ""; }
    L = L.filter(c => c.cur && !(c.cfg.to && c.cfg.to < today) && (a.products || []).some(p => p.slug === c.slug));
    if (!L.length) return "";
    const on = L.filter(c => !c.cfg.off).length;
    return '<div class="ah-card" style="margin:0 0 14px"><h3>الحملات الإعلانية <small>' + num(on) + ' نشطة من ' + num(L.length) + '</small></h3><div class="ah-ads">' + L.map(c => {
      const p = (a.products || []).find(x => x.slug === c.slug), off = !!c.cfg.off;
      return '<div class="ah-ad' + (off ? " off" : "") + '"><div class="ah-adt"><b>' + esc(p ? p.title : c.slug) + '</b><span>' + esc(c.cfg.name || "") + (c.cfg.from ? ' · منذ ' + esc(c.cfg.from) : "") + '</span></div><span class="ah-adp">' + (off ? "معطّلة" : "نشطة") + '</span><button type="button" class="ah-btn' + (off ? "" : " gh") + '" data-adt="' + esc(c.key || c.slug) + '">' + (off ? "تفعيل" : "تعطيل") + '</button></div>';
    }).join("") + '</div></div>';
  }
  /* الفترة: 1 اليوم، 7، 30، -1 هذا الشهر، 0 مخصصة (من/إلى)؛ والفترة السابقة بالطول نفسه للمقارنة */
  function span() {
    let days = S.days, f1, t1;
    if (days === -1) { const d = new Date(); f1 = new Date(d.getFullYear(), d.getMonth(), 1).getTime(); t1 = day0(Date.now()) + DAY; days = Math.max(1, Math.round((t1 - f1) / DAY)); }
    else if (days === 0) {
      const x = new Date(S.from + "T00:00:00").getTime(), y = new Date(S.to + "T00:00:00").getTime();
      if (isFinite(x) && isFinite(y) && y >= x) { f1 = day0(x); t1 = day0(y) + DAY; days = Math.max(1, Math.min(366, Math.round((t1 - f1) / DAY))); if (days === 366) f1 = t1 - 366 * DAY; }
      else { S.days = 7; return span(); }
    } else { [f1, t1] = range(days, 0); }
    const L = t1 - f1; return { days, f1, t1, f0: f1 - L, t0: f1, hourly: days === 1 };
  }
  const perTxt = days => S.days === 1 ? "اليوم" : S.days === -1 ? "هذا الشهر" : S.days === 0 ? "من " + S.from + " إلى " + S.to : "آخر " + days + " يوماً";
  const iso = d => { const x = new Date(d); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); };
  const pct = (x, n) => n ? (Math.round(x / n * 1000) / 10).toLocaleString("fr-DZ") + "%" : "—";
  const isConf = o => ["confirmee", "expediee", "livree", "echec"].indexOf(o.status) >= 0;      /* «مؤكَّدة»: أُكِّدت أو أُرسلت أو سُلّمت أو فشلت/رجعت */
  const C_OK = "#199e70", C_RET = "#d55181", C_RUN = "#3987e5";
  /* بطاقة نسب التسليم والإرجاع: شريط مقسَّم + النسب من الطلبات المؤكَّدة في الفترة */
  function ratesCard(cur, perT) {
    const c = cur.filter(isConf), n = c.length, d = c.filter(o => o.status === "livree").length, r = c.filter(o => o.status === "echec").length, p = n - d - r;
    const seg = (v, col) => v ? `<i style="flex:${v};background:${col}"></i>` : "";
    const col = (lb, v, col, cls) => `<div class="rt-c"><span><u style="background:${col}"></u>${lb}</span><b>${num(v)}</b><div class="rt-m"><i style="width:${n ? Math.max(2, v / n * 100) : 0}%;background:${col}"></i></div><small>${pct(v, n)} من ${num(n)} مؤكَّدة</small></div>`;
    return `<div class="ah-card"><h3>نسب التسليم والإرجاع <small>${perT} · ${num(cur.length)} طلب أُنشئ</small></h3>${n ? `<div class="rt-bar">${seg(d, C_OK)}${seg(p, C_RUN)}${seg(r, C_RET)}</div><div class="rt-g">${col("تم التسليم", d, C_OK)}${col("مرتجعة / فشل", r, C_RET)}${col("قيد الطريق", p, C_RUN)}</div>` : '<div class="em">لا طلبات مؤكَّدة في هذه الفترة</div>'}</div>`;
  }
  /* نسبة التسليم لكل ولاية: أكثر 8 ولايات طلباً (كل التواريخ)، والنسبة من الطلبات المنتهية (سُلّمت أو رجعت)؛ الولاية الصفرية تظهر بالأحمر */
  function wilayaCard(all) {
    const a = A(), m = {};
    all.filter(isConf).forEach(o => { let nm = String(o.wilaya || "").trim(); try { const w = a.wCo && a.wCo(nm); if (w && w.name) nm = w.name; } catch (e) { } nm = nm || "—"; const g = m[nm] || (m[nm] = { n: 0, d: 0, r: 0 }); g.n++; if (o.status === "livree") g.d++; else if (o.status === "echec") g.r++; });
    const L = Object.keys(m).map(k => Object.assign({ k }, m[k])).sort((x, y) => y.n - x.n || x.k.localeCompare(y.k)).slice(0, 8);
    const rows = L.map(g => { const fin = g.d + g.r, rate = fin ? g.d / fin : null, c = rate == null ? "rgba(255,255,255,.3)" : rate === 0 ? "#e5484d" : rate < .5 ? "#e08a1a" : rate < .8 ? C_RUN : C_OK; return `<tr><td data-wl></td><td style="width:42%"><div class="rt-m"><i style="width:${rate == null ? 0 : Math.max(rate ? 3 : 0, rate * 100)}%;background:${c}"></i></div></td><td style="color:${c};font-weight:800;white-space:nowrap">${rate == null ? "—" : pct(g.d, fin)}</td><td style="text-align:end">${num(g.n)}</td></tr>`; }).join("");
    return `<div class="ah-card"><h3>نسبة التسليم حسب الولاية <small>أعلى 8 بالطلبات · كل التواريخ</small></h3>${L.length ? `<table><thead><tr><th>الولاية</th><th>المسلَّمة</th><th></th><th style="text-align:end">الطلبات</th></tr></thead><tbody>${rows}</tbody></table><p class="rt-n">النسبة من الطلبات المنتهية (سُلّمت أو رجعت)؛ «—» لا طلب منتهياً بعد.</p>` : '<div class="em">لا بيانات بعد</div>'}</div>`;
  }
  /* الربح الصافي المحقق للفترة (من حساب تبويب الأرباح نفسه): سعر الشراء + التوصيل + المرتجع + التغليف... */
  function profitCard(P, perT) {
    const a = A(); if (!hasTab("finance") || !a.computeFinance) return "";
    let K = null, K0 = null; try { K = a.computeFinance(0, { from: P.f1, to: P.t1 }).K; K0 = a.computeFinance(0, { from: P.f0, to: P.t0 }).K; } catch (e) { return ""; }
    if (!K) return "";
    const miss = (a.products || []).filter(p => p && p.active !== false && p.slug !== "test" && a.fin && a.fin.costs && a.fin.costs[p.slug] == null).length, d = delta(K.real, K0 ? K0.real : 0), margin = K.revenue ? Math.round(K.real / K.revenue * 100) : 0;
    return `<div class="ah-card"><h3>الربح الصافي المحقق <small>${perT}</small><button type="button" class="ah-btn gh" data-go="finance" style="padding:6px 11px;font-size:.78rem">التفاصيل</button></h3><div class="pf-v" style="color:${K.real >= 0 ? C_OK : "#e5484d"}">${money(K.real)}</div><div class="kpi"><span class="d ${d.c}">${d.t}</span> <small style="color:${MUT}">عن الفترة السابقة</small></div><div class="rt-g" style="margin-top:12px"><div class="rt-c"><span>ربح متوقع (قيد التوصيل)</span><b>${money(K.exp || 0)}</b></div><div class="rt-c"><span>الهامش على المبيعات</span><b>${margin}%</b></div></div>${miss ? `<p class="rt-n" style="color:#e08a1a">${num(miss)} منتج بلا سعر شراء: الربح المعروض غير دقيق، أدخل أسعار الشراء من تبويب الأرباح.</p>` : ""}</div>`;
  }
  function render() {
    const root = $("ahome"); if (!root) return;
    css(); const a = A(), all = orders(), P = span(), days = P.days, hourly = P.hourly, f1 = P.f1, t1 = P.t1, f0 = P.f0, t0 = P.t0, perT = perTxt(days);
    const cur = all.filter(o => { const t = new Date(o.date).getTime(); return t >= f1 && t < t1; }), prev = all.filter(o => { const t = new Date(o.date).getTime(); return t >= f0 && t < t0; });
    const step = hourly ? 36e5 : DAY, ok = cur.filter(okOrder), okp = prev.filter(okOrder);
    const sales = sum(ok.map(o => Number(o.total) || 0)), salesP = sum(okp.map(o => Number(o.total) || 0));
    const od = a.overdueList ? a.overdueList().length : 0;
    const waiting = all.filter(o => o.status === "nouvelle" || !o.status).length;
    try { localStorage.setItem("adm_snap", JSON.stringify({ t: Date.now(), name: (typeof SITE_CFG !== "undefined" && SITE_CFG.name) || "", per: days === 1 ? "اليوم" : days === 7 ? "7 أيام" : days + " يوماً", sales: money(sales), orders: num(cur.length), wait: num(waiting), pack: S.packN == null ? null : num(S.packN) })); } catch (e) { }   /* لقطة تُعرض فور فتح اللوحة التالي قبل اكتمال التحميل */
    const avg = ok.length ? sales / ok.length : 0, avgP = okp.length ? salesP / okp.length : 0;
    const sb = hourly ? bucket(all, day0(Date.now()) - 6 * DAY, t1, DAY, o => okOrder(o) ? Number(o.total) || 0 : 0) : bucket(all, f1, t1, step, o => okOrder(o) ? Number(o.total) || 0 : 0);
    const ob = hourly ? bucket(all, day0(Date.now()) - 6 * DAY, t1, DAY, () => 1) : bucket(all, f1, t1, step, () => 1);
    const series = S.metric === "sales" ? bucket(all, f1, t1, step, o => okOrder(o) ? Number(o.total) || 0 : 0) : bucket(all, f1, t1, step, () => 1);
    const labels = series.map((_, i) => dateLabel(f1 + i * step, hourly));
    const fmt = S.metric === "sales" ? v => v >= 1000 ? Math.round(v / 1000) + "ك" : Math.round(v) : v => Math.round(v);
    const ch = chartSvg(series, labels, fmt);
    const counts = GROUPS.map((g, i) => cur.filter(o => stOf(o.status).g === i).length);
    const last = all.slice().sort((p, q) => new Date(q.date) - new Date(p.date)).slice(0, 8), lastSt = last.map(realSt);
    const prodMap = {}; cur.filter(okOrder).forEach(o => (a.orderItemsCanon ? a.orderItemsCanon(o) : a.parseOrderItems ? a.parseOrderItems(o.items) : []).forEach(it => { prodMap[it.title] = (prodMap[it.title] || 0) + it.qty; }));
    const top = Object.entries(prodMap).sort((p, q) => q[1] - p[1]).slice(0, 5), topMax = top.length ? top[0][1] : 1;
    const prods = (a.products || []).filter(p => p.active !== false), low = prods.filter(p => p.stock !== undefined && p.stock !== null && p.stock !== "" && Number(p.stock) > 0 && Number(p.stock) <= 5), out = prods.filter(p => p.stock !== undefined && p.stock !== null && p.stock !== "" && Number(p.stock) <= 0);
    const fail = all.filter(o => o.status === "echec").length;
    const sOver = (typeof StockCheck !== "undefined") ? StockCheck.summary() : { orders: 0, products: [] };
    let dh = 0; try { dh = typeof AdminDelHealth !== "undefined" ? AdminDelHealth.attention() : 0; } catch (e) { }      /* شركات توصيل تحتاج انتباهاً (أسعار تغيّرت/فحص فشل/مكاتب غير محمَّلة) */
    let mg = []; try { mg = window.AdminUpsell && AdminUpsell.mergeable ? AdminUpsell.mergeable(a.orders || []) : []; } catch (e) { }
    let ag = null; try { if (typeof AdminAgency !== "undefined") { ag = AdminAgency.alerts(); AdminAgency.warm(); } } catch (e) { }
    let dg = null; try { if (typeof AdminDigital !== "undefined") { dg = AdminDigital.alerts(); AdminDigital.warm(); } } catch (e) { }
    let mk = null; try { if (typeof AdminMarketplace !== "undefined") { mk = AdminMarketplace.alerts(); AdminMarketplace.warm(); } } catch (e) { }
    let aic = null; try { if (typeof ImgGen !== "undefined" && ImgGen.credit) { const st = ImgGen.credit.state(); if (st !== "ok") aic = { st, p: ImgGen.credit.pct() }; } } catch (e) { }
    let adLow = []; try { adLow = a.adStockAlerts ? a.adStockAlerts(5) : []; } catch (e) { }
    let rr = []; try { rr = a.retReadyList ? a.retReadyList() : []; } catch (e) { }
    let orph = []; try { orph = (typeof AdminYd !== "undefined" && AdminYd.orphans) ? AdminYd.orphans() : []; } catch (e) { }
    let dgHint = 0; try { if (typeof AdminKind !== "undefined" && AdminKind.kind() === "physical" && typeof AdminStores !== "undefined" && AdminStores.kind() !== "digital") dgHint = (a.products || []).filter(p => p && p.digital && p.active !== false).length; } catch (e) { }
    const name = (typeof SITE_CFG !== "undefined" && SITE_CFG.name) || "متجرك";
    const hour = new Date().getHours(), greet = hour < 12 ? "صباح الخير" : hour < 18 ? "مرحباً" : "مساء الخير";
    root.innerHTML = `
<div class="ah-hd"><div><h2>${greet}، لوحة ${name.replace(/[<>&]/g, "")}</h2><p>${od ? `<button type="button" class="ah-lnk" data-go="callcenter"><b>${num(od)}</b> طلب ينتظر مكالمة منذ أكثر من يوم</button> · ` : ""}نظرة عامة على متجرك ومبيعاتك — تُحسب من طلباتك الحالية.</p></div>
<div class="ah-act"><div class="ah-seg" role="group" aria-label="الفترة">${[[1, "اليوم"], [7, "7 أيام"], [30, "30 يوماً"], [-1, "هذا الشهر"], [0, "مخصص"]].map(([d, t]) => `<button type="button" data-d="${d}" class="${S.days === d ? "on" : ""}">${t}</button>`).join("")}</div>${S.days === 0 ? `<span class="ah-dr"><input type="date" id="ah-from" value="${S.from}" max="${S.to || iso(Date.now())}" aria-label="من"><span>←</span><input type="date" id="ah-to" value="${S.to}" min="${S.from}" max="${iso(Date.now())}" aria-label="إلى"></span>` : ""}</div></div>
${quickBar(waiting)}
${ruqyaCard()}
${payCard()}
${adsCard()}
<div class="ah-kpis">
${kpi("sales", "المبيعات", money(sales), delta(sales, salesP), sb, MINT)}
${kpi("orders", "الطلبات", num(cur.length), delta(cur.length, prev.length), ob, "#3987e5")}
${kpi("wait", "في انتظار التأكيد", num(waiting), null, [], "#c98500")}
${kpi("avg", "متوسط قيمة الطلب", money(avg), delta(avg, avgP), [], "#d55181")}
</div>
${ratesCard(cur, perT)}
<div class="ah-row2">${wilayaCard(all)}${profitCard(P, perT) || ""}</div>
<div class="ah-row">
<div class="ah-card"><h3>${S.metric === "sales" ? "مخطط المبيعات" : "مخطط الطلبات"}<span class="ah-act"><span class="ah-seg" role="group"><button type="button" data-m="sales" class="${S.metric === "sales" ? "on" : ""}">المبيعات</button><button type="button" data-m="orders" class="${S.metric === "orders" ? "on" : ""}">الطلبات</button></span><button type="button" class="ah-btn gh" data-tb="1" style="padding:6px 11px;font-size:.78rem">${S.table ? "عرض المخطط" : "عرض كجدول"}</button></span></h3>
${S.table ? `<div style="max-height:260px;overflow:auto"><table><thead><tr><th>${hourly ? "الساعة" : "اليوم"}</th><th>${S.metric === "sales" ? "المبيعات" : "الطلبات"}</th></tr></thead><tbody>${series.map((v, i) => `<tr><td>${labels[i]}</td><td>${S.metric === "sales" ? money(v) : num(v)}</td></tr>`).join("")}</tbody></table></div>` : `<div class="ch" id="ah-ch">${cur.length || sum(series) ? ch.svg : '<div class="em">لا طلبات في هذه الفترة بعد.</div>'}<div class="tip" id="ah-tip"></div></div>`}</div>
<div class="ah-card"><h3>الطلبات حسب الحالة <small>${perT}</small></h3><div class="dn-w">${donut(counts)}<div class="lg">${GROUPS.map((g, i) => `<div><i style="background:${g.c}"></i>${g.t}<b>${num(counts[i])}</b></div>`).join("")}</div></div></div>
</div>
<div class="ah-row2">
<div class="ah-card"><h3>آخر الطلبات <button type="button" class="ah-btn gh" data-go="orders" style="padding:6px 11px;font-size:.78rem">عرض الكل</button></h3>${last.length ? `<div style="overflow:auto"><table><thead><tr><th>الزبون</th><th>الولاية</th><th>المبلغ</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>${last.map((o, i) => { const g = lastSt[i]; return `<tr class="cl" data-o="${i}"><td></td><td></td><td>${money(o.total)}</td><td><span class="bd" data-rs="${i}" style="background:${g.c}33;border-color:${g.c}"></span></td><td>${new Date(o.date).toLocaleDateString("ar-DZ", { day: "numeric", month: "short" })}</td></tr>`; }).join("")}</tbody></table></div>` : '<div class="em">لا توجد طلبات بعد. ستظهر هنا فور وصولها.</div>'}</div>
<div class="ah-card"><h3>يحتاج انتباهك</h3><div class="at">
<button type="button" class="${waiting ? "w" : "ok"}" data-go="orders-new"><b>${num(waiting)}</b><span>طلب في انتظار التأكيد</span></button>
<button type="button" class="${low.length ? "w" : "ok"}" data-go="products"><b>${num(low.length)}</b><span>منتج مخزونه منخفض (5 أو أقل)</span></button>
<button type="button" class="${out.length ? "w" : "ok"}" data-go="products"><b>${num(out.length)}</b><span>منتج نفد من المخزون</span></button>
<button type="button" class="${sOver.orders ? "w" : "ok"}" data-go="orders-new" title="${sOver.products.map(x => x.title + ": المطلوب " + x.demand + " والمتاح " + x.stock).join(" | ").replace(/"/g, "")}"><b>${num(sOver.orders)}</b><span>طلب جديد يفوق المخزون</span></button>
<button type="button" class="${adLow.length ? "w" : "ok"}" data-go="ads" title="${adLow.map(x => x.p.title + ": " + x.stock + " علبة تكفي ≈ " + x.left + " يوم").join(" | ").replace(/"/g, "")}"><b>${num(adLow.length)}</b><span>حملة نشطة مخزونها يكفي 5 أيام أو أقل</span></button>
<button type="button" class="${mg.length ? "w" : "ok"}" data-go="merge"><b>${num(mg.length)}</b><span>طلب مرتبط (عرض بعد الشراء) ينتظر الدمج</span></button>
${dh ? `<button type="button" class="w" data-go="delivery"><b>${num(dh)}</b><span>شركة توصيل تحتاج انتباهك (أسعار أو مكاتب)</span></button>` : ""}
${ag ? `<button type="button" class="${ag.ready ? "w" : "ok"}" data-go="agency"><b>${num(ag.ready)}</b><span>حساب إعلاني جاهز — استلم رابط الدعوة</span></button>
<button type="button" class="${ag.late ? "w" : "ok"}" data-go="agency"><b>${num(ag.late)}</b><span>طلب خدمة تسويق تأخر عن مهلة التسليم</span></button>` : ""}
${aic ? `<button type="button" class="w" data-go="aicredit"><b>${aic.st === "out" ? "نفد" : "قارب"}</b><span>${aic.st === "out" ? "رصيد Alyssum API نفد — تتوقف أدوات الذكاء حتى تجديده" : "رصيد Alyssum API على وشك النفاد" + (aic.p != null ? " (متبقٍ " + aic.p + "٪)" : "")}</span></button>` : ""}
${dgHint ? `<button type="button" class="w" data-go="kinddg"><b>${num(dgHint)}</b><span>منتج رقمي في متجر مادي — أنشئ متجراً رقمياً (بلا توصيل) لها</span></button>` : ""}
${dg ? `<button type="button" class="${dg.proofs ? "w" : "ok"}" data-go="digital"><b>${num(dg.proofs)}</b><span>إثبات دفع رقمي ينتظر موافقتك</span></button>
<button type="button" class="${dg.low + dg.out + dg.short ? "w" : "ok"}" data-go="digital" title="${(dg.lowSkus || []).join(" | ").replace(/"/g, "")}"><b>${num(dg.low + dg.out + dg.short)}</b><span>منتج رقمي مخزون مفاتيحه ${dg.out ? "نفد" : "منخفض"}${dg.short ? " (وطلبات تنتظر مفاتيح)" : ""}</span></button>` : ""}
${mk && (mk.to_ship || mk.rej) ? `<button type="button" class="w" data-go="market"><b>${num(mk.to_ship + mk.rej)}</b><span>${mk.to_ship ? "طلب التسويق بالعمولة ينتظر شحنك" : ""}${mk.to_ship && mk.rej ? " · " : ""}${mk.rej ? "طلب رُفض لنقص رصيدك كمورّد" : ""}</span></button>` : ""}
<button type="button" class="${od ? "w" : "ok"}" data-go="callcenter"><b>${num(od)}</b><span>طلب بلا استجابة منذ مدة</span></button>
${rr.length ? `<button type="button" class="w" data-go="returns" title="${rr.slice(0, 8).map(x => x.o.id + ": " + x.days + " يوم").join(" | ").replace(/\"/g, "")}"><b>${num(rr.length)}</b><span>طرد راجع جاهز للسحب (Retour à récupérer) — المهلة 10 أيام ثم 10 دج/يوم${rr.some(x => x.late) ? " · غرامة جارية " + num(rr.reduce((t, x) => t + x.late, 0)) + " دج" : rr.some(x => x.days >= 7) ? " · بعضها يقترب من المهلة" : ""}</span></button>` : ""}
${orph.length ? `<button type="button" class="w" data-go="orphans" title="${orph.slice(0, 8).map(r => r.tracking).join(" | ")}"><b>${num(orph.length)}</b><span>طرد عند الشركة بلا طلب في اللوحة — اربطه كي لا يضيع من الحساب</span></button>` : ""}
<button type="button" class="${fail ? "w" : "ok"}" data-go="shipped"><b>${num(fail)}</b><span>فشل توصيل / مرتجع</span></button></div>
<h3 style="margin-top:16px">أفضل المنتجات مبيعاً</h3>${top.length ? `<div class="tp">${top.map(([t, q], i) => `<div class="r"><span class="n">${i + 1}</span><span class="t"></span><span class="q">${num(q)} قطعة</span><span class="bar"><i style="width:${Math.max(6, q / topMax * 100)}%"></i></span></div>`).join("")}</div>` : '<div class="em" style="padding:10px">لا مبيعات في هذه الفترة.</div>'}</div>
</div>`;
    /* نصوص من البيانات بـtextContent (لا innerHTML) */
    root.querySelectorAll("tr[data-o]").forEach(tr => { const o = last[+tr.dataset.o]; tr.cells[0].textContent = o.name || "—"; tr.cells[1].textContent = o.wilaya || "—"; tr._o = o; });
    { const wl = (() => { const a = A(), m = {}; orders().filter(isConf).forEach(o => { let nm = String(o.wilaya || "").trim(); try { const w = a.wCo && a.wCo(nm); if (w && w.name) nm = w.name; } catch (e) { } nm = nm || "—"; m[nm] = (m[nm] || 0) + 1; }); return Object.keys(m).sort((x, y) => m[y] - m[x] || x.localeCompare(y)).slice(0, 8); })(); root.querySelectorAll("td[data-wl]").forEach((td, i) => { td.textContent = wl[i] || "—"; }); }
    root.querySelectorAll("[data-rs]").forEach(el => { el.textContent = lastSt[+el.dataset.rs].t; });
    root.querySelectorAll(".tp .t").forEach((el, i) => { el.textContent = top[i][0]; el.title = top[i][0]; });
    bind(root, ch, series, labels, hourly);
  }
  function bind(root, ch, series, labels, hourly) {
    root.querySelectorAll("[data-d]").forEach(b => b.onclick = () => { S.days = +b.dataset.d; if (S.days === 0 && (!S.from || !S.to)) { S.to = iso(Date.now()); S.from = iso(Date.now() - 6 * DAY); } render(); });
    { const f = $("ah-from"), g = $("ah-to"); if (f) f.onchange = () => { if (f.value) { S.from = f.value; if (S.to && S.to < S.from) S.to = S.from; render(); } }; if (g) g.onchange = () => { if (g.value) { S.to = g.value; if (S.from && S.from > S.to) S.from = S.to; render(); } }; }
    root.querySelectorAll("[data-m]").forEach(b => b.onclick = () => { S.metric = b.dataset.m; render(); });
    root.querySelectorAll("[data-tb]").forEach(b => b.onclick = () => { S.table = !S.table; render(); });
    root.querySelectorAll("[data-go]").forEach(b => b.onclick = () => go(b.dataset.go));
    root.querySelectorAll("[data-adt]").forEach(b => b.onclick = async () => { b.disabled = true; try { await A().toggleAdSlug(b.dataset.adt); } catch (e) { console.warn("AdminHome", e); } render(); });
    root.querySelectorAll("tr[data-o]").forEach(tr => tr.onclick = () => { const o = tr._o, ix = (A().orders || []).indexOf(o); if (ix >= 0 && A().openOrderPreview) { try { A().openOrderPreview(ix); return; } catch (e) { } } go("orders"); const q = $("order-filter-q"); if (q) { q.value = o.phone || o.id || ""; try { A().applyOrderFilters(); } catch (e) { } } });
    const box = $("ah-ch"), svg = box && box.querySelector("svg"); if (!svg) return;
    const tip = $("ah-tip"), cx = $("ah-cx");
    const move = e => {
      const r = svg.getBoundingClientRect(), px = (e.clientX - r.left) / r.width * ch.W, n = ch.n;
      let i = Math.round((px - 8) / ((ch.W - 16) / Math.max(1, n - 1))); i = Math.max(0, Math.min(n - 1, i));
      const X = ch.x(i); cx.setAttribute("x1", X); cx.setAttribute("x2", X); cx.setAttribute("opacity", 1);
      tip.replaceChildren(); const b = document.createElement("b"), s = document.createElement("span"), k = document.createElement("i");
      b.textContent = S.metric === "sales" ? money(series[i]) : num(series[i]) + " طلب"; s.append(k, labels[i]); tip.append(b, s);
      const rx = X / ch.W * r.width, ty = ch.y(series[i]) / 250 * r.height; tip.style.left = Math.max(0, Math.min(r.width - 140, rx - 70)) + "px"; tip.style.top = Math.max(0, ty - 64) + "px"; tip.classList.add("on");
    };
    svg.addEventListener("pointermove", move); svg.addEventListener("pointerdown", move);
    svg.addEventListener("pointerleave", () => { tip.classList.remove("on"); cx.setAttribute("opacity", 0); });
  }
  function go(w) {
    const a = A(), btn = k => [...document.querySelectorAll(".nav-btn")].find(b => (b.getAttribute("onclick") || "").includes("'" + k + "'"));
    if (w === "presend") { try { AdminPreSend.open(); } catch (e) { } return; }
    if (w === "sent") { try { AdminSent.open(); } catch (e) { } return; }
    if (w === "neword") { try { if (typeof ManualOrder !== "undefined") ManualOrder.open({ mode: "new" }); } catch (e) { } return; }
    if (w === "ruqya-new" || w === "ruqya-pending" || w === "ruqya-uv" || w === "ruqya") { try { AdminRuqya.queue(w === "ruqya-new" ? { view: "man" } : w === "ruqya-pending" ? { filter: "pending" } : w === "ruqya-uv" ? { filter: "uv" } : { filter: "up" }); } catch (e) { } const rb = btn("ruqya"); if (rb) a.tab("ruqya", rb); return; }
    if (w === "newp") { try { a.editProduct(null); } catch (e) { } return; }
    if (w === "orders-new") { a.tab("orders", btn("orders")); const s = $("order-filter-status"); if (s) { s.value = "nouvelle"; try { a.applyOrderFilters(); } catch (e) { } } return; }
    if (w === "merge") { a.tab("orders", btn("orders")); try { const g = (AdminUpsell.mergeable(a.orders || []) || [])[0]; if (g) { const ix = (a.orders || []).indexOf(g.keep); const q = $("order-filter-q"); if (q) { q.value = g.keep.phone || g.keep.id || ""; a.applyOrderFilters(); } if (ix >= 0 && a.openOrderPreview) setTimeout(() => { try { a.openOrderPreview(ix); } catch (e) { } }, 150); } } catch (e) { } return; }
    if (w === "aicredit") { try { a.tab("imggen"); if (typeof ImgGen !== "undefined" && ImgGen.tab) ImgGen.tab("set"); } catch (e) { } return; }
    if (w === "orphans") { a.tab("shipped", btn("shipped")); try { AdminYd.showOrphans(); } catch (e) { } return; }
    if (w === "kinddg") { try { AdminStores.newKind("digital"); } catch (e) { } return; }
    if (w === "ads") { a.tab("finance", btn("finance")); try { a.finView("prod"); const x = a.adStockAlerts(5)[0]; if (x) a.finOpen(x.c.slug, 2); } catch (e) { } return; }
    const b = btn(w); if (b) a.tab(w, b);
  }
  function open() { try { if (typeof AdminEdition !== "undefined" && AdminEdition.edition() === "design") return AdminEdition.land(); } catch (e) { } try { if (typeof AdminKind !== "undefined" && AdminKind.landing() === "digital") { const d = [...document.querySelectorAll(".nav-btn")].find(x => (x.getAttribute("onclick") || "").includes("'digital'")); if (d && A().tab) return A().tab("digital", d); } } catch (e) { } const b = [...document.querySelectorAll(".nav-btn")].find(x => (x.getAttribute("onclick") || "").includes("'home'")); if (b && A().tab) A().tab("home", b); }
  /* عند فتح اللوحة تبدأ دائماً على «لوحة التحكم»: إن انتقل قسم آخر تلقائياً أثناء التحميل (قبل أي نقر من المستخدم) نعيدها */
  function guard() {
    let touched = false; const mark = () => { touched = true; };
    document.addEventListener("pointerdown", mark, { capture: true, once: true }); document.addEventListener("keydown", mark, { capture: true, once: true });
    [1200, 3000].forEach(ms => setTimeout(() => { if (touched || /^#(?!$)/.test(location.hash)) return; const on = document.querySelector(".nav-btn.on"); const land = (typeof AdminEdition !== "undefined" && AdminEdition.edition() === "design") ? "builder" : (typeof AdminKind !== "undefined" && AdminKind.landing() === "digital") ? "digital" : "home"; if (on && !new RegExp("'" + land + "'").test(on.getAttribute("onclick") || "")) open(); }, ms));
  }
  /* زر/سحب الرجوع (من حافة الشاشة) لا يغلق اللوحة: يغلق النافذة المفتوحة أولاً، ثم يعود للقسم السابق، وعلى الرئيسية يحذّر مرة قبل الخروج.
     مدخل سجلّ «حارس» يُعاد دفعه بعد كل رجوع (الاستوديو وروابط الأدوات تدفع مداخلها الخاصة فلا يتعارض معها: لا نتصرف إلا عند بلوغ المدخل الأساسي). */
  const TABS = ["home"];
  function trackTab(t) { if (S.popping || !t) return; if (t === "home") { TABS.length = 0; TABS.push("home"); return; } if (TABS[TABS.length - 1] !== t) { TABS.push(t); if (TABS.length > 30) TABS.shift(); } }
  function backGuard() {
    if (S.bg) return; S.bg = 1;
    try { history.pushState({ adm: 1 }, "", location.href); } catch (e) { return; }
    window.addEventListener("popstate", e => {
      if (e.state && e.state.adm) return;                                   // رجوع من مدخل خاص (استوديو/أداة) إلى الحارس: لا شيء
      const a = A(); let did = false;
      const mb = [...document.querySelectorAll(".modal-bg.open")], pb = document.getElementById("pb-app"), spv = document.getElementById("spv");
      if (mb.length) { mb.forEach(x => x.classList.remove("open")); did = true; }
      else if (pb && pb.classList.contains("on") && typeof PBApp !== "undefined" && PBApp.close) { try { PBApp.close(); } catch (x) { } did = true; }
      else if (spv && spv.classList.contains("on") && typeof SitePreview !== "undefined" && SitePreview.close) { try { SitePreview.close(); } catch (x) { } did = true; }
      else if (TABS.length > 1 && a && a.tab) { TABS.pop(); S.popping = true; try { a.tab(TABS[TABS.length - 1]); } catch (x) { } S.popping = false; did = true; }
      if (did) { try { history.pushState({ adm: 1 }, "", location.href); } catch (x) { } S.exitT = 0; return; }
      if (S.exitT && Date.now() - S.exitT < 2500) { S.exitT = 0; history.back(); return; }          // ثاني رجوع خلال ثانيتين: خروج فعلي
      S.exitT = Date.now(); try { toast("اسحب مرة أخرى للخروج من اللوحة"); } catch (x) { } try { history.pushState({ adm: 1 }, "", location.href); } catch (x) { }
    });
  }
  function init() {
    const a = A(); if (!a || a.__homeWrap || typeof a.renderAll !== "function") return setTimeout(init, 400);
    a.__homeWrap = 1; const o = a.renderAll;
    /* الرئيسية تُفتح حتى لو تعثّر رسم قسم آخر (finally) وفور إظهار اللوحة دون انتظار أي رسم: كان تعثّر renderAll يترك «الطلبات» ظاهرة طويلاً */
    a.renderAll = function () { try { return o.apply(this, arguments); } finally { try { render(); if (!S.shown) { S.shown = true; open(); guard(); backGuard(); } } catch (e) { console.warn("AdminHome", e); } } };
    { const app = $("app"); if (app && app.classList.contains("hidden")) { const ob = new MutationObserver(() => { if (app.classList.contains("hidden")) return; ob.disconnect(); if (!S.shown) { S.shown = true; try { open(); guard(); backGuard(); } catch (e) { console.warn("AdminHome", e); } } }); ob.observe(app, { attributes: true, attributeFilter: ["class"] }); } }
    const ot = a.tab; a.tab = function (t, b) { const r = ot.apply(this, arguments); document.body.classList.toggle("ah-on", t !== "orders"); if (t === "home") render(); try { trackTab(t); } catch (e) { } return r; };
    if (a.orders && a.orders.length !== undefined && !$("app").classList.contains("hidden")) { render(); if (!S.shown) { S.shown = true; open(); guard(); backGuard(); } }
  }
  window.addEventListener("store:ai-credit", () => refreshSoft());
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
  return { render, open, S, refreshSoft, realSt };
})();
