/* تعديل بيانات الطلب بعد التأكيد (v1.89.79): من معاينة الطلب (الاسم، الولاية، البلدية، طريقة التوصيل + المكتب، ورسم التوصيل) ثم يُحفظ ويُحدَّث الطرد لدى شركة التوصيل تلقائياً إن كان قد أُرسل.
   الحفظ: قاعدة الطلبات إن سمحت بتعديل هذه الحقول، وإلا يُحفظ التعديل في اللوحة (store_order_edits، يتزامن بين أجهزتك) ويُطبَّق فوق الطلب عند كل تحميل (OrderEdit.apply).
   تحديث الشركة: Admin.updateAtCompany(i) (للشركات التي تدعم updateRequest؛ غيرها يُنبَّه لتعديل الطرد يدوياً). */
window.OrderEdit = (function () {
  const LSK = "store_order_edits", A = () => (typeof Admin !== "undefined" ? Admin : null);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const load = () => { try { const v = JSON.parse(localStorage.getItem(LSK) || "{}"); return v && typeof v === "object" ? v : {}; } catch (e) { return {}; } };
  const save = v => { try { localStorage.setItem(LSK, JSON.stringify(v)); } catch (e) { } };
  const FIELDS = ["name", "wilaya", "commune", "dtype", "desk", "fee", "total"];
  /* يطبّق التعديلات المحفوظة فوق الطلبات (يُستدعى من Admin.liveOrders) */
  function apply(list) { const ed = load(); return (list || []).map(o => { const e = o && ed[o.id]; return e ? Object.assign(o, e) : o; }); }
  const canEdit = o => !!o && ["confirmee", "expediee"].includes(o.status);
  const W = () => (typeof WILAYAS !== "undefined" ? WILAYAS : []);
  const wOf = n => W().find(x => x.name === n) || null;
  const num = v => Math.max(0, Math.round(Number(v) || 0));

  const fdef = ad => (window.ManualOrder && ManualOrder.fromDef ? ManualOrder.fromDef(ad) : "");
  const fcur = (ad, o) => (ad.fromOf && ad.fromOf(o)) || fdef(ad);
  function fromOpts(ad, o) { const d = fdef(ad), c = fcur(ad, o); return W().filter(x => !x.par).slice().sort((a, b) => a.id - b.id).map(w => `<option value="${esc(w.name)}"${w.name === c ? " selected" : ""}>${w.id} — ${esc(w.name)}${w.name === d ? " (الافتراضية)" : ""}</option>`).join(""); }
  function open(i) {
    const ad = A(), o = ad && ad.orders[i]; if (!o) return; if (!canEdit(o)) { toast("التعديل متاح للطلبات المؤكَّدة أو في الطريق فقط"); return; }
    let bg = document.getElementById("oe-bg"); if (bg) bg.remove();
    bg = document.createElement("div"); bg.id = "oe-bg"; bg.className = "modal-bg open"; bg.dir = "rtl";
    const t = ad.trackingOf ? ad.trackingOf(o) : null, sub = num(o.subtotal), disc = num(o.discount);
    const wil = W().slice().sort((a, b) => a.id - b.id).filter(x => !(typeof Admin !== "undefined" && Admin.wilHidden && Admin.wilHidden(x)) || x.name === o.wilaya), fld = (l, h) => `<div class="field" style="margin-bottom:.55rem"><label style="font-weight:800;font-size:.82rem">${l}</label>${h}</div>`;
    bg.innerHTML = `<div class="modal" style="max-width:520px;position:relative"><button type="button" class="ord-x" id="oe-x" title="إغلاق" aria-label="إغلاق">✕</button><h3>✏️ تعديل الطلب <span dir="ltr">${esc(o.id)}</span></h3>
<p class="hint" style="margin:.2rem 0 .7rem">${t ? "هذا الطلب مسجَّل لدى شركة التوصيل (التتبع <b dir=\"ltr\">" + esc(t.tracking) + "</b>): تُحدَّث بياناته عندها تلقائياً بعد الحفظ." : "الطلب لم يُرسل لشركة التوصيل بعد؛ تُحفظ التعديلات وتُستعمل عند الإرسال."}</p>
${fld("الاسم", `<input id="oe-name" value="${esc(o.name)}">`)}
${fld("الولاية", `<select id="oe-wil">${wil.map(w => `<option value="${esc(w.name)}"${w.name === o.wilaya ? " selected" : ""}>${w.id} — ${esc(w.name)}</option>`).join("")}${wOf(o.wilaya) ? "" : `<option value="${esc(o.wilaya)}" selected>${esc(o.wilaya)}</option>`}</select>`)}
${fld("البلدية", `<select id="oe-com"></select>`)}
${fld("طريقة التوصيل", `<div style="display:flex;gap:1rem;flex-wrap:wrap"><label><input type="radio" name="oe-dt" value="home"${o.dtype !== "stop" ? " checked" : ""}> إلى المنزل</label><label><input type="radio" name="oe-dt" value="stop"${o.dtype === "stop" ? " checked" : ""}> مكتب Stop Desk</label></div>`)}
<div id="oe-deskw">${fld("المكتب", `<select id="oe-desk"></select>`)}</div>
${t ? "" : fld("ولاية الانطلاق", `<select id="oe-from">${fromOpts(ad, o)}</select><small class="hint">الافتراضية من إعدادات شركة التوصيل — يتبعها رسم التوصيل وتُرسل منها الطرد</small>`)}
${fld("رسم التوصيل (دج)", `<input id="oe-fee" type="number" min="0" step="50" value="${num(o.fee)}"><small id="oe-fh" class="hint" style="white-space:pre-line"></small>`)}
<div style="display:flex;justify-content:space-between;align-items:center;margin:.3rem 0 .8rem;font-weight:900">الإجمالي الجديد <span id="oe-tot" style="color:var(--green)"></span></div>
<div style="display:flex;gap:.5rem;flex-wrap:wrap"><button type="button" class="small green" id="oe-save">حفظ</button><button type="button" class="small warn" id="oe-no">إلغاء</button></div></div>`;
    document.body.appendChild(bg);
    const $ = id => bg.querySelector("#" + id), dt = () => (bg.querySelector('input[name="oe-dt"]:checked') || {}).value || "home";
    const free0 = num(o.fee) === 0;
    function fillCom(keep) {
      const w = wOf($("oe-wil").value), cur = keep == null ? o.commune : keep;
      $("oe-com").innerHTML = WilKids.html(w, cur);
    }
    function fillDesk(keep) {
      const w = ad.wCo ? ad.wCo($("oe-wil").value) : wOf($("oe-wil").value), com = $("oe-com").value, ds = ad.desksIn ? ad.desksIn(w, com) : ((w && w.desks) || []), cur = keep == null ? o.desk : keep, has = ds.length > 0;
      $("oe-desk").innerHTML = (has ? "" : `<option value="">${com ? "لا يوجد مكتب Stop Desk في بلدية " + esc(com) : "لا توجد مكاتب معروفة لهذه الولاية"}</option>`) + ds.map(d => `<option value="${esc(d.name)}"${d.name === cur ? " selected" : ""}>${esc(d.name)}</option>`).join("");
      const sr = bg.querySelector('input[name="oe-dt"][value="stop"]'); if (sr) { sr.disabled = !has; sr.parentElement.style.opacity = has ? "" : ".45"; sr.parentElement.title = has ? "" : "لا يوجد مكتب Stop Desk في هذه البلدية — التوصيل للمنزل فقط"; if (!has && sr.checked) { bg.querySelector('input[name="oe-dt"][value="home"]').checked = true; } }
      $("oe-deskw").style.display = dt() === "stop" ? "" : "none";
    }
    const ffFail = {};
    function autoFee() {
      const w = wOf($("oe-wil").value), q = w && ad.shipFeeFor ? ad.shipFeeFor(w, $("oe-com").value, dt()) : { fee: w ? num(dt() === "stop" ? w.stop : w.home) : num(o.fee), base: 0, sup: 0 };
      let base = q.fee, note = ad.feeNote ? ad.feeNote(q, $("oe-com").value) : "";
      const fe = $("oe-from"), fw = fe && fe.value && fe.value !== fdef(ad) ? wOf(fe.value) : null;
      if (w && fw && $("oe-com").value && ad.fromFeeFor) {
        const v = ad.fromFeeFor(fw.id, w, $("oe-com").value, dt()), key = fw.id + "-" + (w.par || w.id);
        if (v != null) { base = v; note = " (تعريفة ياليدين من " + fw.name + ")"; }
        else if (!ffFail[key] && ad.ensureFromFees) { ad.ensureFromFees(fw.id, w).then(okk => { if (!okk) ffFail[key] = true; if (document.body.contains(bg)) autoFee(); }); note = " ⏳ جارِ جلب تعريفة الانطلاق من " + fw.name + "…"; }
        else note = " — تعذّر جلب تعريفة الانطلاق من " + fw.name + " فحُسب الرسم من الولاية الافتراضية";
      }
      const same = $("oe-wil").value === o.wilaya && $("oe-com").value === o.commune && dt() === (o.dtype === "stop" ? "stop" : "home") && (!fe || fe.value === fcur(ad, o));
      $("oe-fee").value = same ? num(o.fee) : (free0 ? 0 : base);
      $("oe-fh").textContent = same ? "" : "رسم التوصيل الجديد: " + base.toLocaleString("fr-DZ") + " دج" + note + (free0 ? " (الطلب الأصلي بتوصيل مجاني فبقي مجانياً — عدّل الرسم إن لزم)" : "");
      total();
    }
    const total = () => { $("oe-tot").textContent = Math.max(0, sub - disc + num($("oe-fee").value)).toLocaleString("fr-DZ") + " دج"; };
    fillCom(); fillDesk(); total();
    $("oe-wil").onchange = () => { fillCom(""); fillDesk(""); autoFee(); }; $("oe-com").onchange = () => { WilKids.pick($("oe-wil"), $("oe-com")); fillDesk(""); autoFee(); }; if ($("oe-from")) $("oe-from").onchange = () => autoFee();
    if (ad.shipSupLoad) ad.shipSupLoad().then(() => { if (document.body.contains(bg)) autoFee(); });
    bg.querySelectorAll('input[name="oe-dt"]').forEach(r => r.onchange = () => { fillDesk($("oe-desk").value); autoFee(); });
    $("oe-fee").oninput = total;
    const close = () => bg.remove(); $("oe-x").onclick = close; $("oe-no").onclick = close; bg.addEventListener("click", e => { if (e.target === bg) close(); });
    $("oe-save").onclick = async () => {
      const name = $("oe-name").value.trim(); if (name.length < 2) { toast("أدخل الاسم"); return; }
      const f = { name, wilaya: $("oe-wil").value, commune: $("oe-com").value, dtype: dt(), desk: dt() === "stop" ? $("oe-desk").value : "", fee: num($("oe-fee").value) };
      if (f.dtype === "stop" && !f.desk) { toast("اختر مكتب Stop Desk"); return; }
      f.total = Math.max(0, sub - disc + f.fee);
      const b = $("oe-save"); b.disabled = true; b.textContent = "جارٍ الحفظ…";
      const fe = $("oe-from"), fromNew = fe ? (fe.value === fdef(ad) ? "" : fe.value) : null, fromChanged = fromNew !== null && fromNew !== (ad.fromOf && ad.fromOf(o) || "");
      const changed = fromChanged || FIELDS.some(k => String(o[k] == null ? "" : o[k]) !== String(f[k]));
      if (!changed) { close(); toast("لا يوجد تغيير"); return; }
      Object.assign(o, f);
      if (fromChanged) { try { const hadX = !!(o.extra && o.extra["📍 ولاية الانطلاق"]); ad.setNoteTag(o, /📍@\S+\s*/g, fromNew ? "📍@" + fromNew.replace(/\s+/g, "_") : (hadX ? "📍@-" : "")); } catch (e) { } }
      const ed = load(); ed[o.id] = f; save(ed);                                    // احتياط محلي (يتزامن بين الأجهزة)
      let saved = false; try { saved = await API.updateOrderFields(ad.key, o.id, f); } catch (e) { }
      if (saved) { const e2 = load(); delete e2[o.id]; save(e2); }                  // حُفظ في القاعدة: لا حاجة للاحتياط
      let msg = saved ? "تم الحفظ." : "تم الحفظ في اللوحة.";
      if (t) {
        b.textContent = "تحديث شركة التوصيل…";
        const r = await safeCo(ad, ad.orders.indexOf(o));
        msg += r.ok ? " وتحدّث الطرد لدى شركة التوصيل." : (r.skipped ? "" : " لكن تعذّر تحديث الشركة: " + r.msg);
        if (!r.ok && !r.skipped) ad.showNotice("تعذّر تحديث الطرد لدى شركة التوصيل", esc(r.msg) + "<br><small>تم حفظ التعديل في اللوحة؛ عدّل الطرد " + esc(t.tracking) + " يدوياً من حساب الشركة.</small>");
      }
      close(); try { ad.renderOrders(); } catch (e) { } try { ad.openOrderPreview(ad.orders.indexOf(o)); } catch (e) { } toast("✅ " + msg);
    };
  }
  const stash = (id, f) => { const ed = load(); ed[id] = f; save(ed); }, unstash = id => { const ed = load(); delete ed[id]; save(ed); };
  /* تحديث الطرد لدى الشركة بلا تعليق النافذة: أي استثناء (حجب المتصفح/انقطاع) أو تأخّر فوق 25ث يعود كنتيجة فشل عادية فتُغلق نافذة التعديل وتُعاد المعاينة دائماً (كانت تبقى «تحديث شركة التوصيل…» إلى الأبد) */
  const safeCo = async (ad, i, opt) => {
    let timer; try { return await Promise.race([ad.updateAtCompany(i, opt), new Promise(res => { timer = setTimeout(() => res({ ok: false, msg: "انتهت مهلة الشركة (25 ث) — تحقق من الطرد عندها" }), 25000); })]); }
    catch (e) { return { ok: false, msg: e && e.cors ? "الشركة لا تقبل الاتصال من المتصفح" : String((e && e.message) || e).slice(0, 140) }; }
    finally { clearTimeout(timer); }
  };
  return { open, apply, canEdit, load, stash, unstash, safeCo };
})();
