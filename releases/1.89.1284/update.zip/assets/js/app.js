/* اسم متجرك — محرك الطلبات والسلة */
/* صفحات منتجات قديمة تحمل @font-face بمسار جذري /assets/fonts/ فيفشل تحميل خط Cairo عند تثبيت المتجر داخل مجلد فرعي (/store/…): يُصحَّح المسار هنا نسبةً إلى موقع هذا السكربت فيصلح في أي مجلد تثبيت بلا إعادة توليد الصفحات. لا أثر على التثبيت في الجذر (المسار الصحيح يبقى كما هو). */
(function(){ try{ var st=document.getElementById("cairo-local"), sc=document.currentScript; if(!st||!sc||!sc.src||!/url\(\/assets\/fonts\//.test(st.textContent)) return; var base=new URL("../fonts/", sc.src).pathname; if(base==="/assets/fonts/") return; st.textContent=st.textContent.replace(/url\(\/assets\/fonts\//g,"url("+base); }catch(e){} })();
let WA_NUMBER = (typeof CONFIG !== "undefined" && CONFIG.SITE && CONFIG.SITE.waNumber) || "213550000000"; // يمكن استبداله ديناميكياً عبر assets/data/checkout.json (راجع initCheckout أدناه)
/* الشحن المجاني: خاصية المنتج freeShip، ويمكن حصره في عروض بعينها (offer.ship)؛ بلا عروض محددة يشمل كل العروض */
function offerFreeShip(p, o){ if(!p || !p.freeShip) return false; if(productType(p)==="grouped") return true; const flagged = (p.offers||[]).some(x=>x.ship); return flagged ? !!(o && o.ship) : true; }
function cartItemFreeShip(it){ const p = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug===it.slug) : null; if(!p || !p.freeShip) return false; const fl = (p.offers||[]).filter(x=>x.ship); return fl.length ? it.qty >= Math.min(...fl.map(x=>x.qty)) : true; }
const SITE_NAME = (typeof CONFIG !== "undefined" && CONFIG.SITE && CONFIG.SITE.name) || "اسم متجرك اسم متجرك";
const fmt = n => n.toLocaleString("fr-DZ") + " " + (window.__STORE_CUR || "دج");
/* مناطق التوصيل (Zones): الأسعار والشحن المجاني والاستثناءات مشتقة في WILAYAS من لوحة التحكم ⟵ رسوم التوصيل:
   w.fh/w.fs = توصيل مجاني للمنزل/المكتب، w.fo = مجاني عند بلوغ مجموع الطلب هذا المبلغ، w.xw = الولاية مستثناة كلياً،
   w.xc = {بلدية:"all"|"home"} (all = لا توصيل نهائياً، home = لا توصيل للمنزل فقط ويبقى المكتب) */
function shipBlocked(w, commune, type){
  if(!w) return "";
  if(type === "stop" && __SHIPNOSTOP) return "التوصيل إلى مكتب (Stop Desk) غير متاح حالياً — اختر التوصيل إلى المنزل";
  if(w.xw) return "عذراً، لا يتوفر التوصيل إلى ولاية " + w.name + " حالياً";
  const m = w.xc && commune ? w.xc[commune] : "";
  if(m === "all") return "عذراً، لا يتوفر التوصيل إلى بلدية " + commune + " حالياً";
  if(m === "home" && type !== "stop") return "التوصيل للمنزل غير متاح في بلدية " + commune + (shipDesks(w, null).some(d=>d.commune===commune) ? " — اختر التوصيل إلى مكتب Stop Desk" : "");
  return "";
}
/* تسعير التوصيل: الافتراضي أسعار المناطق (WILAYAS)؛ إن فُعّلت شركة تجلب أسعارها فـ ship-co.json (`def` + `companies`) يعتمد أسعارها تلقائياً.
   وللمنتج اختيار خاص: shipCo = مفتاح شركة | "zones" (أسعار المناطق) | "free" (سعر حر ثابت shipFreeHome/shipFreeStop) */
/* __OCSC: تكاليف الشحن لنموذج الطلب المضمَّن في صفحة هبوط (oc.sc): "" = الشركة الافتراضية، "zones" = مناطق التوصيل؛ null = حسب إعداد المنتج */
let __OCSC = null, __OCPF = null; const pshipCo = p => __OCSC !== null ? __OCSC : (p && p.shipCo);
let __SHIPCO = null, __SHIPDEF = "", __SHIPSUP = {}, __SHIPCP = {}; let __SHIPNOSTOP = false;
/* مكاتب Stop Desk: تُعرض مكاتب شركة التوصيل الافتراضية (أو شركة المنتج) فقط؛ المكتب بلا وسم شركة (قديم) يبقى ظاهراً. وسم الشركة: d.co (يكتبه تحميل المراكز في اللوحة) أو «[Yalidine]/[EasyAndSpeed]» في اسم مراكز ياليدين */
let __SHIPDK = "", __SHIPDP = [];
const deskCo = d => (d && d.co) || (/\[(?:Yalidine|EasyAndSpeed)\]\s*$/i.test(String((d && d.name) || "")) ? "yalidine" : "");
/* الاحتياط: إن لم تُحمَّل مراكز هذه الشركة في أي ولاية بعد (لا مكتب موسوم بها في كل الولايات) لا نُرشّح فتبقى كل المكاتب كما كانت ولا يتعطّل خيار المكتب؛ وبعد تحميلها يُعرض لكل ولاية مكاتب الشركة فقط */
/* الأرخص أولاً: شركة تجمع مكاتب شركات عدة (WeCan): أول كلمة مفضّلة (dp من ship-co.json) تطابق مكتباً في هذه البلدية يُعرض ما يطابقها فقط، وإلا الكلمة التالية، وإلا الكل */
const preferDesks = list => { if(!__SHIPDP.length) return list; const by = {}; list.forEach(d => { (by[(d && d.commune) || ""] = by[(d && d.commune) || ""] || []).push(d); });
  return [].concat(...Object.keys(by).map(k => { const g = by[k]; for(const t of __SHIPDP){ const m = g.filter(d => String((d && d.name) || "").toLowerCase().includes(t)); if(m.length) return m; } return g; })); };      /* لكل بلدية على حدة */
/* عنوان المكتب المختار بالضبط وقت الطلب (يُحفظ في الطلب فلا يضيع بعد إرسال الطرد) */
const deskAddrOf = (w, name, commune) => { try { const all = (w && w.desks) || [], n = String(name || ""), a = all.filter(d => d.name === n), d = a.find(x => commune && x.commune === commune) || a[0]; return d ? String(d.address || "").trim() : ""; } catch (e) { return ""; } };
const shipDesks = (w, p) => { const all = (w && w.desks) ? w.desks : [], pk = typeof pshipCo === "function" ? pshipCo(p) : "", k = (pk && pk !== "zones" && pk !== "free" && pk !== "def") ? pk : __SHIPDK; if(!k) return all;      /* «zones/free/def» مصدر تسعير للصفحة لا شركة: المكاتب تبقى للشركة الافتراضية (كانت «zones» تُعامَل كشركة فتُعرض كل المكاتب) */
  let synced = false; try{ synced = (typeof WILAYAS !== "undefined" ? WILAYAS : []).some(x => (x.desks || []).some(d => deskCo(d) === k)); }catch(e){}
  return synced ? all.filter(d => { const c = deskCo(d); return !c || c === k; }) : all; };     /* شركة التوصيل الافتراضية بلا قائمة مكاتب Stop Desk عبر واجهتها: لا يُعرض التوصيل للمكتب للزبون (يُنشره admin في ship-co.json) */
/* بلديات لا توصّل إليها شركة التوصيل الافتراضية (مثل تبلبالة عند ياليدين): تُعلَّم «غير متاح» بنفس آلية الاستثناءات w.xc */
function applyShipNd(nd, def){
  if(!nd || def !== "yalidine" || typeof WILAYAS === "undefined") return;
  const nz = x=>String(x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
  WILAYAS.forEach(w=>{ const L = nd[w.par || w.id]; if(!L || !L.length) return; const set = new Set(L); (w.communes || []).forEach(c=>{ if(set.has(nz(c))){ w.xc = w.xc || {}; if(!w.xc[c]) w.xc[c] = "all"; } }); });
}
/* قائمة ولايات شركة التوصيل الافتراضية نفسها (لا القائمة الموحّدة): ولاية غير موجودة أو غير مخدومة عندها تُحذف من القوائم (w.hide)، وبلدياتها الجديدة 59–69 تتبع أمّها؛ لا يُطبَّق إن لم تتطابق 50 ولاية على الأقل (اختلاف تسمية) */
function applyShipList(cos, def){
  if(def !== "yalidine" || typeof WILAYAS === "undefined" || !cos || !cos.yalidine || !cos.yalidine.wl) return;
  const wl = cos.yalidine.wl, nz = x=>String(x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, ""), vals = Object.keys(wl).map(k=>wl[k]), find = w=>{ const n = nz(w.name), e = wl[w.id]; return (e && (e[0] === n || e[0].includes(n) || n.includes(e[0]))) ? e : vals.find(v=>v[0] === n); };
  const tops = WILAYAS.filter(w=>!w.par); let hit = 0; tops.forEach(w=>{ if(find(w)) hit++; }); if(hit < 50) return;
  tops.forEach(w=>{ const e = find(w); w.hide = !e || !e[1]; });
  WILAYAS.filter(w=>w.par).forEach(w=>{ const e = find(w); w.hide = !e || !e[1]; });   // الولايات الجديدة 59–69: لا تظهر كولايات إلا إن عدّتها الشركة ولاية (بئر العاتر عند ياليدين ما زالت بلدية تابعة لتبسة)
}
function loadShipCo(){
  if(__SHIPCO !== null) return;
  __SHIPCO = {};
  fetch((typeof REL!=="undefined"?REL:"") + "assets/data/ship-co.json", {cache:"no-store"}).then(r=>r.ok?r.json():null).then(j=>{ if(j && j.companies){ __SHIPCO = j.companies; __SHIPDEF = j.def || ""; __SHIPDK = j.dk || ""; __SHIPDP = String(j.dp || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean); __SHIPNOSTOP = !!j.noStop; __SHIPSUP = j.sup || {}; __SHIPCP = j.cp || {}; try{ applyShipNd(j.nd, j.def); applyShipList(j.companies, j.def); }catch(e){} if(__SHIPNOSTOP || __SHIPDEF || Object.keys(__SHIPCO).length || Object.keys(__SHIPSUP).length || Object.keys(__SHIPCP).length) document.dispatchEvent(new Event("shipco:ready")); } }).catch(()=>{});
}
document.addEventListener("DOMContentLoaded", ()=>{ try{ loadShipCo(); }catch(e){} });
document.addEventListener("shipco:ready", ()=>{ try{ if(typeof Cart !== "undefined" && document.getElementById("cwilaya")) Cart.render(); }catch(e){} });
document.addEventListener("shipco:ready", ()=>{ try{ ["wilaya","cwilaya"].forEach(id=>{ const sel = document.getElementById(id); if(!sel || typeof WILAYAS === "undefined") return; Array.from(sel.options).forEach(o=>{ const w = o.value && WILAYAS.find(x=>x.id == o.value); if(w && w.hide) o.remove(); }); }); }catch(e){} });
/* سعر المنتج الحر: يُرجع {home,stop} (قيمة فارغة = null) أو null */
function prodShipPf(p){ if(__OCSC !== null) return (__OCSC === "free" && __OCPF && (__OCPF.home !== null || __OCPF.stop !== null)) ? __OCPF : null;   /* صفحة هبوط حدّدت أسعار توصيلها (oc.sc): تتجاوز المنتج */
  if(!p || p.shipCo !== "free") return null; const n = v=>(v === undefined || v === null || v === "" || isNaN(Number(v))) ? null : Number(v); const pf = { home:n(p.shipFreeHome), stop:n(p.shipFreeStop) }; return (pf.home === null && pf.stop === null) ? null : pf; }
/* مصدر تسعير بنود السلة: إن اتفقت كلها على مصدر واحد فهو، وإلا (مختلطة) التسعير الافتراضي */
function cartShipCo(items){
  const set = new Set((items||[]).map(it=>{ const p = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug===it.slug) : null; return (p && p.shipCo) || ""; }));
  return set.size === 1 ? [...set][0] : "";
}
function prodShipAdj(p){ if(!p || p.shipAdj === undefined || p.shipAdj === null || p.shipAdj === "" || isNaN(Number(p.shipAdj))) return null; return Math.round(Number(p.shipAdj)); }      // المبلغ المنقوص من سعر التوصيل لهذا المنتج (يتجاوز إعداد الشركة؛ 0 = بلا نقص)
function cartShipAdj(items){
  const slugs = new Set((items||[]).map(it=>it.slug)); if(slugs.size !== 1) return null;
  const p = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug===[...slugs][0]) : null; return prodShipAdj(p);
}
function cartShipPf(items){
  const slugs = new Set((items||[]).map(it=>it.slug)); if(slugs.size !== 1) return null;
  const p = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug===[...slugs][0]) : null; return prodShipPf(p);
}
/* خيار «النقص على الولاية فقط»: بلدية الولاية نفسها (الاسم نفسه) تأخذ سعر الولاية − المبلغ المنقوص، وكل بلدية أخرى تأخذ سعر الولاية الأصلي */
function __adjSkip(w, commune, co){
  if(!co || co.adjMode !== "wilaya") return false; const nk = v => String(v || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, ""), c = nk(commune);
  return !!c && c !== nk(w && w.name);
}
function shipQuote(w, commune, type, sub, co, pf, pa){
  if(!w) return { fee:null, free:false, blocked:false, msg:"" };
  const msg = shipBlocked(w, commune, type); if(msg) return { fee:0, free:false, blocked:true, msg };
  let base = type === "stop" ? w.stop : w.home, flatFree = false, supAdd = 0, adjApplied = 0;
  let src = co || ""; if(src === "free" && !pf) src = "";
  if(src === "free"){
    const v = type === "stop" ? (pf.stop !== null ? pf.stop : pf.home) : (pf.home !== null ? pf.home : pf.stop);
    if(v !== null && v >= 0){ base = v; flatFree = v === 0; }
  } else if(src !== "zones"){
    const key = src || __SHIPDEF;
    if(key && __SHIPCO && __SHIPCO[key] && __SHIPCO[key].prices){ const t = __SHIPCO[key].prices[w.id], v = t ? Number(type === "stop" ? t.stop : t.home) : 0; if(v > 0){ base = v; const aj = (pa !== undefined && pa !== null) ? pa : (Number(__SHIPCO[key].adj) || 0); if(aj && !__adjSkip(w, commune, __SHIPCO[key])){ const nb = Math.max(0, base - aj); adjApplied = base - nb; base = nb; } } }   // تعديل سعر التوصيل المعروض للزبون (يُطرح من سعر الشركة؛ سالب = يزيد)
  }
  const kcm = String(commune || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, ""), ckey = src !== "free" && src !== "zones" ? (src || __SHIPDEF) : "", adjOnly = !!(ckey && __SHIPCO && __SHIPCO[ckey] && __SHIPCO[ckey].adjMode === "wilaya" && kcm), cpd = !adjOnly && ckey === "yalidine" && kcm && __SHIPCP[w.par || w.id] && __SHIPCP[w.par || w.id][kcm];
  if(cpd && (type === "stop" ? cpd[1] : cpd[0]) > 0){      // سعر البلدية المستقل عند الشركة (مطلق) — منفصل عن سعر الولاية؛ يبقى تعديل السعر المعروض (adj) مطبَّقاً عليه
    const wb = base, aj = (pa !== undefined && pa !== null) ? pa : (Number(__SHIPCO[ckey] && __SHIPCO[ckey].adj) || 0), nb = Math.max(0, Number(type === "stop" ? cpd[1] : cpd[0]) - aj);
    supAdd = nb - wb; adjApplied = aj ? Number(type === "stop" ? cpd[1] : cpd[0]) - nb : 0; base = nb;
  } else if(src !== "free" && src !== "zones" && !adjOnly && !(ckey && __SHIPCO && __SHIPCO[ckey] && __SHIPCO[ckey].own)){      /* شركة تعريفتها كاملة (DHD وZR وWeCan…): لا تُضاف إليها إضافات بلديات ياليدين */            // (أسعار المناطق = سعر الولاية فقط بلا إضافة بلدية) إضافة البلدية (Supplément commune) عند شركة التوصيل: تُضاف لسعر الولاية
    const cs = __SHIPSUP[w.par || w.id], k = String(commune || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, ""), d = cs && k && cs[k];
    if(d){ const add = Number(type === "stop" ? d[1] : d[0]) || 0; if(add){ const nb = Math.max(0, base + add); supAdd = nb - base; base = nb; } }
  }
  const free = flatFree || !!(type === "stop" ? w.fs : w.fh) || !!(w.fo && sub >= w.fo);
  return { fee: free ? 0 : base, free, blocked:false, msg:"", sup: free ? 0 : supAdd, adj: free ? 0 : adjApplied };      // sup: إضافة البلدية داخل fee (لا تُعرض للزبون؛ تُسجَّل في الطلب لمعاينة المدير)
}
/* تعطيل خيار المنزل/المكتب المحجوب في بلدية مستثناة وتحويل الاختيار إلى الآخر إن أمكن */
function shipRadios(name, w, commune){
  const rs = [...document.querySelectorAll('input[name="'+name+'"]')]; if(!rs.length) return;
  rs.forEach(r=>{ const b = shipBlocked(w, commune, r.value); if(!b) return; r.disabled = true; const l = r.closest("label"); if(l){ l.style.opacity = .45; l.title = b; } });
  const cur = rs.find(r=>r.checked);
  if(cur && cur.disabled){ const alt = rs.find(r=>!r.disabled); if(alt){ alt.checked = true; alt.dispatchEvent(new Event("change")); } }
}
function shipOptLabel(w, c){ return (w && w.xc && w.xc[c] === "all") ? c + " (غير متوفر)" : c; }
/* بلديات الولايات الجديدة 59–69 تظهر أيضاً مع بلديات ولايتها الأم (بريكة مع باتنة)؛ اختيار إحداها يحوّل الولاية إلى الجديدة تلقائياً */
/* بلدية غير موجودة في قائمة بلديات ياليدين لولايتها (قائمة cp المنشورة) تُحذف؛ لا يُطبَّق إن لم تتطابق 70% من بلديات الولاية (اختلاف تهجئة) */
function commHidden(w, c){
  if(__SHIPDEF !== "yalidine" || !w) return false; const cp = __SHIPCP[w.par || w.id]; if(!cp) return false;
  const nz = x=>String(x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, ""), keys = Object.keys(cp), has = n=>{ const k = nz(n); return keys.some(y=>y === k || y.includes(k) || k.includes(y)); };
  const all = w.communes || []; if(all.length && all.filter(has).length / all.length < .7) return false;
  return !has(c);
}
function commOpts(w){
  const out = ((w && w.communes) || []).filter(c=>!commHidden(w, c)).map(c=>({ c, w, kid:false }));
  if(w && !w.par && typeof WILAYAS !== "undefined") WILAYAS.filter(k=>k.par === w.id).forEach(k=>(k.communes || []).forEach(c=>{ if(!commHidden(k, c) && !out.some(x=>x.c === c)) out.push({ c, w:k, kid:!k.hide }); }));
  return out;
}
function fillCommuneSel(sel, w){
  sel.innerHTML = '<option value="">— اختر البلدية —</option>';
  commOpts(w).forEach(x=>{ const o = document.createElement("option"); o.value = x.c; o.textContent = shipOptLabel(x.w, x.c) + (x.kid ? " — ولاية " + x.w.name : ""); if(x.kid) o.dataset.w = x.w.id; if(x.w.xc && x.w.xc[x.c] === "all"){ o.disabled = true; o.style.color = "#9aa3a0"; } sel.appendChild(o); });
}
/* سعر كل بلدية يظهر بجانب اسمها في القائمة (يُحسب بالمنطق نفسه الذي يحسب رسم الطلب: نوع التوصيل والمنتج والشحن المجاني) */
function labelCommunes(sel, w, fn){
  if(!sel || !w || !sel.options) return;
  for(let i = 0; i < sel.options.length; i++){
    const o = sel.options[i]; if(!o.value) continue; if(o.dataset.t === undefined) o.dataset.t = o.textContent; if(o.disabled) continue;
    o.textContent = o.dataset.t;      /* بلا سعر في أسماء البلديات (طلب المتجر): رسم التوصيل يظهر في ملخّص الطلب لا في القائمة */
  }
}
/* إن كانت البلدية المختارة تابعة لولاية جديدة: بدّل قائمة الولاية إليها وأعد ملء بلدياتها وأبقِ البلدية محدّدة */
function kidSwitch(wsel, csel){
  const op = csel.selectedOptions && csel.selectedOptions[0], kid = op && op.dataset.w ? WILAYAS.find(x=>x.id == op.dataset.w) : null;
  if(!kid) return null;
  const c = csel.value; wsel.value = kid.id; fillCommuneSel(csel, kid); csel.value = c; return kid;
}
function lowStockNote(p){ const stock = Number(p && p.stock); return Number.isFinite(stock) && stock > 0 && stock <= 5 ? "بقي " + stock + " فقط" : ""; }

/* ── أنواع المنتجات: فردي (simple) | متغيّر (variable: سمات + تنويعات بسعر/مخزون/صورة لكل تنويع) | مجمّع (grouped: عدة منتجات فردية في صفحة واحدة) ── */
function productType(p){ return (p && (p.type === "variable" || p.type === "grouped")) ? p.type : "simple"; }
function activeVariations(p){ return ((p && p.variations) || []).filter(v=>v && v.active !== false); }
function varOut(v){ return v.stock !== undefined && v.stock !== null && Number(v.stock) <= 0; }
function variationLabel(p, v){ return ((p && p.attributes) || []).filter(a=>a.variation && v && v.attrs && v.attrs[a.name] != null).map(a=>a.name + ": " + v.attrs[a.name]).join(" / "); }
function groupChildren(p){ return ((p && p.children) || []).map(sl=>PRODUCTS.find(x=>x.slug===sl)).filter(x=>x && productType(x)==="simple"); }
function minPrice(p){
  const t = productType(p);
  if(t==="variable"){ const vs = activeVariations(p); if(vs.length) return Math.min(...vs.map(v=>Number(v.price)||0)); }
  if(t==="grouped"){ const cs = groupChildren(p); if(cs.length) return Math.min(...cs.map(c=>Number(c.price)||0)); }
  return Number(p && p.price) || 0;
}
function hasPriceRange(p){
  const t = productType(p), mn = minPrice(p);
  if(t==="variable") return activeVariations(p).some(v=>(Number(v.price)||0) !== mn);
  if(t==="grouped") return groupChildren(p).some(c=>(Number(c.price)||0) !== mn);
  return false;
}
function itemOut(it){
  const p = PRODUCTS.find(x=>x.slug===it.slug); if(!p) return false;
  if(it.vid){ const v = (p.variations||[]).find(x=>x.id===it.vid); return !v || v.active===false || varOut(v); }
  return isOutOfStock(p);
}

/* ── السلة ── */
const Cart = {
  key: "store_cart_v1",
  all(){ try{ return JSON.parse(localStorage.getItem(this.key))||[] }catch(e){ return [] } },
  save(items){ localStorage.setItem(this.key, JSON.stringify(items)); Cart.render() },
  /* unitPrice = السعر الفعلي للقطعة (إجمالي العرض ÷ عدد القطع) — كان يُمرَّر إجمالي العرض فيُضرب في الكمية ويظهر مجموع السلة مضاعفاً */
  add(slug, qty, unitPrice, vid, vlabel){
    const p = PRODUCTS.find(p=>p.slug===slug);
    if(p && p.digital){ toast("💾 المنتج الرقمي يُشترى مباشرة من صفحته (دفع مسبق وتسليم تلقائي)"); try{ if(!/\/p\/[^/]+\/?$/.test(location.pathname) || location.pathname.indexOf(slug)<0) location.href = productHref(p); }catch(e){} return }   // لا يدخل السلة: سلة التوصيل والدفع عند الاستلام لا تناسبه
    if(p && p.mpId){ toast("🛒 هذا المنتج يُطلب مباشرة من صفحته (يتحقق من توفره لدى المورّد)"); try{ if(!/\/p\/[^/]+\/?$/.test(location.pathname) || location.pathname.indexOf(slug)<0) location.href = productHref(p); }catch(e){} return }   // منتج التسويق بالعمولة: يُشترى من صفحته فقط
    if(p && itemOut({slug, vid})){ toast("⚠️ نفدت كمية هذا المنتج حالياً"); return }
    const items = Cart.all();
    const ex = items.find(i => i.slug===slug && Math.abs(i.price-unitPrice) < 1e-6 && (i.vid||"")===(vid||""));
    if(ex) ex.qty += qty; else { const it = {slug, qty, price: unitPrice}; if(vid){ it.vid = vid; it.vlabel = vlabel||""; } items.push(it); }
    Cart.save(items);
    try{ trackEvent("AddToCart", { slug, title: p ? p.title : slug, qty, value: Math.round(unitPrice * qty) }); }catch(e){}
    toast(`تمت إضافة «${p?p.title:slug}${vlabel?" — "+vlabel:""}» إلى السلة ✓`);
  },
  setQty(idx, delta){
    const items = Cart.all();
    if(!items[idx]) return;
    items[idx].qty += delta;
    if(items[idx].qty<=0) items.splice(idx,1);
    Cart.save(items);
  },
  remove(idx){ const items=Cart.all(); items.splice(idx,1); Cart.save(items) },
  clear(){ Cart.save([]) },
  count(){ return Cart.all().reduce((s,i)=>s+i.qty,0) },
  subtotal(){ return Cart.all().reduce((s,i)=>s+Math.round(i.qty*i.price),0) },
  render(){
    document.querySelectorAll(".cart-count").forEach(el=>el.textContent = Cart.count());
    const box = document.getElementById("cart-items");
    if(!box) return;
    const items = Cart.all();
    box.innerHTML = items.length ? items.map((it,idx)=>{
      const p = PRODUCTS.find(p=>p.slug===it.slug) || it;
      const img = p.cover || (p.images&&p.images[0]) || "";
      const oos = itemOut(it);
      return `<div class="citem">
        <img src="${REL}${img}" alt="">
        <div class="t">${p.title}${it.vlabel?' — <small>'+it.vlabel+'</small>':""}${oos?' <b style="color:var(--red)">— نفدت الكمية 🚫</b>':""}<br><small style="color:var(--muted)">${fmt(Math.round(it.price))} / وحدة</small></div>
        <div class="qty"><button onclick="Cart.setQty(${idx},-1)">−</button><b>${it.qty}</b><button onclick="Cart.setQty(${idx},1)" ${oos?"disabled":""}>+</button></div>
      </div>`;
    }).join("") : `<p style="text-align:center;color:var(--muted);padding:2rem 0">السلة فارغة 🛒</p>`;
    const sub = Cart.subtotal();
    const fee = Cart.fee();
    const disc = currentCartDiscount(sub, couponCartItems());
    const discount = disc.discount;
    const totEl = document.getElementById("cart-total");
    if(totEl) totEl.textContent = fmt(Math.max(0, sub - discount) + (items.length?fee:0));
    let autoMsg = document.getElementById("cart-auto-disc-msg");
    if(!autoMsg && totEl){ autoMsg = document.createElement("div"); autoMsg.id = "cart-auto-disc-msg"; autoMsg.style.cssText = "font-size:.82rem;color:var(--green,#16834a);margin:.25rem 0"; totEl.insertAdjacentElement("afterend", autoMsg); }
    if(autoMsg) autoMsg.textContent = disc.autoDiscount > 0 ? "🎉 " + disc.message + " — خصم " + fmt(disc.autoDiscount) : "";
    const feeEl = document.getElementById("cart-fee");
    const sq = Cart.quote();
    try{ const cw = document.getElementById("cwilaya"), cc = document.getElementById("ccommune"), w0 = cw && WILAYAS.find(x=>x.id == cw.value), t0 = document.querySelector('input[name="cdtype"]:checked');
      if(w0 && cc) labelCommunes(cc, w0, (ww, c)=>{ const q = shipQuote(ww, c, t0 ? t0.value : "home", Cart.subtotal(), cartShipCo(Cart.all()), cartShipPf(Cart.all()), cartShipAdj(Cart.all())); return q.blocked ? null : ((items.every(cartItemFreeShip) || couponFreeShip() || q.free) ? 0 : q.fee); }); }catch(e){}
    if(feeEl){ feeEl.title = sq.msg || ""; feeEl.textContent = items.length ? (sq.blocked ? "غير متاح ⛔" : ((fee===0 && (items.every(cartItemFreeShip) || couponFreeShip() || sq.free)) ? "مجاني 🚚" : fmt(fee))) : "—"; }
    let sm = document.getElementById("cart-ship-msg");
    if(!sm && feeEl){ sm = document.createElement("div"); sm.id = "cart-ship-msg"; sm.style.cssText = "color:var(--red,#c0392b);font-size:.85rem;margin:.3rem 0;font-weight:700"; (feeEl.closest("div")||feeEl.parentNode).appendChild(sm); }
    if(sm) sm.textContent = items.length ? sq.msg : "";
    try{ if(window.Upsell && Upsell.ready()){ const tb = totEl && (totEl.closest(".tot") || totEl.parentNode); if(tb) Upsell.cartSync(tb); } }catch(e){}   // Order Bump في السلة
  },
  fee(){
    const _all = Cart.all(); if(_all.length && (_all.every(cartItemFreeShip) || couponFreeShip())) return 0;   // كل منتجات السلة بشحن مجاني
    const w = document.getElementById("cwilaya");
    const t = document.querySelector('input[name="cdtype"]:checked');
    if(!w || !w.value) return 0;
    const wl = WILAYAS.find(x=>x.id==w.value);
    if(!wl) return 0;
    return Cart.quote().fee || 0;
  },
  quote(){
    const w = document.getElementById("cwilaya"), t = document.querySelector('input[name="cdtype"]:checked'), c = document.getElementById("ccommune");
    const wl = w && w.value ? WILAYAS.find(x=>x.id==w.value) : null;
    return shipQuote(wl, c ? c.value : "", t ? t.value : "home", Cart.subtotal(), cartShipCo(Cart.all()), cartShipPf(Cart.all()), cartShipAdj(Cart.all()));
  },
  async checkout(){
    const items = Cart.all();
    if(!items.length){ toast("السلة فارغة"); return }
    const oosItem = items.filter(itemOut).map(it=>PRODUCTS.find(p=>p.slug===it.slug))[0];
    if(oosItem){ toast(`⚠️ «${oosItem.title}» نفدت كميته — يرجى إزالته من السلة`); return }
    const name = ((document.getElementById("cname") || {}).value || "").trim();
    const phone = ((document.getElementById("cphone") || {}).value || "").trim();
    const wId = (document.getElementById("cwilaya") || {}).value;
    const commune = ((document.getElementById("ccommune") || {}).value || "").trim();
    const dtype = (document.querySelector('input[name="cdtype"]:checked') || {}).value || "home";
    if(!name || !phone || !wId){ toast("يرجى ملء الاسم، الهاتف والولاية"); return }
    if(PhoneDZ.on && !PhoneDZ.ok(PhoneDZ.norm(phone))){ toast(PhoneDZ.MSG); (function(e){ if(e) e.focus(); })(document.getElementById("cphone")); return }
    const wl = WILAYAS.find(x=>x.id==wId);
    const __sq = Cart.quote(); if(__sq.blocked){ toast(__sq.msg); return }
    const sub = Cart.subtotal();
    const fee = Cart.fee();
    const disc = currentCartDiscount(sub, couponCartItems());
    const discount = disc.discount;
    const total = Math.max(0, sub - discount) + fee;
    const __cgrp = (window.Upsell && Upsell.hasType("post")) ? Upsell.gid() : "";
    // Enregistrement dans Google Sheets
    const __pre = (Guard.active() && waAutoOn()) ? window.open("", "_blank") : null;      // يُفتح فوراً (ضمن نقرة الزبون) قبل انتظار فحص الخادم
    const __order = {
      name, phone, wilaya: wl.name, commune, dtype,
      items: items.map(it => { const p = PRODUCTS.find(p=>p.slug===it.slug)||it;
        return { slug: it.slug, title: p.title + (it.vlabel ? " — " + it.vlabel : ""), qty: it.qty, price: Math.round(it.price) }; }),
      subtotal: sub, fee, total,
      coupon: AppliedCoupon.record && (disc.couponDiscount > 0 || couponFreeShip() || couponGiftTitle()) ? AppliedCoupon.code : "", discount, promo: (AppliedCoupon.record && disc.couponDiscount > 0 && AppliedCoupon.record.__promo) ? AppliedCoupon.code : undefined,
      extra: Object.assign({}, couponGiftTitle() ? { "🎁 هدية": couponGiftTitle() } : {}, disc.autoDiscount > 0 ? { "🤖 خصم تلقائي": disc.message } : {}, items.some(it=>it.up) ? { "➕ إضافة سريعة": (items.find(it=>it.up).upt || ""), "🆔 قاعدة العرض": items.find(it=>it.up).up } : {}, __cgrp ? { "🧺 مجموعة": __cgrp } : {}, PageSrc ? { "📄 الصفحة": PageSrc } : {}, (fee > 0 && __sq.sup > 0 && fee === __sq.fee) ? { "🚚 تفصيل التوصيل": (fee - __sq.sup) + "+" + __sq.sup } : {}, (fee > 0 && __sq.adj && fee === __sq.fee) ? { "🎁 دعم الشحن": String(__sq.adj) } : {}, (window.GeoPin && GeoPin.link()) ? { "📍 الموقع": GeoPin.link() } : {}, Attrib),
    };
    const __pfr = window.PFOrder ? PFOrder.prep(__order) : "";
    if(Guard.active()){ const gr = await Guard.submit(__order); if(!gr.ok){ if(__pre) __pre.close(); toast(gr.msg); return } } else API.submitOrder(__order);
    Gifts.markUsed(AppliedCoupon.record); markCouponPhoneUsed(AppliedCoupon.record, phone);
    try{ if(window.PFOrder) PFOrder.send(__order, __pfr, items.map(it=>({ slug: it.slug, vid: it.vid || "", qty: it.qty, price: it.price, title: it.slug }))); }catch(e){}
    let msg = `السلام عليكم ${SITE_NAME}، أريد تأكيد طلبي:\n`;
    items.forEach(it=>{
      const p = PRODUCTS.find(p=>p.slug===it.slug)||it;
      msg += `\n• ${p.title}${it.vlabel?" — "+it.vlabel:""} ×${it.qty} = ${fmt(Math.round(it.price*it.qty))}`;
    });
    msg += `\n\nالمجموع: ${fmt(sub)}`;
    if(discount>0) msg += disc.autoDiscount > 0 ? `\n🎉 ${disc.message}: -${fmt(discount)}` : `\n🎟️ خصم الكود (${AppliedCoupon.code}): -${fmt(discount)}`;
    else if(couponFreeShip()) msg += `\n🎟️ كود التوصيل المجاني (${AppliedCoupon.code})`;
    if(couponGiftTitle()) msg += `\n🎁 هدية الكود (${AppliedCoupon.code}): ${couponGiftTitle()}`;
    msg += `\nالتوصيل (${dtype==="stop"?"مكتب":"للمنزل"} - ${wl.name}${commune?" / "+commune:""}): ${fmt(fee)}`;
    msg += `\n*الإجمالي: ${fmt(total)}*`;
    msg += `\n\nالاسم: ${name}\nالهاتف: ${phone}`;
    try{ const f0 = items[0] && (PRODUCTS.find(x=>x.slug===items[0].slug) || items[0]); trackEvent("Lead", { slug: items[0] && items[0].slug, title: f0 && f0.title, qty: items.reduce((a,i)=>a+i.qty,0), value: total }); if(f0) firePixelPurchase(f0, total, items.reduce((a,i)=>a+i.qty,0)); }catch(e){}
    if(waAutoOn()) Guard.openWa(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`, __pre);
    Thanks.show({ name, total, up: { customer:{ name, phone, wilaya: wl.name, commune, dtype }, slugs: items.map(i=>i.slug), cats: items.map(i=>{ const q = PRODUCTS.find(x=>x.slug===i.slug); return q ? q.cat : ""; }), total, grp: __cgrp, page: PageSrc || "" }, lines: items.map(it=>{ const q = PRODUCTS.find(x=>x.slug===it.slug)||it; return q.title + (it.qty>1?" ×"+it.qty:""); }), wa: `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}` });
  }
};

function toast(t){
  let el = document.getElementById("toast");
  if(!el){ el=document.createElement("div"); el.id="toast";
    el.style.cssText="position:fixed;bottom:100px;right:50%;transform:translateX(50%);background:var(--green);color:#fff;padding:.7rem 1.4rem;border-radius:999px;font-weight:800;z-index:99;box-shadow:var(--shadow-lg);transition:.3s";
    document.body.appendChild(el); }
  el.textContent=t; el.style.opacity=1; el.style.bottom="110px";
  clearTimeout(el._t);
  el._t=setTimeout(()=>{el.style.opacity=0;el.style.bottom="100px"},2400);
}

/* ════════ بكسلات التتبع (فيسبوك / تيك توك / جوجل) — تُدار من لوحة التحكم admin.html ════════
   تُقرأ من assets/data/pixels.json عند كل تحميل صفحة (رئيسية أو منتج)، ثم تُثبَّت أكواد
   التتبع الأساسية (PageView) لكل بكسل مفعّل ومُتاح على هذه الصفحة، ويُسجَّل حدث «شراء»
   تلقائياً عند نجاح تأكيد الطلب في صفحة أي منتج مفعّل عليه البكسل. */
let __pixelsCache = null;
async function loadPixels(){
  if(__pixelsCache) return __pixelsCache;
  try{
    const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/pixels.json", {cache:"no-store"});
    __pixelsCache = r.ok ? await r.json() : [];
  }catch(e){ __pixelsCache = []; }
  return __pixelsCache;
}
function currentProductSlugFromUrl(){
  { const q = location.search.match(/[?&]p=([a-z0-9-]+)/i); if(q && /[?&]embed=1/.test(location.search) && /order-embed\.html$/.test(location.pathname)) return q[1]; }   // صفحة النموذج المستقلة
  const m = location.pathname.match(/\/p\/([a-z0-9-]+)\/?/i);
  if(m) return m[1];
  /* الرابط النظيف: example.com/<slug>/ */
  const f = location.pathname.split("/").filter(Boolean)[0];
  return f && typeof PRODUCTS !== "undefined" && PRODUCTS.some(p=>p.slug===f) ? f : null;
}
function pixelApplies(px, slug){
  if(!px || px.active===false) return false;
  if(!px.scope || px.scope === "all") return true;
  return Array.isArray(px.scope) && !!slug && px.scope.includes(slug);
}
function injectGtagBase(id){
  if(window.__gtagBaseLoaded) return;
  window.__gtagBaseLoaded = true;
  const s = document.createElement("script");
  s.async = true; s.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(id);
  document.head.appendChild(s);
  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function(){ dataLayer.push(arguments); };
  gtag("js", new Date());
}
function injectPixelBase(px){
  if(px.platform === "facebook"){
    if(!window.fbq){
      /* كود فيسبوك بكسل الرسمي (Meta Events Manager) */
      (function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
      n.push=n;n.loaded=!0;n.version="2.0";n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)})(window,
      document,"script","https://connect.facebook.net/en_US/fbevents.js");
    }
    fbq("init", px.pixelId);
    fbq("track", "PageView");
  } else if(px.platform === "tiktok"){
    if(!window.ttq){
      /* كود تيك توك بكسل الرسمي (TikTok Events Manager) */
      (function (w, d, t) {
        w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"];
        ttq.setAndDefer=function(tq,e){tq[e]=function(){tq.push([e].concat(Array.prototype.slice.call(arguments,0)))}};
        for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);
        ttq.instance=function(t2){for(var e=ttq._i[t2]||[],n=0;n<e.length;n++)ttq.setAndDefer(e,e.methods[n]);return e};
        ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};
          var o=d.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;
          var a=d.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};
      })(window, document, "ttq");
    }
    ttq.load(px.pixelId);
    ttq.page();
  } else if(px.platform === "ga4" || px.platform === "google_ads"){
    injectGtagBase(px.pixelId);
    gtag("config", px.pixelId);
  }
}
/* داخل إطار نموذج صفحة الهبوط: إن كانت الصفحة الأم تتولّى البكسلات (lp-pixels.js) نمرّر الأحداث إليها بدل تحميل البكسل هنا (يمنع تكرار PageView والأحداث) */
function __pxParent(){ try{ return window.parent !== window && /[?&]embed=1/.test(location.search) && window.parent.__pbPx === true; }catch(e){ return false; } }
async function initPixels(){
  if(__pxParent()){ window.__activePixels = []; window.__pxReady = true; const q0 = window.__pxq || []; window.__pxq = []; q0.forEach(x=>trackEvent(x[0], x[1])); return; }
  try{
    const pixels = await loadPixels();
    const slug = currentProductSlugFromUrl();
    window.__activePixels = pixels.filter(px=>pixelApplies(px, slug));
    window.__activePixels.forEach(px=>{
      try{ injectPixelBase(px); }catch(e){ console.error("pixel init error", px.id, e); }
    });
  }catch(e){ /* تجاهل — البكسلات ليست حرجة لعمل الموقع */ }
  window.__pxReady = true; const q = window.__pxq || []; window.__pxq = []; q.forEach(x=>trackEvent(x[0], x[1]));
}
/* أحداث القمع (لجنة الخبراء v1.89.132): ViewContent / AddToCart / InitiateCheckout / Lead — تُحفظ في طابور إن لم تكن البكسلات جاهزة بعد */
const __PX_EVENTS = {
  ViewContent:      { facebook:"ViewContent",      tiktok:"ViewContent",      ga4:"view_item" },
  AddToCart:        { facebook:"AddToCart",        tiktok:"AddToCart",        ga4:"add_to_cart" },
  InitiateCheckout: { facebook:"InitiateCheckout", tiktok:"InitiateCheckout", ga4:"begin_checkout" },
  Lead:             { facebook:"Lead",             tiktok:"SubmitForm",       ga4:"generate_lead" }
};
function trackEvent(name, d){
  if(!window.__pxReady){ (window.__pxq = window.__pxq || []).push([name, d]); return }
  d = d || {};
  if(__pxParent()){ try{ window.parent.postMessage({ pbPx: { name, d: JSON.parse(JSON.stringify(d)) } }, location.origin); }catch(e){} return; }
  (window.__activePixels || []).forEach(px=>{
    try{
      const m = __PX_EVENTS[name]; if(!m) return;
      const currency = px.currency || "DZD", val = Number(d.value) || 0, qty = Number(d.qty) || 1;
      if(px.platform === "facebook" && window.fbq){
        fbq("track", m.facebook, { value: val, currency, content_ids: d.slug ? [d.slug] : [], content_type:"product", contents: d.slug ? [{ id: d.slug, quantity: qty }] : [] }, d.eventId ? { eventID: d.eventId } : undefined);
      } else if(px.platform === "tiktok" && window.ttq){
        ttq.track(m.tiktok, { value: val, currency, content_id: d.slug || "", content_type:"product", quantity: qty });
      } else if(px.platform === "ga4" && window.gtag){
        gtag("event", m.ga4, { value: val, currency, items: d.slug ? [{ item_id: d.slug, item_name: d.title || d.slug, quantity: qty, price: val }] : [] });
      }
    }catch(e){ console.error("pixel event error", name, px.id, e); }
  });
}
/* يُستدعى عند نجاح تأكيد الطلب (زر «تأكيد الطلب») في initProduct أدناه */
/* قيمة حدث الشراء حسب إعداد البكسل: إجمالي الطلب (افتراضي) أو سعر المنتجات بدون رسوم التوصيل */
function pxPurchaseValue(px, total, fee){ const t = Number(total) || 0; return px && px.valueMode === "products" ? Math.max(0, t - (Number(fee) || 0)) : t; }
function firePixelPurchase(p, total, qty, orderId, fee){
  if(__pxParent()){ try{ window.parent.postMessage({ pbPx: { name: "Purchase", d: { slug: p && p.slug, title: p && p.title, value: total, qty, orderId, fee: Number(fee) || 0 } } }, location.origin); }catch(e){} return; }
  (window.__activePixels||[]).forEach(px=>{
    try{
      const currency = px.currency || "DZD", val = pxPurchaseValue(px, total, fee);
      if(px.platform === "facebook" && window.fbq){
        fbq("track", "Purchase", { value: val, currency, content_ids:[p.slug], content_type:"product", contents:[{id:p.slug, quantity: qty}] });
      } else if(px.platform === "tiktok" && window.ttq){
        ttq.track("CompletePayment", { value: val, currency, content_id: p.slug, content_type:"product", quantity: qty });
      } else if(px.platform === "google_ads" && window.gtag){
        gtag("event", "conversion", { send_to: px.pixelId + (px.conversionLabel ? ("/" + px.conversionLabel) : ""), value: val, currency, transaction_id: String(orderId || Date.now()) });
      } else if(px.platform === "ga4" && window.gtag){
        gtag("event", "purchase", { value: val, currency, transaction_id: String(orderId || Date.now()), items:[{item_id:p.slug, item_name:p.title, quantity: qty, price: val}] });
      }
    }catch(e){ console.error("pixel purchase error", px.id, e); }
  });
}

/* ════════ مظهر الموقع (الخطوط/الألوان/الشعار) — تُدار من لوحة التحكم admin.html ⟵ المظهر ════════ */
let __themeCache = null;
async function loadTheme(){
  if(__themeCache) return __themeCache;
  try{
    const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/theme.json", {cache:"no-store"});
    __themeCache = r.ok ? await r.json() : null;
  }catch(e){ __themeCache = null; }
  return __themeCache;
}
function applyTheme(theme){
  if(!theme || typeof theme !== "object") return;
  try{
    if(theme.fontUrl && !((/[?&]embed=1/.test(location.search) || document.getElementById("cairo-local")) && /family=Cairo/.test(theme.fontUrl)) && ![...document.querySelectorAll('link[rel="stylesheet"]')].some(l=>l.href === theme.fontUrl)){   // لا تكرار إن كان الخط محمّلاً في <head>
      const link = document.createElement("link");
      link.rel = "stylesheet"; link.href = theme.fontUrl;
      document.head.appendChild(link);
    }
    const c = theme.colors || {};
    const map = { bg:"--bg", card:"--card", ink:"--ink", muted:"--muted", green:"--green", green2:"--green-2", gold:"--gold", gold2:"--gold-2", red:"--red", ok:"--ok", line:"--line" };
    const rootVars = Object.entries(map).filter(([k])=>c[k]).map(([k,v])=>v+":"+c[k]).join(";");
    let css = "";
    if(rootVars) css += ":root{" + rootVars + "}";
    if(theme.fontFamily) css += "body{font-family:" + theme.fontFamily + "!important}";
    if(theme.fontSize) css += "body{font-size:" + theme.fontSize + "}";
    if(theme.fontWeight) css += "body{font-weight:" + theme.fontWeight + "}";
    if(theme.logo && theme.logo.url){
      const w = theme.logo.width || "150px", h = theme.logo.height || "46px";
      css += ".logo{font-size:0!important;line-height:0;background:url('" + (typeof REL!=="undefined"?REL:"") + theme.logo.url + "') no-repeat center/contain;display:inline-block;width:" + w + ";height:" + h + "}";
    }
    if(!css) return;
    const st = document.createElement("style");
    st.id = "__store_theme_override";
    st.textContent = css;
    document.head.appendChild(st);
  }catch(e){ /* تجاهل — المظهر ليس حرجاً لعمل الموقع */ }
}
async function initTheme(){
  try{
    const theme = await loadTheme();
    applyTheme(theme);
    // إعدادات SEO الخاصة بالصفحة الرئيسية فقط (تُضبط من لوحة التحكم ⟵ المظهر) — تُطبَّق هنا لأن
    // initTheme() يُستدعى من كل الصفحات، ونتحقق من وجود #grid (خاص بالرئيسية فقط) قبل التطبيق
    if(theme && document.getElementById("grid")){
      applySeoTags({
        title: theme.seoTitle || "",
        description: theme.seoDesc || "",
        image: (theme.logo && theme.logo.url) ? theme.logo.url : "",
        type: "website",
      });
    }
  }catch(e){ /* تجاهل */ }
}

/* ════════ نموذج الطلب (واتساب/الأزرار/الحقول الإضافية/الألوان/العروض) — تُدار من لوحة التحكم ⟵ نموذج الطلب ════════
   تُقرأ من assets/data/checkout.json وتُطبَّق على كل صفحة (رقم واتساب، إظهار/إخفاء الأزرار، النصوص، الألوان)؛
   حقول «العروض» و«الحقول الإضافية» و«تسميات الحقول» تُطبَّق داخل initProduct() لأنها خاصة بصفحة المنتج فقط. */
let __checkoutCache = null;
/* فتح واتساب تلقائياً بعد تسجيل الطلب (الافتراضي مفعّل؛ يُطفأ من «نموذج الطلب» في اللوحة: waAuto=false). زر «إرسال الطلب على واتساب» في صفحة الشكر يبقى. */
function waAutoOn(){ return !(__checkoutCache && __checkoutCache.waAuto === false); }
async function loadCheckout(){
  if(__checkoutCache) return __checkoutCache;
  try{
    const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/checkout.json", {cache:"no-store"});
    __checkoutCache = r.ok ? await r.json() : null;
  }catch(e){ __checkoutCache = null; }
  return __checkoutCache;
}
function applyCheckoutColors(colors){
  if(!colors || typeof colors !== "object") return;
  try{
    let css = "";
    if(colors.orderBg || colors.orderText){
      css += ".btn-order{" + (colors.orderBg?("background:"+colors.orderBg+"!important;border-color:"+colors.orderBg+"!important;"):"") + (colors.orderText?("color:"+colors.orderText+"!important;"):"") + "}";
    }
    if(colors.waBg || colors.waText){
      css += ".btn-wa{" + (colors.waBg?("background:"+colors.waBg+"!important;border-color:"+colors.waBg+"!important;"):"") + (colors.waText?("color:"+colors.waText+"!important;"):"") + "}";
    }
    if(colors.cartBg || colors.cartText){
      css += ".btn-cart2{" + (colors.cartBg?("background:"+colors.cartBg+"!important;border-color:"+colors.cartBg+"!important;"):"") + (colors.cartText?("color:"+colors.cartText+"!important;"):"") + "}";
    }
    if(!css) return;
    const st = document.createElement("style");
    st.id = "__store_checkout_colors";
    st.textContent = css;
    document.head.appendChild(st);
  }catch(e){ /* تجاهل */ }
}
function applyCheckout(cfg){
  if(!cfg || typeof cfg !== "object") return;
  try{
    if(cfg.waNumber){
      const digits = String(cfg.waNumber).replace(/[^\d]/g,"");
      if(digits) WA_NUMBER = digits;
    }
    // إعادة كتابة كل روابط واتساب الثابتة في الصفحة بنفس الرقم الجديد (مع الحفاظ على نص الرسالة بعد الرقم)
    document.querySelectorAll('a[href*="wa.me/"]').forEach(a=>{
      const href = a.getAttribute("href") || "";
      const m = href.match(/wa\.me\/\d*(.*)$/);
      if(m) a.setAttribute("href", "https://wa.me/" + WA_NUMBER + (m[1]||""));
    });
    // إظهار/إخفاء زر «الطلب مباشرة عبر واتساب» (الاختصار المباشر + زر CTA الثانوي)
    if(cfg.showWhatsappBtn === false){
      document.querySelectorAll(".btn-wa, .lp-btn-green").forEach(a=>{ a.style.display = "none"; });
    }
    // إظهار/إخفاء زر «أضف إلى السلة»
    if(cfg.showAddToCart === false){
      document.querySelectorAll("#add-cart").forEach(b=>{ b.style.display = "none"; });
    }
    // نصوص الأزرار المخصصة
    const orderBtn = document.querySelector("#order-form .btn-order, .order-wide .btn-order") || document.querySelector(".btn-order");
    if(orderBtn && cfg.orderBtnText){
      const span = orderBtn.querySelector("#btn-total");
      orderBtn.innerHTML = cfg.orderBtnText + ' — <span id="btn-total">' + (span?span.textContent:"") + '</span>';
    }
    if(cfg.whatsappBtnText){
      document.querySelectorAll(".btn-wa").forEach(a=>{ a.textContent = cfg.whatsappBtnText; });
    }
    const cartBtn = document.getElementById("add-cart");
    if(cartBtn && cfg.cartBtnText) cartBtn.textContent = cfg.cartBtnText;
    // تسميات الحقول (الاسم/الهاتف/البلدية) — تُطبَّق هنا أيضاً لأنها ثابتة في HTML قبل استبدال initProduct لحقل البلدية
    if(cfg.fieldLabels){
      Object.entries(cfg.fieldLabels).forEach(([id,label])=>{
        if(!label) return;
        const input = document.getElementById(id);
        const field = input ? input.closest(".field") : null;
        const lbl = field ? field.querySelector("label") : null;
        if(lbl){
          const req = /\*\s*$/.test(lbl.textContent) ? " *" : "";
          lbl.textContent = label + req;
        }
      });
    }
    applyCheckoutColors(cfg.colors);
  }catch(e){ /* تجاهل — إعدادات نموذج الطلب ليست حرجة لعمل الموقع */ }
}
/* ═══ الطلب بمراحل (مساعد تسهيل ملء النموذج) — يُفعَّل من لوحة التحكم ⟵ نموذج الطلب (checkout.json: steps:true) ═══
   طبقة فوق نموذج الطلب الحالي بلا إعادة رسم: تُخفي/تُظهر مجموعات الحقول نفسها (فلا تضيع أي بيانات عند الرجوع، ولا تُعاد الصفحة):
   1) الولاية ثم البلدية (ونوع التوصيل/المكتب)  2) اختيار العرض + رسوم التوصيل والمجموع فوراً  3) الاسم والهاتف  4) مراجعة ثم تأكيد الطلب.
   «اطلب الآن» يمرّر بسلاسة إلى المرحلة الحالية. لا تعمل مع المنتجات المتغيّرة/المجمَّعة/الرقمية أو النافدة (يبقى النموذج العادي). الاختبار: scripts/test-order-steps.js */
/* أخطاء الحقول داخل النموذج: الخانة تحمرّ فوراً مع رسالة واضحة تحتها (بدل رسالة المتصفح أو التنبيه العابر) — تُستعمل في النموذج العادي والطلب بمراحل */
const FieldErr = (() => {
  const CSS = `.fe-bad.fe-bad.fe-bad{border-color:#d92d20!important;background-color:rgba(217,45,32,.07)!important;box-shadow:0 0 0 3px rgba(217,45,32,.16)!important}
.fe-box{outline:2px solid #d92d20;outline-offset:3px;border-radius:14px}
.fe-msg{display:flex;align-items:flex-start;gap:.4rem;margin:.35rem 0 .1rem;padding:.3rem .6rem;border-radius:8px;background:#fef3f2;border:1px solid #fecdca;color:#b42318;font-size:.84rem;font-weight:700;line-height:1.55}
.fe-msg::before{content:"!";flex:none;width:17px;height:17px;margin-top:.1rem;border-radius:50%;background:#d92d20;color:#fff;font-size:.72rem;font-weight:800;display:grid;place-items:center}
.fe-shake{animation:fesh .35s}@keyframes fesh{20%{transform:translateX(5px)}40%{transform:translateX(-5px)}60%{transform:translateX(3px)}80%{transform:translateX(-3px)}}
.field:has(>.fe-msg) .phone-hint{display:none}
@media(prefers-reduced-motion:reduce){.fe-shake{animation:none}}`;
  let inj = false; const css = () => { if (inj) return; inj = true; try { const st = document.createElement("style"); st.id = "fe-css"; st.textContent = CSS; document.head.appendChild(st); } catch (e) { } };
  const host = el => el.closest(".field") || el.parentNode;
  function clear(el) { if (!el) return; el.classList.remove("fe-bad", "fe-box", "fe-shake"); el.removeAttribute("aria-invalid"); if (el._fe) { try { el._fe.remove(); } catch (e) { } el._fe = null; } }
  function mark(el, msg, box) {
    if (!el) return; css(); clear(el); el.classList.add(box ? "fe-box" : "fe-bad"); void el.offsetWidth; el.classList.add("fe-shake"); if (!box) el.setAttribute("aria-invalid", "true");
    const m = document.createElement("div"); m.className = "fe-msg"; m.setAttribute("role", "alert"); m.textContent = msg;
    if (box) el.insertAdjacentElement("afterend", m); else host(el).appendChild(m); el._fe = m;
    if (!el._feL) { el._feL = 1; const c = () => clear(el); (el.tagName === "SELECT" ? ["input", "change"] : ["input"]).forEach(ev => el.addEventListener(ev, c)); /* حقل نصي: حدث change يُطلَق عند فقدان التركيز فقط (لا يُزيل الخطأ) */ if (box) el.addEventListener("click", c); }
  }
  function clearAll(root) { try { (root || document).querySelectorAll(".fe-bad,.fe-box").forEach(clear); } catch (e) { } }
  function show(errs) {
    if (!errs || !errs.length) return; errs.forEach(x => mark(x.el, x.msg, x.box));
    const f = errs[0].el; try { f.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth", block: "center" }); if (!errs[0].box && f.focus) f.focus({ preventScroll: true }); } catch (e) { }
  }
  return { mark, clear, clearAll, show };
})();
/* قواعد التحقق المشتركة: scope = 0 (الكل) أو رقم المرحلة 1 / 3؛ opt.ship=false لمنتج رقمي بلا توصيل */
const FormCheck = {
  star(form) { try { const l = form.querySelector('label[for="commune"]'); if (l && !/\*/.test(l.textContent)) l.textContent = l.textContent.trim() + " *"; } catch (e) { } },
  list(form, scope, opt) {
    const q = id => form.querySelector("#" + id), out = [], add = (el, msg) => { if (el) out.push({ el, msg }); }, all = !scope, ship = !(opt && opt.ship === false);
    if (ship && (all || scope === 1)) {
      const w = q("wilaya"); if (w && !w.value) add(w, "ادخل الولاية — اختر ولايتك من القائمة");
      const dw = q("desk-wrap"), dk = q("desk"); if (dw && dk && dw.style.display !== "none" && !dk.value) add(dk, "اختر مكتب التوصيل");
      const c = q("commune"); if (c && !c.value && c.options.length > 1 && c.getClientRects().length) add(c, "اختر البلدية");      // البلدية إجبارية متى وُجدت قائمتها
    }
    if (all || scope === 3) {
      const nm = q("name"), ph = q("phone");
      if (nm && nm.value.trim().length < 2) add(nm, nm.value.trim() ? "الاسم قصير — اكتب اسمك الكامل" : "ادخل الاسم الكامل");
      if (ph) { const v = ph.value.trim(); if (!v) add(ph, "ادخل رقم الهاتف"); else if (typeof PhoneDZ !== "undefined" && PhoneDZ.on) { if (!PhoneDZ.ok(PhoneDZ.norm(v))) add(ph, "رقم الهاتف خاطئ — 10 أرقام تبدأ بـ 05 أو 06 أو 07 (أرقام فقط)"); } else if (v.replace(/\D/g, "").length < 9) add(ph, "رقم الهاتف خاطئ"); }
      form.querySelectorAll('[id^="extra-"]').forEach(e => { if ((e.required || e.dataset.req) && !String(e.value).trim()) add(e, "هذا الحقل مطلوب"); });
    }
    return out;
  }
};
const OrderSteps = (() => {
  /* الطلب بمرحلتين تراكميتين: (1) الولاية + البلدية + العرض + السعر مع التوصيل  (2) الاسم والهاتف وزر التأكيد تُضاف تحت الأولى ولا تحجبها */
  const $ = id => document.getElementById(id);
  const S = { on: false, step: 1, max: 1, form: null, groups: [], bar: null, top: null, hint: null, hint2: null, offs: null, nav: null, next: null, stage2: [], done: false, why: "" };
  const LBL = ["السعر والتوصيل", "بياناتك"];
  const HINT = [
    "بعد اختيار <b>الولاية والبلدية والعرض</b> يظهر <b>السعر مع تكلفة التوصيل</b> فوراً. ويمكنك التوصيل إلى المنزل أو إلى مكتب شركة التوصيل (غالباً أرخص).",
    "اكتب <b>اسمك</b> و<b>رقم هاتفك</b> (10 أرقام تبدأ بـ 05 أو 06 أو 07) ليتصل بك فريقنا لتأكيد الطلب. تدفع عند الاستلام ولا نطلب أي دفع مسبق."
  ];
  const SEL1 = '#wilaya,#commune,#desk,#desk-wrap,input[name="dtype"],.dtype,.geopin,[data-geopin]';
  const SEL3 = '#name,#phone,[id^="extra-"]';
  const SEL2 = '.coupon-box,.total-box,#fee,#grand,.bump,.ups-bump,[id^="bump"]';
  const SEL4 = 'button[type="submit"],.btn-order,.btn-wa,.btn-cart2,#add-cart,.cod-note';
  const has = (c, sel) => c.matches(sel) || !!c.querySelector(sel);
  const CSS = `.os-hide{display:none!important}
.os-bar{display:flex;gap:.35rem;align-items:center;justify-content:space-between;margin:.6rem 0 .5rem;direction:rtl}
.os-st{flex:1;display:flex;flex-direction:column;align-items:center;gap:.2rem;background:none;border:0;cursor:pointer;font:inherit;color:inherit;opacity:.55;padding:0;min-width:0}
.os-st i{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-weight:800;font-size:.9rem;border:2px solid currentColor}
.os-st small{font-size:.74rem;font-weight:700;white-space:nowrap}
.os-st.done{opacity:.9}.os-st.done i{background:var(--os-ac,#d4af37);border-color:var(--os-ac,#d4af37);color:var(--os-ac-t,#1a1a1a)}
.os-st.on{opacity:1}.os-st.on i{background:var(--os-ac,#d4af37);border-color:var(--os-ac,#d4af37);color:var(--os-ac-t,#1a1a1a);box-shadow:0 0 0 4px rgba(255,255,255,.12)}
.os-ln{flex:0 0 14px;height:2px;background:currentColor;opacity:.3;margin-bottom:1rem}
.os-hint{margin:.2rem 0 .8rem;padding:.6rem .8rem;border-radius:12px;border:1px dashed rgba(255,255,255,.35);font-size:.92rem;line-height:1.8}
.os-h{font-weight:800;font-size:1.02rem;margin:.5rem 0 .35rem}
.os-offs{display:grid;gap:.5rem;margin:.3rem 0 .8rem}
.os-off{display:flex;gap:.7rem;align-items:center;text-align:start;padding:.75rem .9rem;border-radius:14px;border:2px solid rgba(255,255,255,.28);background:transparent;color:inherit;font:inherit;cursor:pointer;width:100%}
.os-off i{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid currentColor;position:relative}
.os-off.on{border-color:var(--os-ac,#d4af37);box-shadow:0 0 0 2px var(--os-ac,#d4af37) inset}.os-off.on i::after{content:"";position:absolute;inset:3px;border-radius:50%;background:var(--os-ac,#d4af37)}
.os-off span{flex:1;min-width:0;display:flex;justify-content:space-between;gap:.6rem;flex-wrap:wrap;align-items:center}.os-off b{white-space:nowrap}
.os-nav{display:flex;gap:.6rem;margin-top:.9rem;direction:rtl}.os-nav button{flex:1;padding:.85rem 1rem;font:inherit;font-weight:800;cursor:pointer;border-radius:12px}
.os-fade{animation:osf .28s ease}@keyframes osf{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@media(prefers-reduced-motion:reduce){.os-fade{animation:none}}`;
  /* تصنيف أبناء النموذج المباشرين إلى مرحلتين (1: توصيل/عرض/سعر، 2: بيانات/تأكيد)؛ يعيد null إن اختلطتا في عنصر واحد (فيُترك النموذج العادي) */
  function classify(form) {
    const out = []; let last = 1, mixed = false;
    Array.from(form.children).forEach(c => {
      if (c.classList.contains("os-top") || c.classList.contains("os-nav") || c.classList.contains("os-offs") || c.classList.contains("os-hint")) return;
      if (c.tagName === "INPUT" && c.type === "hidden") return;
      const a = has(c, SEL1) || has(c, SEL2), z = has(c, SEL3) || c.matches(SEL4) || !!c.querySelector('.btn-order,button[type="submit"]');
      if (a && z) mixed = true;
      if (!a && !z) {
        if (/^H[1-6]$/.test(c.tagName)) { out.push({ el: c, stage: 0, title: true }); return; }
        if (/^(INPUT|SELECT|TEXTAREA)$/.test(c.tagName) || c.querySelector("input:not([type=hidden]),select,textarea")) { last = 2; out.push({ el: c, stage: 2 }); return; }
        out.push({ el: c, stage: last }); return;      // نص/ملاحظة تتبع ما قبلها
      }
      last = a ? 1 : 2; out.push({ el: c, stage: last });
    });
    return mixed ? null : out;
  }
  function unsupported() {
    if (!$("order-form") || !$("wilaya")) return "no-form"; if (document.querySelector(".oos-warning")) return "oos"; if ($("variants") || $("group-box")) return "variants";
    if (document.querySelector('[data-digital],#digital-pay,.digital-checkout,#dg-box')) return "digital"; return "";
  }
  /* n=1: الولاية/البلدية/المكتب + العرض؛ n=2: الاسم والهاتف والحقول الإضافية */
  function validate(n) {
    const errs = FormCheck.list(S.form, n === 2 ? 3 : 1);
    if (n === 1) { const of = $("offers"); if (of && (of.style.display !== "none" || S.origHidden) && of.querySelector(".offer") && !of.querySelector(".offer.on")) errs.push({ el: S.offs, msg: "اختر العرض المناسب", box: true }); }
    return errs.length ? { ok: false, msg: errs[0].msg, el: errs[0].el, all: errs } : { ok: true, all: [] };
  }
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const sigOf = () => Array.from(document.querySelectorAll("#offers .offer")).map(o => o.textContent.replace(/\s+/g, " ").trim()).join("|");
  function syncOffers() {
    if (!S.offs) return; const src = document.querySelectorAll("#offers .offer"); S.offs.querySelectorAll(".os-off").forEach((b, i) => b.classList.toggle("on", !!(src[i] && src[i].classList.contains("on"))));
  }
  function buildOffers() {
    S.sig = sigOf(); const of = $("offers"); if (of && of.style.display === "none" && !S.origHidden) { S.offs.innerHTML = ""; if (S.h2) S.h2.classList.add("os-hide"); return; } if (S.h2) S.h2.classList.remove("os-hide");
    const src = document.querySelectorAll("#offers .offer"); S.offs.innerHTML = "";
    src.forEach((o, i) => {
      const q = o.querySelector(".q"), p = o.querySelector(".p"), b = document.createElement("button"); b.type = "button"; b.className = "os-off";
      const ws = x => x.replace(/[ \t\r\n\f]+/g, " ").trim(), t = q ? ws(q.textContent) : ws(o.textContent), pr = p ? ws(p.textContent) : "";      /* لا نحوّل المسافة الضيّقة U+202F في «1 800» إلى مسافة عادية: تفصل الرقم في اتجاه RTL فيظهر «800 1» */
      const bd = o.querySelector(".badge,.tag,.best,.save,small"); const extra = bd && bd !== q && bd !== p ? ws(bd.textContent) : "";
      b.innerHTML = "<i></i><span><span>" + esc(t) + (extra ? ' <small style="opacity:.8">' + esc(extra) + "</small>" : "") + "</span><b>" + esc(pr) + "</b></span>";
      b.addEventListener("click", () => { o.click(); setTimeout(syncOffers, 30); }); S.offs.appendChild(b);
    }); syncOffers();
  }
  function show(n, opt) {
    n = n >= 2 ? 2 : 1; const was = S.step; S.started = true; S.step = n; S.max = Math.max(S.max, n);
    S.stage2.forEach(el => { el.classList.toggle("os-hide", n < 2); if (n === 2 && was < 2) { el.classList.remove("os-fade"); void el.offsetWidth; el.classList.add("os-fade"); } });
    S.nav.classList.toggle("os-hide", n >= 2);
    S.bar.querySelectorAll(".os-st").forEach((b, i) => { b.classList.toggle("on", i + 1 === n); b.classList.toggle("done", i + 1 < n); b.setAttribute("aria-current", i + 1 === n ? "step" : "false"); });
    if (n === 2 && was < 2 && !(opt && opt.noScroll)) { try { S.hint2.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion:reduce)").matches ? "auto" : "smooth", block: "start" }); } catch (e) { } }
  }
  function next() { const v = validate(1); if (!v.ok) { FieldErr.show(v.all); return false; } FieldErr.clearAll(S.form); show(2); return true; }
  function goTo(n) { if (n <= 1) { if (S.step >= 2) { try { S.bar.scrollIntoView({ behavior: "smooth", block: "start" }); } catch (e) { } } return; } if (S.step < 2) return next(); }
  function build(form) {
    const groups = classify(form); if (!groups) { S.why = "mixed"; return false; }
    const s1 = groups.filter(g => g.stage === 1), s2 = groups.filter(g => g.stage === 2);
    if (!s1.some(g => has(g.el, "#wilaya")) || !s2.some(g => has(g.el, "#name,#phone")) || !s2.some(g => g.el.matches(SEL4) || g.el.querySelector('.btn-order,button[type="submit"]'))) { S.why = "incomplete"; return false; }
    S.form = form; S.groups = groups;
    if (!$("os-css")) { const st = document.createElement("style"); st.id = "os-css"; st.textContent = CSS; document.head.appendChild(st); }
    const sb = form.querySelector(".btn-order,button[type=submit]"); const accent = () => { try { const cs = getComputedStyle(sb); if (cs.backgroundColor && cs.backgroundColor !== "rgba(0, 0, 0, 0)" && cs.backgroundColor !== "transparent") return cs.backgroundColor; const m = String(cs.backgroundImage).match(/rgba?\([^)]*\)|#[0-9a-fA-F]{3,8}/); return m ? m[0] : "#d4af37"; } catch (e) { return "#d4af37"; } };
    if (sb) { try { form.style.setProperty("--os-ac", accent()); form.style.setProperty("--os-ac-t", getComputedStyle(sb).color || "#1a1a1a"); } catch (e) { } }
    /* قائمة العروض الأصلية داخل إطار صفحة الهبوط تُستبدل بقائمة المرحلة 1 */
    { const eo = $("offers"); if (eo && /[?&]embed=/.test(location.search) && eo.style.display !== "none") { eo.style.setProperty("display", "none", "important"); S.origHidden = true; } }
    const top = document.createElement("div"); top.className = "os-top"; S.top = top;
    S.bar = document.createElement("div"); S.bar.className = "os-bar"; S.bar.innerHTML = LBL.map((l, i) => '<button type="button" class="os-st" data-os-go="' + (i + 1) + '"><i>' + (i + 1) + "</i><small>" + l + "</small></button>").join('<span class="os-ln"></span>');
    S.hint = document.createElement("div"); S.hint.className = "os-hint"; S.hint.innerHTML = HINT[0];
    S.hint2 = document.createElement("div"); S.hint2.className = "os-hint"; S.hint2.innerHTML = HINT[1];
    S.offs = document.createElement("div"); S.offs.className = "os-offs"; top.append(S.bar, S.hint);
    S.h1 = document.createElement("div"); S.h1.className = "os-h"; S.h1.textContent = "اختر ولايتك"; S.h2 = document.createElement("div"); S.h2.className = "os-h"; S.h2.textContent = "اختر العرض المناسب"; FormCheck.star(form);
    S.nav = document.createElement("div"); S.nav.className = "os-nav"; S.next = document.createElement("button"); S.next.type = "button"; S.next.className = "os-next"; S.next.textContent = "متابعة: أدخل بياناتك ↓"; S.nav.appendChild(S.next);
    try { const cs = getComputedStyle(sb || S.next); S.next.style.backgroundColor = cs.backgroundColor; if (cs.backgroundImage && cs.backgroundImage !== "none") S.next.style.backgroundImage = cs.backgroundImage; S.next.style.color = cs.color; S.next.style.border = cs.border; S.next.style.borderRadius = cs.borderRadius; S.next.style.boxShadow = cs.boxShadow; S.next.style.fontFamily = cs.fontFamily; } catch (e) { }
    /* إعادة ترتيب النموذج: العنوان ← الشريط ← [ولاية/بلدية] ← العروض ← بقية المرحلة 1 (توصيل، كوبون، السعر مع التوصيل) ← زر المتابعة ← [اسم/هاتف ← تأكيد] */
    const t = groups.find(g => g.title); if (t) t.el.insertAdjacentElement("afterend", top); else form.insertBefore(top, form.firstChild);
    let ref = top; const place = el => { ref.insertAdjacentElement("afterend", el); ref = el; };
    const cg = s1.find(g => has(g.el, "#commune")) || s1.find(g => has(g.el, "#wilaya")), wg = s1.find(g => has(g.el, "#wilaya"));
    s1.forEach(g => { if (g === wg) place(S.h1); place(g.el); if (g === cg) { place(S.h2); place(S.offs); } });
    place(S.nav); place(S.hint2); s2.forEach(g => place(g.el));
    S.stage2 = [S.hint2].concat(s2.map(g => g.el));
    S.next.addEventListener("click", next);
    form.addEventListener("click", e => { const a = e.target.closest && e.target.closest("[data-os-go]"); if (a) { e.preventDefault(); goTo(+a.dataset.osGo); } });
    form.addEventListener("keydown", e => { if (String(e.key || "") === "Enter" && S.step < 2 && /^(INPUT|SELECT)$/.test(e.target.tagName)) { e.preventDefault(); next(); } });
    form.addEventListener("submit", e => {
      if (S.step < 2) { e.preventDefault(); e.stopImmediatePropagation(); next(); return; }
      const errs = validate(1).all.concat(validate(2).all); if (errs.length) { e.preventDefault(); e.stopImmediatePropagation(); FieldErr.show(errs); }
    }, true);
    try { const of = $("offers"); if (of) new MutationObserver(() => { if (sigOf() !== S.sig) buildOffers(); else syncOffers(); }).observe(of, { attributes: true, subtree: true, attributeFilter: ["class"], childList: true, characterData: true }); } catch (e) { }
    /* «اطلب الآن»: تمرير سلس إلى النموذج دون تحميل صفحة */
    document.addEventListener("click", e => { const a = e.target.closest && e.target.closest('a[href="#order-form"],a[href="#pb-order"],.aly-buybar .bb-btn'); if (!a || !S.on) return; if (form.contains(a)) return; e.preventDefault(); try { S.bar.scrollIntoView({ behavior: "smooth", block: "start" }); } catch (x) { location.hash = "#order-form"; } }, true);
    buildOffers(); S.on = true; show(1, { noScroll: true }); return true;
  }
  function init(cfg) {
    if (S.done || !cfg) return;
    /* تفضيل الصفحة (مطوّر الصفحات): "1" مفعّل، "0" معطّل، وإلا فإعداد المتجر */
    let ov = ""; try { const m = location.search.match(/[?&]oc=([^&]+)/); if (m) ov = String((JSON.parse(decodeURIComponent(m[1])) || {}).st || ""); } catch (e) { }
    if (!ov) { try { const fm = document.getElementById("order-form"), w = fm && fm.closest("[data-ost]"); if (w) ov = w.getAttribute("data-ost") || ""; } catch (e) { } }
    const want = ov === "1" ? true : ov === "0" ? false : cfg.steps === true;
    if (!want) return; S.done = true; let tries = 0;
    const attempt = () => {
      const f = $("order-form"), w = $("wilaya"); const ready = f && w && w.options.length > 1 && (!$("offers") || $("offers").querySelector(".offer"));
      if (!ready) { if (++tries < 40) return setTimeout(attempt, 150); S.why = "timeout"; return; }
      const why = unsupported(); if (why) { S.why = why; return; } try { build(f); } catch (e) { S.why = "error:" + (e && e.message); S.on = false; }
    }; attempt();
  }
  return { init, go: goTo, state: S, _t: { classify } };
})();

async function initCheckout(){
  try{
    const cfg = await loadCheckout();
    applyCheckout(cfg);
    Guard.init(cfg && cfg.guard);
    PhoneDZ.setup(cfg);
    try{ OrderSteps.init(cfg); }catch(e){ /* الطلب بمراحل اختياري */ }
  }catch(e){ /* تجاهل */ }
  try{ applyStore(await loadStore()); }catch(e){ /* تجاهل */ }
  try{ siteGate(); }catch(e){ /* تجاهل */ }
}
/* حالة الاشتراك: الموقع الذي أغلقته المنصة (خمول/انتهاء اشتراك/قرار إداري) تظهر فيه رسالة بدل المتجر للزوار؛ أي فشل اتصال = المتجر يعمل.
   المدير (store_admin_on) لا تُحجب عنه الصفحات. للتعطيل: CONFIG.SAAS_GATE = false */
async function siteGate(){
  if(/[?&]embed=1/.test(location.search)) return;   // الصفحة الأم تتحقق
  if(/\/admin(\.html)?\/?$/.test(location.pathname) || localStorage.getItem("store_admin_on") === "1") return;
  const C = (typeof CONFIG !== "undefined" && CONFIG) || {}; if(C.SAAS_GATE === false) return;
  const url = String(C.SAAS_URL || "https://YOUR_PROJECT_REF.supabase.co").replace(/\/+$/, ""), key = C.SAAS_KEY || "sb_publishable_1ZtNDbkZ0uLFEdJeGkX0mw_zwXVI59h";
  let st = null; try{ const c = JSON.parse(localStorage.getItem("store_gate") || "null"); if(c && Date.now() - c.t < 18e5) st = c.s; }catch(e){}
  if(!st){
    try{
      const r = await fetch(url + "/rest/v1/rpc/saas_site_status", {method:"POST", headers:{apikey:key, Authorization:"Bearer " + key, "Content-Type":"application/json"}, body:JSON.stringify({p:{origin:location.origin}})});
      if(!r.ok) return; const j = await r.json(); st = {known:!!j.known, status:j.status || ""};
      try{ localStorage.setItem("store_gate", JSON.stringify({t:Date.now(), s:st})); }catch(e){}
    }catch(e){ return; }
  }
  if(!st.known || st.status !== "suspended" || document.getElementById("store-closed")) return;
  const d = document.createElement("div"); d.id = "store-closed";
  d.style.cssText = "position:fixed;inset:0;z-index:2147483001;background:#0b1511;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;font-family:inherit";
  const h = document.createElement("h1"); h.style.cssText = "font-size:1.6rem;margin:0"; h.textContent = "هذا المتجر متوقف مؤقتاً";
  const p = document.createElement("p"); p.style.cssText = "max-width:480px;line-height:1.9;margin:0;opacity:.9"; p.textContent = "إن كنت صاحب المتجر فادخل إلى لوحة التحكم أو تواصل مع الدعم لإعادة التفعيل.";
  d.append(h, p); document.body.appendChild(d);
}
/* إعدادات المتجر (assets/data/store.json، من لوحة التحكم ← إعدادات الموقع): الاسم، واتساب، انستغرام، اللغة، العملة، وضع الصيانة */
async function loadStore(){
  try{ const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/store.json", {cache:"no-store"}); return r.ok ? await r.json() : null; }catch(e){ return null; }
}
function applyStore(c){
  if(!c || typeof c !== "object") return;
  window.STORE = c;
  try{
    if(typeof CONFIG !== "undefined" && CONFIG.SITE){
      if(c.name) CONFIG.SITE.name = c.name;
      if(c.instagram) CONFIG.SITE.instagram = String(c.instagram).replace(/^@/,"");
      if(!c.instagram && c.social && c.social.instagram){ try{ CONFIG.SITE.instagram = decodeURIComponent(new URL(c.social.instagram).pathname.split("/").filter(Boolean).pop()||"").replace(/^@/,""); }catch(e){} }
    }
    if(c.currency) window.__STORE_CUR = c.currency;
    if(c.lang && /^(ar|fr|en|es|de|tr)$/.test(c.lang)) document.documentElement.lang = c.lang;
    const wa = String(c.wa || "").replace(/[^\d]/g,"");
    if(wa){
      WA_NUMBER = wa;
      document.querySelectorAll('a[href*="wa.me/"]').forEach(a=>{ const m = (a.getAttribute("href")||"").match(/wa\.me\/\d*(.*)$/); if(m) a.setAttribute("href", "https://wa.me/" + WA_NUMBER + (m[1]||"")); });
    }
    if(c.maintenance && !/\/admin(\.html)?\/?$/.test(location.pathname) && localStorage.getItem("store_admin_on") !== "1" && !document.getElementById("store-maint")){
      const d = document.createElement("div"); d.id = "store-maint";
      d.style.cssText = "position:fixed;inset:0;z-index:2147483000;background:#0b1511;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;font-family:inherit";
      const h = document.createElement("h1"); h.style.cssText = "font-size:1.6rem;margin:0"; h.textContent = c.name || "الموقع";
      const p = document.createElement("p"); p.style.cssText = "max-width:480px;line-height:1.9;margin:0;opacity:.9"; p.textContent = c.maintMsg || "الموقع تحت الصيانة حالياً، نعود إليكم قريباً.";
      d.append(h, p); document.body.appendChild(d);
    }
  }catch(e){ /* تجاهل */ }
}

/* ════════ حقول SEO (عنوان/وصف/صورة meta لكل صفحة) — تُحقن ديناميكياً عبر وسوم og و twitter ════════
   العنوان والوصف الأساسيان (title/meta description) مكتوبان مسبقاً في كل صفحة HTML يدوياً؛ هذه
   الدالة تُضيف فوقهما وسوم og/twitter (غير موجودة حالياً) لتحسين المشاركة على فيسبوك/واتساب/تويتر،
   وتستبدل العنوان/الوصف الافتراضيين فقط إذا ضُبط حقل SEO مخصص من لوحة التحكم */
function setMetaTag(attr, key, content){
  if(!content) return;
  let el = document.querySelector('meta[' + attr + '="' + key + '"]');
  if(!el){ el = document.createElement("meta"); el.setAttribute(attr, key); document.head.appendChild(el); }
  el.setAttribute("content", content);
}
function applySeoTags(opts){
  opts = opts || {};
  if(opts.title) document.title = opts.title;
  if(opts.description) setMetaTag("name", "description", opts.description);
  const finalTitle = document.title || "";
  const descEl = document.querySelector('meta[name="description"]');
  const finalDesc = opts.description || (descEl ? descEl.getAttribute("content") : "") || "";
  let finalImage = "";
  if(opts.image){
    try{ finalImage = new URL((typeof REL!=="undefined"?REL:"") + opts.image, location.href).href; }catch(e){ finalImage = ""; }
  }
  setMetaTag("property", "og:title", finalTitle);
  setMetaTag("property", "og:description", finalDesc);
  if(finalImage) setMetaTag("property", "og:image", finalImage);
  setMetaTag("property", "og:type", opts.type || "website");
  setMetaTag("property", "og:url", location.href);
  setMetaTag("name", "twitter:card", finalImage ? "summary_large_image" : "summary");
  setMetaTag("name", "twitter:title", finalTitle);
  setMetaTag("name", "twitter:description", finalDesc);
  if(finalImage) setMetaTag("name", "twitter:image", finalImage);
}


/* Merchant managed SEO metadata; applied on product pages only. */
const Seo = (() => {
  let configPromise = null;
  async function config(){
    if(!configPromise) configPromise=fetch((typeof REL!=="undefined"?REL:"")+"assets/data/seo.json",{cache:"no-store"}).then(r=>r.ok?r.json():{}).catch(()=>({}));
    return configPromise;
  }
  function absolute(src){try{return src?new URL((src.startsWith("http://")||src.startsWith("https://")||src.startsWith("data:"))?src:(typeof REL!=="undefined"?REL:"")+src,location.href).href:"";}catch(e){return "";}}
  function setRobotsNoindex(){let tag=document.querySelector('meta[name="robots"]');if(!tag){tag=document.createElement("meta");tag.name="robots";document.head.appendChild(tag);}tag.content="noindex";}
  async function apply(p){
    if(!p||!p.slug)return;
    const cfg=await config(),record=(cfg.products&&cfg.products[p.slug])||{};
    const site=(typeof CONFIG!=="undefined"&&CONFIG.SITE)||{},brand=cfg.siteTitle||site.name||"";
    const title=p.seoTitle||record.title||[p.title,brand].filter(Boolean).join(" | ");
    const description=p.seoDesc||record.desc||p.desc||cfg.siteDesc||"";
    const image=p.seoImg||record.ogImage||p.cover||(p.images&&p.images[0])||cfg.ogImage||"";
    applySeoTags({title,description,image,type:"product"});
    const kws=[p.seoFocus,p.seoKw].map(x=>String(x||"").trim()).filter(Boolean).join(", ");
    if(kws)setMetaTag("name","keywords",kws);
    if(image.startsWith("http://")||image.startsWith("https://")){setMetaTag("property","og:image",image);setMetaTag("name","twitter:image",image);}
    const skipped=!!p.noindex||(Array.isArray(cfg.noindex)?cfg.noindex:[]).map(x=>String(x).replace(/^https?:\/\/[^/]+/i,"").replace(/^\/+|\/+$/g,"")).some(x=>x===p.slug||x==="p/"+p.slug);
    if(skipped)setRobotsNoindex();else{const managed=document.querySelector('meta[name="robots"][data-seo-managed="1"]');if(managed)managed.remove();}
    const images=(p.images&&p.images.length?p.images:[image]).map(absolute).filter(Boolean);
    const out=typeof isOutOfStock==="function"&&isOutOfStock(p);
    const schema={"@context":"https://schema.org","@type":"Product",name:p.title||title,description,image:images,url:location.href,sku:p.slug,offers:{"@type":"Offer",price:Number(p.price)||0,priceCurrency:"DZD",availability:out?"https://schema.org/OutOfStock":"https://schema.org/InStock",url:location.href}};
    let ld=document.querySelector('script[type="application/ld+json"][data-seo-product]');if(!ld){ld=document.createElement("script");ld.type="application/ld+json";ld.dataset.seoProduct="1";document.head.appendChild(ld);}ld.textContent=JSON.stringify(schema);
  }
  return {apply};
})();

/* ════════ أكواد الخصم (Coupons) — تُدار من لوحة التحكم admin.html ⟵ أكواد الخصم ════════
   تُقرأ من assets/data/coupons.json (ملف عام — راجع الملاحظة في admin.html)، ويُحقن حقل إدخال
   الكود ديناميكياً في صفحة المنتج ودرج السلة عبر الدالتين أدناه، دون الحاجة لتعديل كل صفحة HTML. */
let __couponsCache = null;
async function loadCoupons(){
  if(__couponsCache) return __couponsCache;
  try{
    const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/coupons.json", {cache:"no-store"});
    __couponsCache = r.ok ? await r.json() : [];
  }catch(e){ __couponsCache = []; }
  return __couponsCache;
}
function findValidCoupon(list, code, subtotal, items){
  const c = (list||[]).find(x=>x.code && x.code.toUpperCase()===String(code||"").trim().toUpperCase());
  if(!c) return { ok:false, msg:"⚠️ الكود غير صحيح" };
  if(c.active===false) return { ok:false, msg:"⚠️ هذا الكود غير مفعّل حالياً" };
  const now = Date.now(), from = c.from ? new Date(c.from + "T00:00:00").getTime() : 0, to = c.to ? new Date(c.to + "T23:59:59").getTime() : c.expiresAt ? new Date(c.expiresAt).getTime() : 0;
  if(from && now < from) return { ok:false, msg:"⚠️ يبدأ هذا الكود في " + c.from };
  if(to && now > to) return { ok:false, msg:"⚠️ انتهت صلاحية هذا الكود" };
  const min = Number(c.min != null ? c.min : c.minOrder) || 0;
  if(min && subtotal < min) return { ok:false, msg:"⚠️ الحدّ الأدنى للطلب " + fmt(min) };
  const lines = Array.isArray(items) ? items : [];
  if(c.cats && c.cats.length && !lines.some(it=>(c.cats||[]).includes(it.cat))) return { ok:false, msg:"⚠️ لا ينطبق هذا الكود على فئات سلتك" };
  if(c.slugs && c.slugs.length && !lines.some(it=>(c.slugs||[]).includes(it.slug))) return { ok:false, msg:"⚠️ لا ينطبق هذا الكود على منتجات سلتك" };
  if(c.stack === false && lines.some(it=>Number(it.qty)>1 || Number(it.free)>0)) return { ok:false, msg:"⚠️ لا يمكن جمع هذا الكود مع عرض الكمية" };
  const eligible = lines.length && (c.cats && c.cats.length || c.slugs && c.slugs.length)
    ? lines.filter(it=>(!c.cats || !c.cats.length || c.cats.includes(it.cat)) && (!c.slugs || !c.slugs.length || c.slugs.includes(it.slug))).reduce((s,it)=>s+(Number(it.amount)||0),0)
    : subtotal;
  if(c.type==="freeship" || c.type==="gift") return { ok:true, coupon:c, discount:0 };      // توصيل مجاني / هدية منتج: بلا مبلغ خصم
  let discount = c.type==="percent" ? Math.round(eligible * Number(c.value)/100) : Math.min(Number(c.value)||0, eligible);
  if(c.type==="percent" && Number(c.max)>0) discount = Math.min(discount, Number(c.max));
  if(discount<=0) return { ok:false, msg:"⚠️ الكود غير صالح لهذا الطلب" };
  return { ok:true, coupon:c, discount };
}
/* حالة الكود المُطبَّق — مشتركة بين صفحة المنتج ودرج السلة (سياق واحد نشط في كل مرة عملياً) */
const AppliedCoupon = { code:"", record:null };
function couponCartItems(){ return (typeof Cart !== "undefined" ? Cart.all() : []).map(it=>{const p=PRODUCTS.find(x=>x.slug===it.slug)||{};return {slug:it.slug,cat:p.cat,qty:it.qty,amount:Number(it.qty)*Number(it.price)};}); }
function markCouponPhoneUsed(c, phone){ if(!c || !c.perPhone || !phone) return; try{ const k="store_coupon_phone_"+c.code.toUpperCase(), a=JSON.parse(localStorage.getItem(k)||"[]"), d=String(phone).replace(/\D/g,""); if(d&&!a.includes(d)){a.push(d);localStorage.setItem(k,JSON.stringify(a));} }catch(e){} }
function couponHasPreviousOrders(){ let prior=false; try{const recent=JSON.parse(localStorage.getItem("store_recent_orders")||"{}");prior=Object.keys(recent||{}).length>0;}catch(e){} try{const profile=typeof Account!=="undefined"&&Account.profile?Account.profile():null;prior=prior||!!(profile&&(Number(profile.ordersCount)>0||Number(profile.order_count)>0||(Array.isArray(profile.orders)&&profile.orders.length)));}catch(e){} return prior; }
function couponPhoneAlreadyUsed(c,phone){ if(!c||!c.perPhone||!phone)return false; try{const used=JSON.parse(localStorage.getItem("store_coupon_phone_"+c.code.toUpperCase())||"[]"),digits=String(phone).replace(/\D/g,"");return digits.length>=9&&used.includes(digits);}catch(e){return false;} }
function couponFreeShip(){ return !!(AppliedCoupon.record && AppliedCoupon.record.type==="freeship"); }
function couponGiftTitle(){
  const r = AppliedCoupon.record; if(!r || r.type!=="gift") return "";
  if(r.giftTitle) return r.giftTitle;
  const pr = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug===r.product) : null; return pr ? pr.title : (r.product||"");
}
function couponMsg(res){
  const c = res.coupon;
  return c.type==="freeship" ? "✅ تم تطبيق الكود — توصيل مجاني 🚚" : c.type==="gift" ? "✅ تم تطبيق الكود — هديتك: " + (c.giftTitle || (PRODUCTS.find(x=>x.slug===c.product)||{}).title || c.product) + " 🎁" : "✅ تم تطبيق الكود — خصم " + fmt(res.discount);
}
function currentCouponDiscount(subtotal, items){
  if(!AppliedCoupon.record || !subtotal) return 0;
  const res = findValidCoupon([AppliedCoupon.record], AppliedCoupon.code, subtotal, items);
  return res.ok ? res.discount : 0;
}

/* Automatic discounts (FR-DSC-3). Pure calculation is kept independent of the DOM. */
const AutoDisc = {
  rules: [],
  compute(cart, rules, coupon) {
    const now = new Date();
    const items = (Array.isArray(cart) ? cart : []).map(it => ({
      slug: String(it.slug || ""), cat: String(it.cat || ""),
      qty: Math.max(0, Math.floor(Number(it.qty) || 0)),
      price: Math.max(0, Number(it.price) || (Number(it.qty) ? Number(it.amount || 0) / Number(it.qty) : 0))
    })).filter(it => it.qty > 0);
    const subtotal = items.reduce((sum, it) => sum + it.qty * it.price, 0);
    const eligible = (it, selector) => {
      if (!selector || (!selector.slugs && !selector.cats)) return true;
      const slugs = Array.isArray(selector.slugs) ? selector.slugs : selector.slug ? [selector.slug] : [];
      const cats = Array.isArray(selector.cats) ? selector.cats : selector.cat ? [selector.cat] : [];
      return (!slugs.length && !cats.length) || slugs.includes(it.slug) || cats.includes(it.cat);
    };
    const active = (rule) => rule && rule.active !== false &&
      (!rule.from || new Date(rule.from + "T00:00:00").getTime() <= now.getTime()) &&
      (!rule.to || new Date(rule.to + "T23:59:59").getTime() >= now.getTime()) &&
      (!Number(rule.min) || subtotal >= Number(rule.min));
    const candidates = (Array.isArray(rules) ? rules : []).filter(active).map(rule => {
      let amount = 0;
      if (rule.kind === "bxgy") {
        const buyItems = items.filter(it => eligible(it, rule.buy));
        const buyQty = Math.max(1, Math.floor(Number(rule.buy && rule.buy.qty) || 1));
        const getQty = Math.max(1, Math.floor(Number(rule.get && rule.get.qty) || 1));
        const times = Math.floor(buyItems.reduce((n, it) => n + it.qty, 0) / (buyQty + getQty));
        const getSelector = rule.get && rule.get.same ? rule.buy : { slugs: rule.get && rule.get.slug ? [rule.get.slug] : [] };
        const getItems = items.filter(it => eligible(it, getSelector));
        let free = Math.min(times * getQty, getItems.reduce((n, it) => n + it.qty, 0));
        getItems.sort((a, b) => a.price - b.price);
        for (const it of getItems) {
          const n = Math.min(free, it.qty);
          amount += n * it.price * (Math.min(100, Math.max(0, rule.get && rule.get.percent != null ? Number(rule.get.percent) : 100)) / 100);
          free -= n;
          if (!free) break;
        }
      } else {
        const base = items.filter(it => eligible(it, rule)).reduce((n, it) => n + it.qty * it.price, 0);
        amount = rule.kind === "auto_percent"
          ? Math.round(base * Math.max(0, Number(rule.value) || 0) / 100)
          : rule.kind === "auto_fixed" ? Math.min(base, Math.max(0, Number(rule.value) || 0)) : 0;
      }
      return { rule, discount: Math.max(0, Math.min(subtotal, Math.round(amount))) };
    }).filter(x => x.discount > 0).sort((a, b) => b.discount - a.discount);
    const best = candidates[0] || null;
    const codeDiscount = Math.max(0, Math.min(subtotal, Math.round(Number(coupon && coupon.discount) || 0)));
    if (!best) return { discount: codeDiscount, autoDiscount: 0, couponDiscount: codeDiscount, rule: null, message: "" };
    const stack = best.rule.stack === true;
    if (stack) {
      const total = Math.min(subtotal, best.discount + codeDiscount);
      return { discount: total, autoDiscount: total - codeDiscount, couponDiscount: codeDiscount, rule: best.rule,
        message: String(best.rule.name || (best.rule.kind === "bxgy" ? "اشترِ واحصل على هدية" : "خصم تلقائي")) };
    }
    if (best.discount > codeDiscount) return { discount: best.discount, autoDiscount: best.discount, couponDiscount: 0, rule: best.rule,
      message: String(best.rule.name || (best.rule.kind === "bxgy" ? "اشترِ واحصل على هدية" : "خصم تلقائي")) };
    return { discount: codeDiscount, autoDiscount: 0, couponDiscount: codeDiscount, rule: null, message: "" };
  },
  load() {
    fetch((typeof REL!=="undefined"?REL:"") + "assets/data/autodisc.json", { cache: "no-store" }).then(r => r.ok ? r.json() : [])
      .then(data => { this.rules = Array.isArray(data) ? data : []; if (typeof Cart !== "undefined") Cart.render(); })
      .catch(() => { this.rules = []; });
  }
};
AutoDisc.load();
function currentCartDiscount(subtotal, items) {
  const codeDiscount = currentCouponDiscount(subtotal, items);
  const cart = (items || []).map(it => ({ ...it, price: Number(it.qty) ? Number(it.amount || 0) / Number(it.qty) : 0 }));
  return AutoDisc.compute(cart, AutoDisc.rules, { discount: codeDiscount });
}

function buildCouponBoxHTML(idPrefix){
  return '<div class="coupon-box" style="display:flex;gap:.4rem;margin:.6rem 0;align-items:center;flex-wrap:wrap">' +
    '<input id="' + idPrefix + '-coupon-input" placeholder="🎟️ كود الخصم (إن وُجد)" style="flex:1;min-width:120px;padding:.55rem .7rem;border:1.5px solid var(--line);border-radius:8px;font-family:inherit">' +
    '<button type="button" id="' + idPrefix + '-coupon-btn" class="btn-cart2" style="padding:.5rem .9rem;white-space:nowrap">تطبيق</button>' +
    '</div><div id="' + idPrefix + '-coupon-msg" style="font-size:.82rem;margin:-.3rem 0 .6rem;min-height:1.1em"></div>';
}
/* يُدرج صندوق كود الخصم قبل عنصر مرجعي (مربع الإجمالي)، ويربط منطق التطبيق بدالة إعادة الحساب rerender */
function injectCouponBox(idPrefix, beforeEl, getSubtotal, rerender, getItems){
  if(!beforeEl && !document.getElementById(idPrefix + "-coupon-input")) return;
  /* صفحات المنتجات الثابتة تحمل صندوق الكود جاهزاً في HTML (بلا أي معالج) — نربط المعالج به بدل الخروج، وإلا لا يعمل الكود إطلاقاً */
  if(!document.getElementById(idPrefix + "-coupon-input")){
    const wrap = document.createElement("div");
    wrap.innerHTML = buildCouponBoxHTML(idPrefix);
    while(wrap.firstChild) beforeEl.parentNode.insertBefore(wrap.firstChild, beforeEl);
  }
  const input = document.getElementById(idPrefix + "-coupon-input");
  if(input.dataset.bound) return; input.dataset.bound = "1";
  const msg = document.getElementById(idPrefix + "-coupon-msg");
  async function apply(){
    const code = (input.value||"").trim();
    if(!code){ AppliedCoupon.code=""; AppliedCoupon.record=null; msg.textContent=""; rerender(); return; }
    let list = (await loadCoupons()).concat(await Gifts.records());      // + هدايا الحساب (ترحيب/تثبيت) غير المستعملة
    /* كود شخصي (إعادة الشراء): ليس في الملف العام، يُفحص على الخادم مع رقم هاتف الطلب */
    if(!list.some(c=>String(c.code||"").toUpperCase() === code.toUpperCase())){
      const ph = (document.getElementById("phone") || document.getElementById("cphone") || {}).value || "";
      if(/^(BACK|PR|WEL|APP)-/i.test(code)){
        if(ph.replace(/\D/g, "").length < 9){ AppliedCoupon.code=""; AppliedCoupon.record=null; msg.textContent="📱 أدخل رقم هاتفك في النموذج أولاً — هذا الكود شخصي"; msg.style.color="var(--red)"; rerender(); return; }
        let pr = null; try{ pr = await API.promoCheck(code, ph); }catch(e){}
        if(pr && pr.ok) list = list.concat([{ code: code.toUpperCase(), type: pr.type, value: pr.value, minOrder: pr.minOrder, expiresAt: pr.expiresAt, active: true, __promo: true }]);
        else if(pr && pr.error){ AppliedCoupon.code=""; AppliedCoupon.record=null; msg.textContent = pr.error === "used" ? "⚠️ هذا الكود استُعمل من قبل" : pr.error === "expired" ? "⚠️ انتهت صلاحية هذا الكود" : "⚠️ هذا الكود غير صالح لهذا الرقم"; msg.style.color="var(--red)"; rerender(); return; }
      }
    }
    const lines = getItems ? getItems() : [];
    const candidate = list.find(c=>String(c.code||"").toUpperCase()===code.toUpperCase());
    if(candidate && candidate.firstOrder){
      if(couponHasPreviousOrders()){ AppliedCoupon.code=""; AppliedCoupon.record=null; msg.textContent="⚠️ هذا الكود مخصّص لأول طلب فقط"; msg.style.color="var(--red)"; rerender(); return; }
    }
    if(candidate && candidate.perPhone){
      const ph=(document.getElementById("phone")||document.getElementById("cphone")||{}).value||"", digits=ph.replace(/\D/g,"");
      if(digits.length<9){AppliedCoupon.code="";AppliedCoupon.record=null;msg.textContent="📱 أدخل رقم هاتفك للتحقق من هذا الكود";msg.style.color="var(--red)";rerender();return;}
      if(couponPhoneAlreadyUsed(candidate,ph)){AppliedCoupon.code="";AppliedCoupon.record=null;msg.textContent="⚠️ استُعمل هذا الكود من قبل لهذا الرقم";msg.style.color="var(--red)";rerender();return;}
    }
    const res = findValidCoupon(list, code, getSubtotal(), lines);
    if(!res.ok){
      AppliedCoupon.code=""; AppliedCoupon.record=null;
      msg.textContent = res.msg; msg.style.color = "var(--red)";
    }else{
      AppliedCoupon.code = res.coupon.code; AppliedCoupon.record = res.coupon;
      msg.textContent = couponMsg(res);
      msg.style.color = "var(--ok)";
    }
    rerender();
  }
  input.addEventListener("keydown", e=>{ if(e.key==="Enter"){ e.preventDefault(); apply(); } });
  document.getElementById(idPrefix + "-coupon-btn").onclick = apply;
  /* رابط يحمل ?code=XXXX (رسائل إعادة الشراء): يملأ الكود تلقائياً؛ الكود الشخصي BACK-/WEL-... يُطبَّق بعد إدخال الهاتف */
  try{
    const qc = (new URLSearchParams(location.search).get("code") || "").trim();
    if(qc && /^[A-Za-z0-9_-]{3,30}$/.test(qc) && !input.value){
      input.value = qc.toUpperCase();
      if(/^(BACK|PR|WEL|APP)-/i.test(qc)){
        const ph = document.getElementById("phone") || document.getElementById("cphone");
        if(ph){ const go = ()=>{ if(!AppliedCoupon.code && ph.value.replace(/\D/g, "").length >= 10){ ph.removeEventListener("input", go); apply(); } }; ph.addEventListener("input", go); go(); }
        msg.textContent = "🎟️ كودك الشخصي جاهز — أدخل رقم هاتفك ليُطبَّق تلقائياً"; msg.style.color = "var(--ok)";
      } else setTimeout(apply, 400);
    }
  }catch(e){}
}

/* ── صفحة المنتج ── */
function initProduct(slug){
  const p = PRODUCTS.find(p=>p.slug===slug);
  if(!p) return;
  /* تنبيه طبي لمنتجات الصحة (assets/data/med-notes.json): يظهر قبل نموذج الطلب */
  try{ fetch(REL + "assets/data/med-notes.json", {cache:"no-cache"}).then(r=>r.ok?r.json():null).then(j=>{
    if(!j || p.medNoteOff || !(p.medNote || (j.slugs||[]).includes(p.slug)) || document.getElementById("med-note")) return;
    let f = document.getElementById("order-form") || document.getElementById("pb-order"); if(!f) return;
    { const of = document.getElementById("offers"), os = of && /[?&]embed=/.test(location.search) ? of : null; if(os) f = os; }   // داخل الإطار: التنبيه فوق العروض لتبقى العروض فوق النموذج مباشرة
    const d = document.createElement("p"); d.id = "med-note"; d.textContent = p.medNote || j.text || "";
    d.style.cssText = "margin:.8rem 0;padding:.7rem .9rem;border:1px solid rgba(251,191,36,.45);border-radius:12px;background:rgba(245,158,11,.12);color:#fde68a;font-size:.88rem;line-height:1.7";
    f.parentNode.insertBefore(d, f);
  }).catch(()=>{}); }catch(e){}
  /* «مسار المنتج»: إن اختيرت صفحة هبوط لهذا المنتج فهي مساره الرئيسي، فيُحوَّل إليها أي دخول مباشر لصفحته (إعلان، واتساب، بحث، رابط محفوظ) بنفس معاملات الرابط؛ لا يُحوَّل داخل الإطارات والمعاينة، ولا مع ?noroute=1 للوصول للصفحة الأصلية */
  try{
    if(p.route && self===top && !/[?&](noroute|embed|preview)=/.test(location.search)){
      let pg = p.route, v = "";
      if(p.ab && p.ab.b){ const k = "store_ab_" + p.slug; let g = ""; try{ g = localStorage.getItem(k) || ""; }catch(e){} if(g !== "A" && g !== "B"){ g = Math.random()*100 < (Number(p.ab.pct)||50) ? "B" : "A"; try{ localStorage.setItem(k, g); }catch(e){} } if(g === "B") pg = p.ab.b; v = g; }
      const q = location.search + (v && !/[?&]ab=/.test(location.search) ? (location.search ? "&" : "?") + "ab=" + v : "");
      location.replace(REL + "lp/" + pg + "/" + q + location.hash); return;
    }
  }catch(e){}
  // العرض الافتراضي المُحدَّد مسبقاً هو نفسه العرض "الأكثر طلباً" (bestIdx) — قبل هذا التصحيح
  // كان يُحدَّد افتراضياً «قطعة واحدة» بينما شارة «الأكثر طلباً 🔥» تظهر على عرض آخر، ما يُشتّت الزبون
  const bestIdx = 2;
  const state = { offer: p.offers[bestIdx] || p.offers[0], wilaya:null, dtype:"home" };
  const outOfStock = isOutOfStock(p);

  function updateLowStockNote(variation){
    const pp = document.getElementById("pprice"); if(!pp || !pp.parentElement) return;
    let note = pp.parentElement.querySelector(".stk-note");
    const stockProduct = variation && variation.stock != null ? Object.assign({}, p, { stock:variation.stock }) : p;
    const text = lowStockNote(stockProduct);
    if(text){ if(!note){ note = document.createElement("small"); note.className = "stk-note"; pp.parentElement.appendChild(note); } note.textContent = text; }
    else if(note) note.remove();
  }
  updateLowStockNote();

  Seo.apply(p);

  // معرض الصور — تُقرأ دائماً من data.js (p.images) عند كل تحميل للصفحة، ولا تُترك
  // لتجمّد داخل HTML الثابت للصفحة، حتى تبقى متطابقة مع ما يُعدَّل من لوحة التحكم
  const staticGallery = !!document.querySelector(".gthumbs[data-static]");   // صفحات القالب الجديد: معرض مكتوب في الصفحة نفسها (يُعدَّل من اللوحة) ولا يتبع صور المنتج
  if(!staticGallery && !/[?&]embed=1/.test(location.search)){   // في التضمين (نموذج الطلب) لا معرض ولا تحميل صور
    const main = document.getElementById("gmain");
    const gthumbsEl = document.querySelector(".gthumbs");
    if(gthumbsEl) gthumbsEl.innerHTML = ""; // تفريغ أي صور مصغّرة ثابتة مضمّنة في HTML (تفادي التكرار)
    if(main && p.images && p.images[0]) main.src = REL + p.images[0]; // مزامنة الصورة الرئيسية مع أول صورة في المعرض (تفادي بقائها قديمة)
    p.images.forEach((src,i)=>{
      const th = document.createElement("img");
      th.src = REL+src; th.alt = p.title;
      if(i===0) th.classList.add("on");
      th.onclick = ()=>{ main.src=REL+src; document.querySelectorAll(".gthumbs img").forEach(x=>x.classList.remove("on")); th.classList.add("on"); };
      document.querySelector(".gthumbs").appendChild(th);
    });
  }

  // العروض — العرض المُحدَّد بصرياً (on) هو نفسه bestIdx المُفعَّل افتراضياً في state.offer أعلاه
  // للمنتج المتغيّر تُعاد أسعار العروض بنسبة سعر التنويع المختار إلى السعر الأساسي (p.price)
  const offersBox = document.getElementById("offers");
  const type = productType(p);
  let offerIdx = p.offers[bestIdx] ? bestIdx : 0;
  function buildOffers(){
    offersBox.innerHTML = ""; // تفريغ أي بطاقات عروض ثابتة مضمّنة في HTML (تفادي التكرار)
    const sc = (type==="variable" && state.variation && Number(p.price)>0) ? state.variation.price / p.price : 1;
    let ocI = null; try{ const m = location.search.match(/[?&]oc=([^&]+)/); ocI = m ? JSON.parse(decodeURIComponent(m[1])) : null; }catch(e){}
    const wantImg = !!ocI && ocI.ol === "i";      /* «بطاقات بالصور»: صورة المنتج في كل بطاقة عرض */
    (p.offers || []).forEach((o0,i)=>{
      const o = sc===1 ? o0 : Object.assign({}, o0, { price: Math.round(o0.price*sc) });
      const paid = o.qty - (o.free||0);
      const unit = Math.round(o.price/paid);
      const disc = Math.round((1 - o.price/(p.price*sc*paid))*100);
      const d = document.createElement("div");
      d.className = "offer"+(i===offerIdx?" on":"");
      const label = o.free ? "قطعتان + الثالثة 🎁" : (o.qty===1?"قطعة واحدة":o.qty===2?"قطعتان":o.qty+" قطع");
      const cov0 = p.cover || (p.images&&p.images[0]) || "", oimg = wantImg ? String((ocI.oi && ocI.oi[i]) || o.img || cov0).trim().replace(/^(\.\.?\/)+/, "") : "";      /* مسار نسبي بالنسبة لصفحة الهبوط (../../) يُقصّ لأن الإطار في الجذر */
      d.innerHTML = `${i===bestIdx?'<span class="best">الأكثر طلباً 🔥</span>':""}${oimg?`<img class="oi" src="${/^(https?:|data:|\/)/.test(oimg)?"":REL}${oimg}" onerror="if(!this.dataset.f&&this.dataset.c){this.dataset.f=1;this.src=this.dataset.c}else{this.style.display='none'}" data-c="${REL}${cov0}" alt="" loading="lazy" decoding="async">`:""}
        <div class="q">${label}</div>
        <div class="p">${fmt(o.price)}</div>
        <div class="u">${fmt(unit)} للقطعة ${disc>0?`· وفر ${disc}%`:""}${o.free?'<br><b style="color:var(--ok)">مجاناً داخل العرض</b>':""}${offerFreeShip(p,o)?'<br><b style="color:var(--ok)">🚚 شحن مجاني</b>':""}</div>`;
      d.onclick = ()=>{
        offerIdx = i; state.offer = o;
        document.querySelectorAll(".offer").forEach(x=>x.classList.remove("on"));
        d.classList.add("on");
        update();
      };
      offersBox.appendChild(d);
      if(i===offerIdx) state.offer = o;
    });
  }
  buildOffers();

  /* ── منتج متغيّر: اختيار السمات (لون/مقاس...) ثم يتحدد التنويع بسعره ومخزونه وصورته ── */
  const attrEsc = t => String(t).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;");
  function heroPrice(priceTxt, old){
    const pp = document.getElementById("pprice"), po = document.getElementById("pold"), ps = document.getElementById("psave");
    if(!pp) return;
    pp.textContent = priceTxt;
    const has = old && old.value > old.price;
    if(po){ po.textContent = has ? fmt(old.value) : ""; po.style.display = has ? "" : "none"; }
    if(ps){ ps.textContent = has ? "وفّر " + Math.round((1-old.price/old.value)*100) + "%" : ""; ps.style.display = has ? "" : "none"; }
    updateLowStockNote(type === "variable" ? state.variation : null);
  }
  function refreshHeroPrice(){
    if(type==="variable"){
      if(state.variation) heroPrice(fmt(state.variation.price), state.variation.old ? { value:Number(state.variation.old), price:state.variation.price } : null);
      else heroPrice((hasPriceRange(p) ? "من " : "") + fmt(minPrice(p)), null);
    }else if(type==="grouped"){
      const tp = state.offer ? state.offer.price : 0;
      heroPrice(tp>0 ? fmt(tp) : (hasPriceRange(p) ? "من " : "") + fmt(minPrice(p)), null);
    }
  }
  const variantAttrs = (type==="variable") ? (p.attributes||[]).filter(a=>a.variation && (a.values||[]).length) : [];
  const varSel = {};
  function missingAttrs(){ return variantAttrs.filter(a=>!varSel[a.name]).map(a=>a.name); }
  if(type==="variable"){
    const vs = activeVariations(p);
    const box = document.createElement("div"); box.id = "variants"; box.className = "variant-box";
    offersBox.parentNode.insertBefore(box, offersBox);
    const compatible = (name, val)=>vs.some(v=>!varOut(v) && v.attrs[name]===val && variantAttrs.every(a=>a.name===name || !varSel[a.name] || v.attrs[a.name]===varSel[a.name]));
    function pickVariation(){
      const done = variantAttrs.length && variantAttrs.every(a=>varSel[a.name]);
      state.variation = done ? (vs.find(v=>variantAttrs.every(a=>v.attrs[a.name]===varSel[a.name])) || null) : null;
      if(state.variation && state.variation.image){ const m = document.getElementById("gmain"); if(m) m.src = REL + state.variation.image; }
      buildOffers(); refreshHeroPrice(); update(); renderVariants();
    }
    function renderVariants(){
      box.innerHTML = variantAttrs.map(a=>`<div class="v-attr"><div class="v-name">${attrEsc(a.name)}${varSel[a.name]?`: <b>${attrEsc(varSel[a.name])}</b>`:""}</div><div class="v-vals">${a.values.map(val=>{
          const ok = compatible(a.name, val);
          return `<button type="button" class="v-chip${varSel[a.name]===val?" on":""}${ok?"":" off"}" data-a="${attrEsc(a.name)}" data-v="${attrEsc(val)}" ${ok?"":"disabled"}>${attrEsc(val)}</button>`; }).join("")}</div></div>`).join("") +
        `<div class="v-hint">${state.variation ? "✅ متوفر" : (missingAttrs().length ? "اختر: " + missingAttrs().map(attrEsc).join(" و ") : "هذا الاختيار غير متوفر")}</div>`;
    }
    box.addEventListener("click", e=>{
      const btn = e.target.closest(".v-chip"); if(!btn || btn.disabled) return;
      const name = btn.dataset.a, val = btn.dataset.v;
      varSel[name] = (varSel[name]===val) ? "" : val;
      variantAttrs.forEach(a=>{ if(a.name!==name && varSel[a.name] && !compatible(a.name, varSel[a.name])) varSel[a.name] = ""; });
      pickVariation();
    });
    if(vs.length===1) variantAttrs.forEach(a=>varSel[a.name] = vs[0].attrs[a.name]);
    renderVariants();
    if(vs.length===1) setTimeout(pickVariation, 0);   // بعد تعريف update()
  }

  /* ── منتج مجمّع: عدة منتجات فردية بكمية لكل منها ── */
  if(type==="grouped"){
    const kids = groupChildren(p), qty = kids.map(()=>0);
    const box = document.createElement("div"); box.id = "group-box"; box.className = "group-box";
    box.innerHTML = kids.map((c,i)=>{
      const oos = isOutOfStock(c), img = c.cover || (c.images && c.images[0]) || "";
      return `<div class="g-row" data-i="${i}"><img src="${REL}${img}" alt=""><div class="g-t"><b>${attrEsc(c.title)}</b><small>${fmt(c.price)}${c.old?` <s>${fmt(c.old)}</s>`:""}${oos?' · <b style="color:var(--red)">نفدت</b>':""}</small></div>
        <div class="g-q"><button type="button" data-d="-1" ${oos?"disabled":""}>−</button><b>0</b><button type="button" data-d="1" ${oos?"disabled":""}>+</button></div></div>`;
    }).join("");
    offersBox.parentNode.insertBefore(box, offersBox); offersBox.style.display = "none";
    state.group = { kids, qty };
    const recalc = ()=>{
      const tq = qty.reduce((a,b)=>a+b,0), tp = qty.reduce((s2,q,i)=>s2+q*(Number(kids[i].price)||0),0);
      state.offer = { qty: tq, price: tp };
      box.querySelectorAll(".g-row").forEach((row,i)=>row.querySelector(".g-q b").textContent = qty[i]);
      refreshHeroPrice(); update();
    };
    box.addEventListener("click", e=>{
      const btn = e.target.closest("button[data-d]"); if(!btn || btn.disabled) return;
      const i = +btn.closest(".g-row").dataset.i; qty[i] = Math.max(0, Math.min(99, qty[i] + (+btn.dataset.d))); recalc();
    });
    state.offer = { qty:0, price:0 };
  }
  if(type!=="simple") setTimeout(refreshHeroPrice, 0);   // بعد سكربت الصفحة الذي يكتب سعر المنتج الأساسي
  // إخفاء بطاقات العروض إن عُطِّلت من لوحة التحكم ⟵ نموذج الطلب — يبقى العرض «الأكثر طلباً» (bestIdx)
  // محتسَباً داخلياً في state.offer لأغراض التسعير رغم إخفاء واجهة الاختيار
  if(__checkoutCache && __checkoutCache.showOffers === false) offersBox.style.display = "none";

  // نفاد الكمية — تعطيل الطلب وإظهار تنبيه (يُضبط من لوحة التحكم، حقل المخزون في تبويب المنتجات)
  if(outOfStock){
    const form = document.getElementById("order-form");
    if(form){
      const warn = document.createElement("div");
      warn.className = "oos-warning";
      warn.textContent = "⚠️ نفدت كمية هذا المنتج حالياً — سيتوفر قريباً";
      form.parentNode.insertBefore(warn, form);
      form.querySelectorAll("input,select,textarea,button").forEach(el=>el.disabled = true);
    }
    const addCartBtn = document.getElementById("add-cart");
    if(addCartBtn) addCartBtn.disabled = true;
    document.querySelectorAll(".btn-wa").forEach(a=>{
      a.style.pointerEvents = "none"; a.style.opacity = ".5";
    });
    document.querySelectorAll('a[href="#order-form"]').forEach(a=>{
      a.style.pointerEvents = "none"; a.style.opacity = ".5";
    });
  }

  // العدّاد التنازلي: لا يظهر إلا لعرض له تاريخ انتهاء حقيقي (p.dealEnd). كان يُعاد 48 ساعة لكل زائر فيبدو ضغطاً مصطنعاً (لجنة الخبراء v1.89.132)
  (function dealCountdown(){
    const boxes = document.querySelectorAll(".deal-timer");
    if(!boxes.length) return;
    let end = 0;
    try{ const pp = (typeof PRODUCTS !== "undefined") && PRODUCTS.find(x=>x.slug === slug); end = pp && pp.dealEnd ? Date.parse(pp.dealEnd) : 0; }catch(e){ end = 0; }
    if(!(end > Date.now())){
      boxes.forEach(b=>{
        const info = b.previousElementSibling, sm = info && info.querySelector("small"), bb = info && info.querySelector("b");
        if(sm && /ينتهي/.test(sm.textContent)) sm.remove();
        if(bb) bb.textContent = bb.textContent.replace(/^\s*عرض محدود\s*:?\s*/, "عرض الباقة: ");
        b.remove();
      });
      return;
    }
    function tick(){
      const left = end - Date.now();
      if(left <= 0){ boxes.forEach(b=>{ b.textContent = "انتهى العرض"; }); clearInterval(iv); return; }
      const h = Math.floor(left/3600000), m = Math.floor(left%3600000/60000), s = Math.floor(left%60000/1000);
      const txt = `${String(h).padStart(2,"0")} : ${String(m).padStart(2,"0")} : ${String(s).padStart(2,"0")}`;
      boxes.forEach(b=>b.textContent = txt);
    }
    const iv = setInterval(tick, 1000);
    tick();
  })();

  // الولايات والبلديات — قوائم منسدلة متوافقة مع الهاتف
  const sel = document.getElementById("wilaya");
  const deskWrap = document.getElementById("desk-wrap");
  const deskSel = document.getElementById("desk");

  // حذف حقل العنوان (غير ضروري)
  const addrInput = document.getElementById("address");
  if (addrInput){ const f = addrInput.closest(".field"); if(f) f.remove(); else addrInput.remove(); }

  // استبدال حقل البلدية بقائمة منسدلة (الداتاليست لا يعمل جيداً على الهاتف)
  let communeSel = null;
  const communeInput = document.getElementById("commune");
  if (communeInput){
    communeSel = document.createElement("select");
    communeSel.id = "commune"; communeSel.setAttribute("aria-label", "البلدية");
    communeSel.innerHTML = '<option value="">— اختر البلدية —</option>';
    communeInput.replaceWith(communeSel);
  }
  function setCommunes(w){
    if(!communeSel) return;
    fillCommuneSel(communeSel, w);
  }
  // مكاتب Stop Desk الحقيقية من Yalidine — تُرشَّح حسب البلدية المختارة
  function setDesks(w){
    if(!deskSel) return;
    const commune = communeSel ? communeSel.value : "";
    const allDesks = shipDesks(w, typeof p !== "undefined" ? p : null);
    const desks0 = commune ? allDesks.filter(d=>d.commune===commune) : allDesks, pk0 = typeof pshipCo === "function" ? pshipCo(typeof p !== "undefined" ? p : null) : "", desks = ((!pk0 || pk0 === "zones" || pk0 === "free" || pk0 === "def") && /[?&]embed=1/.test(location.search)) ? preferDesks(desks0) : desks0;      /* «الأرخص أولاً» لنموذج صفحة الهبوط (الإطار المضمَّن embed=1) وللشركة الافتراضية فقط؛ صفحات المنتجات العادية واللوحة تعرض كل المكاتب */
    deskSel.innerHTML = '<option value="">— اختر أقرب مكتب —</option>';
    desks.forEach(d=>{
      const o = document.createElement("option");
      o.value = d.name;
      o.textContent = `${d.name}${d.commune ? " — " + d.commune : ""}`;
      deskSel.appendChild(o);
    });
    const hasDesk = desks.length > 0;
    // إخفاء/إظهار حسب نوع التوصيل
    if(deskWrap) deskWrap.style.display = (state.dtype==="stop" && hasDesk) ? "" : "none";
    // تعطيل خيار المكتب إذا لا يوجد مكتب في البلدية المختارة
    document.querySelectorAll('input[name="dtype"]').forEach(r=>{
      if(r.value === "stop"){
        r.disabled = !hasDesk;
        const lbl = r.closest("label");
        if(lbl){
          lbl.style.opacity = hasDesk ? 1 : .45;
          lbl.title = hasDesk ? "" : "لا يوجد مكتب Stop Desk في هذه البلدية";
        }
        if(!hasDesk && r.checked){
          const home = document.querySelector('input[name="dtype"][value="home"]');
          if(home){ home.checked = true; state.dtype = "home"; }
        }
      } else { r.disabled = false; const l = r.closest("label"); if(l){ l.style.opacity = 1; l.title = ""; } }
    });
    shipRadios("dtype", w, commune);
    const cur = document.querySelector('input[name="dtype"]:checked'); if(cur) state.dtype = cur.value;
  }
  WILAYAS.forEach(w=>{
    if(w.hide) return;
    const o = document.createElement("option");
    o.value = w.id; o.textContent = `${String(w.id).padStart(2,"0")} - ${w.name}` + (w.xw ? " (غير متوفر)" : ""); if(w.xw){ o.disabled = true; o.style.color = "#9aa3a0"; }
    sel.appendChild(o);
  });
  sel.onchange = ()=>{ state.wilaya = WILAYAS.find(w=>w.id==sel.value); setCommunes(state.wilaya); setDesks(state.wilaya); update() };
  if(communeSel) communeSel.onchange = ()=>{ const k = kidSwitch(sel, communeSel); if(k) state.wilaya = k; setDesks(state.wilaya); update() };
  document.querySelectorAll('input[name="dtype"]').forEach(r=>r.onchange=()=>{ state.dtype=r.value; setDesks(state.wilaya); update() });
  if(deskSel) deskSel.onchange = ()=>{ state.desk = deskSel.value; };

  // حقول إضافية مخصصة (تُضاف من لوحة التحكم ⟵ نموذج الطلب) — تُدرج قبل مربع الإجمالي وتُرفَق
  // قيمتها في رسالة واتساب عند تأكيد الطلب (راجع معالج submit أدناه)
  const extraFields = (__checkoutCache && Array.isArray(__checkoutCache.extraFields)) ? __checkoutCache.extraFields : [];
  if(extraFields.length){
    const form = document.getElementById("order-form");
    const totalBoxRef = document.getElementById("fee") ? document.getElementById("fee").closest(".total-box") : null;
    extraFields.forEach(f=>{
      if(!f || !f.id) return;
      const field = document.createElement("div");
      field.className = "field";
      field.innerHTML = `<label>${f.label||""}${f.required?" *":""}</label><input id="extra-${f.id}" ${f.required?"required":""} placeholder="${f.placeholder||""}">`;
      if(totalBoxRef) totalBoxRef.parentNode.insertBefore(field, totalBoxRef);
      else if(form) form.appendChild(field);
    });
  }

  const feeEl = document.getElementById("fee"), totEl = document.getElementById("grand");
  let bumpSel = null, bumpCtl = null;                                  // Order Bump المختار (خانة قبل زر التأكيد) — راجع assets/js/upsell.js
  const bumpAmt = ()=> bumpSel ? bumpSel.price * bumpSel.qty : 0;
  function update(){
    const freeShip = offerFreeShip(p, state.offer) || couponFreeShip();
    const sq = (state.wilaya && !p.digital) ? shipQuote(state.wilaya, communeSel ? communeSel.value : "", state.dtype, state.offer.price, pshipCo(p), prodShipPf(p), prodShipAdj(p)) : null;
    const fee = p.digital ? 0 : (freeShip ? 0 : (sq ? sq.fee : null));
    if(!p.digital && state.wilaya) labelCommunes(communeSel, state.wilaya, (ww, c)=>{ const q = shipQuote(ww, c, state.dtype, state.offer.price, pshipCo(p), prodShipPf(p), prodShipAdj(p)); return q.blocked ? null : ((freeShip || q.free) ? 0 : q.fee); });
    feeEl.textContent = p.digital ? "—" : freeShip ? "مجاني 🚚" : (sq && sq.blocked ? "غير متاح ⛔" : (sq && sq.free ? "مجاني 🚚" : (fee!=null ? fmt(fee) : "اختر الولاية")));
    let sm = document.getElementById("ship-msg");
    if(!sm){ sm = document.createElement("div"); sm.id = "ship-msg"; sm.style.cssText = "color:var(--red,#c0392b);font-size:.88rem;margin:.4rem 0;font-weight:700"; const tb = feeEl.closest(".total-box"); if(tb) tb.parentNode.insertBefore(sm, tb); }
    sm.textContent = (!freeShip && sq) ? sq.msg : "";
    const discount = currentCouponDiscount(state.offer.price, [{slug:p.slug,cat:p.cat,qty:state.offer.qty,free:state.offer.free,amount:state.offer.price}]);
    const total = Math.max(0, state.offer.price - discount) + bumpAmt() + (fee||0);
    totEl.textContent = fmt(total);
    const st = document.getElementById("sticky-price");
    if(st) st.textContent = fmt(total);
    // زر «تأكيد الطلب» كان يعرض دائماً سعر القطعة الواحدة الثابت (p.price) ولا يتحدّث أبداً
    // مع تغيير العرض أو إضافة رسوم التوصيل — أصبح الآن يعكس نفس الإجمالي الحقيقي دوماً (يشمل خصم الكوبون إن وُجد)
    const bt = document.querySelector("#order-form #btn-total, .order-wide #btn-total") || document.getElementById("btn-total");
    if(bt){ bt.textContent = fmt(total); const pn = bt.previousSibling; if(pn && pn.nodeType === 3 && !/الإجمالي|الاجمالي/.test(pn.textContent)) pn.textContent = pn.textContent.replace(/—\s*$/, "— الإجمالي: "); }
    if(bumpCtl) bumpCtl.refresh();      // تغيّر العرض/الكمية قد يغيّر أهلية الـOrder Bump
  }
  if(p.digital){ const __dm = ()=>{ try{ DigitalCheckout.mount(p); update(); }catch(e){} }; if(window.DigitalCheckout) __dm(); else document.addEventListener("digital:ready", __dm, { once:true }); }   // منتج رقمي: بلا توصيل، بريد + دفع مسبق (assets/js/digital-checkout.js)
  update();
  document.addEventListener("shipco:ready", ()=>{ try{ update(); }catch(e){} });
  // حقل كود الخصم — يُحقن ديناميكياً قبل مربع الإجمالي (لا حاجة لتعديل كل صفحة منتج يدوياً)
  const totalBoxEl = feeEl.closest(".total-box");
  if(totalBoxEl) injectCouponBox("prod", totalBoxEl, ()=>state.offer.price, update, ()=>[{slug:p.slug,cat:p.cat,qty:state.offer.qty,free:state.offer.free,amount:state.offer.price}]);
  // Order Bump: منتج مكمّل بسعر خاص بخانة اختيار قبل الإجمالي (القواعد من لوحة التحكم ⟵ العروض الإضافية)
  const mountBump = ()=>{ if(bumpCtl || !totalBoxEl || !window.Upsell) return; try{ bumpCtl = Upsell.mountBump(totalBoxEl, ()=>({ slugs:[p.slug], cats:[p.cat], total: state.offer.price }), sel=>{ bumpSel = sel; update(); }); }catch(e){} };
  if(window.Upsell && Upsell.ready()) mountBump(); else document.addEventListener("upsell:ready", mountBump, { once:true });

  // بنود الطلب حسب نوع المنتج (المتغيّر: عنوان التنويع داخل الاسم؛ المجمّع: بند لكل منتج بكمية)
  function orderItems(){
    if(type==="grouped") return state.group.kids.map((c,i)=>({ slug:c.slug, title:c.title, qty:state.group.qty[i], price:Number(c.price)||0 })).filter(x=>x.qty>0);
    const title = p.title + (state.variation ? " — " + variationLabel(p, state.variation) : "");
    /* سعر القطعة = سعر العرض ÷ عدد القطع الكلي (بما فيها المجانية) ليكون مجموع السطر = سعر العرض تماماً (كان 3 قطع بعرض «2+1» تُسجَّل 3×سعر القطعة الكاملة فيظهر مجموع أكبر من الحقيقي) */
    return [{ slug: p.slug, title, qty: state.offer.qty, price: Math.round(state.offer.price / state.offer.qty * 100) / 100 }];
  }

  /* تحقق مرئي قبل أي إرسال: الخانة الناقصة أو الخاطئة تحمرّ مع رسالتها (يُعطَّل تحقق المتصفح الأصلي ليحلّ محلّه) */
  { const __f = document.getElementById("order-form"); if(__f){ __f.noValidate = true; FormCheck.star(__f); __f.addEventListener("submit", e=>{
    if(typeof OrderSteps !== "undefined" && OrderSteps.state.on) return;
    FieldErr.clearAll(__f); const __er = FormCheck.list(__f, 0, { ship: !p.digital }); if(__er.length){ e.preventDefault(); e.stopImmediatePropagation(); FieldErr.show(__er); }
  }, true); } }
  // تأكيد الطلب — واتساب
  document.getElementById("order-form").addEventListener("submit", async e=>{
    e.preventDefault();
    if(outOfStock){ toast("⚠️ نفدت كمية هذا المنتج حالياً"); return }
    const name = document.getElementById("name").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const commune = document.getElementById("commune").value.trim();
    if(PhoneDZ.on && !PhoneDZ.ok(PhoneDZ.norm(phone))){ toast(PhoneDZ.MSG); document.getElementById("phone").focus(); return }
    if(type==="variable" && !state.variation){ toast("اختر " + (missingAttrs().join(" و ") || "خياراً متوفراً")); const vb = document.getElementById("variants"); if(vb) vb.scrollIntoView({behavior:"smooth", block:"center"}); return }
    if(type==="grouped" && !(state.offer && state.offer.qty>0)){ toast("اختر كمية منتج واحد على الأقل"); const gb = document.getElementById("group-box"); if(gb) gb.scrollIntoView({behavior:"smooth", block:"center"}); return }
    if(!p.digital && !state.wilaya){ toast("يرجى اختيار الولاية"); sel.focus(); return }
    const __sq = p.digital ? { fee:0 } : shipQuote(state.wilaya, communeSel ? communeSel.value : "", state.dtype, state.offer.price, pshipCo(p), prodShipPf(p), prodShipAdj(p)); if(!p.digital && __sq.blocked && !offerFreeShip(p, state.offer)){ toast(__sq.msg); return }
    if(!p.digital && state.dtype==="stop" && deskSel && !deskSel.value){ toast("يرجى اختيار المكتب"); deskSel.focus(); return }
    // جمع قيم الحقول الإضافية المخصّصة (لوحة التحكم ⟵ نموذج الطلب) — تُرفق في رسالة واتساب وفي الطلب المُسجَّل
    const extraValues = {};
    for(const f of extraFields){
      const el = document.getElementById("extra-"+f.id);
      const v = el ? el.value.trim() : "";
      if(f.required && !v){ toast(`يرجى ملء حقل «${f.label||f.id}»`); if(el) el.focus(); return }
      if(v) extraValues[f.label||f.id] = v;
    }
    try{ const __gp = window.GeoPin && GeoPin.link(); if(__gp) extraValues["📍 الموقع"] = __gp; }catch(e){}
    const fee = (offerFreeShip(p, state.offer) || couponFreeShip()) ? 0 : __sq.fee;
    const discount = currentCouponDiscount(state.offer.price, [{slug:p.slug,cat:p.cat,qty:state.offer.qty,free:state.offer.free,amount:state.offer.price}]);
    const bumpPrice = bumpAmt();
    const total = Math.max(0, state.offer.price - discount) + bumpPrice + fee;
    if(p.digital){       // مسار المنتج الرقمي: لا توصيل؛ طلب + دفع مسبق (BaridiMob/CCP/بطاقة) ثم تسليم تلقائي — assets/js/digital-checkout.js
      if(!window.DigitalCheckout){ toast("حاول بعد لحظات"); return }
      const __dOrder = { name, phone, wilaya:"رقمي", commune:"", dtype:"home", desk:"", items: orderItems().map(x=>Object.assign({}, x, { vid: (type!=="grouped" && state.variation) ? state.variation.id : "" })), subtotal: state.offer.price, fee:0, total: Math.max(0, state.offer.price - discount),
        coupon: AppliedCoupon.record ? AppliedCoupon.code : "", discount, extra: Object.assign({}, extraValues, { "📄 الصفحة": PageSrc || ("p/" + slug) }) };
      try{ trackEvent("Lead", { slug: p.slug, title: p.title, qty: state.offer.qty, value: __dOrder.total }); }catch(e){}
      Gifts.markUsed(AppliedCoupon.record); markCouponPhoneUsed(AppliedCoupon.record, phone);
      return DigitalCheckout.submit({ order: __dOrder, total: __dOrder.total });
    }
    const desk = (state.dtype==="stop" && deskSel) ? deskSel.value : "";
    const __grp = (bumpSel || (window.Upsell && Upsell.hasType("post"))) ? Upsell.gid() : "";    // مجموعة الطلب: تربط طلب «بعد الشراء» بهذا الطلب ليُدمجا في شحنة واحدة
    // Enregistrement dans Google Sheets
    const __pre = (Guard.active() && waAutoOn()) ? window.open("", "_blank") : null;      // يُفتح فوراً (ضمن نقرة الزبون) قبل انتظار فحص الخادم
    const __order = {
      name, phone, wilaya: state.wilaya.name, commune,
      dtype: state.dtype, desk,
      items: orderItems().concat(bumpSel ? [{ slug: bumpSel.slug, title: bumpSel.title, qty: bumpSel.qty, price: bumpSel.price }] : []),
      subtotal: state.offer.price + bumpPrice, fee, total,
      coupon: AppliedCoupon.record ? AppliedCoupon.code : "", discount, promo: (AppliedCoupon.record && AppliedCoupon.record.__promo) ? AppliedCoupon.code : undefined,
      extra: Object.assign({}, couponGiftTitle() ? { "🎁 هدية": couponGiftTitle() } : {}, (state.offer.qty > 1 || state.offer.free) ? { "🎁 العرض": "عرض " + state.offer.qty + " قطع" + (state.offer.free ? " (" + (state.offer.qty - state.offer.free) + " + " + state.offer.free + " مجاناً)" : "") + " بسعر " + fmt(state.offer.price) } : {}, extraValues, bumpSel ? { "➕ إضافة سريعة": bumpSel.rule.title || bumpSel.title, "🆔 قاعدة العرض": bumpSel.rule.id } : {}, __grp ? { "🧺 مجموعة": __grp } : {}, { "📄 الصفحة": PageSrc || ("p/" + slug) }, (fee > 0 && __sq.sup > 0 && fee === __sq.fee) ? { "🚚 تفصيل التوصيل": (fee - __sq.sup) + "+" + __sq.sup } : {}, (fee > 0 && __sq.adj && fee === __sq.fee) ? { "🎁 دعم الشحن": String(__sq.adj) } : {}, Attrib),
    };
    if(desk){ const __da = deskAddrOf(state.wilaya, desk, commune); if(__da) __order.extra["📍 عنوان المكتب"] = __da; }
    const __pfr = window.PFOrder ? PFOrder.prep(__order) : "";
    if(p.mpId){       // منتج التسويق بالعمولة: لا يُقبل الطلب إلا إن حجز المورّد عمولته وكميته (فحص متزامن عند المنصة)
      __order.extra["🛒 سوق التوريد"] = "1";
      const __hold = window.PFOrder ? await PFOrder.hold(__order, __pfr, __order.items.map(x=>Object.assign({}, x, { vid: (type!=="grouped" && state.variation) ? state.variation.id : "" }))) : { ok:false, msg:"حاول بعد لحظات" };
      if(!__hold.ok){ if(__pre) __pre.close(); toast(__hold.msg); return }
    }
    if(Guard.active()){ const gr = await Guard.submit(__order); if(!gr.ok){ if(__pre) __pre.close(); toast(gr.msg); return } } else API.submitOrder(__order);
    Gifts.markUsed(AppliedCoupon.record); markCouponPhoneUsed(AppliedCoupon.record, phone);
    try{ if(window.PFOrder) PFOrder.send(__order, __pfr, __order.items.map(x=>Object.assign({}, x, { vid: (type!=="grouped" && state.variation) ? state.variation.id : "" }))); }catch(e){}
    // حدث «شراء» لكل بكسل تتبع مفعّل على هذا المنتج (فيسبوك/تيك توك/جوجل) — لوحة التحكم ⟵ البكسلات
    try{ trackEvent("Lead", { slug: p.slug, title: p.title, qty: state.offer.qty, value: total }); }catch(e){}
    firePixelPurchase(p, total, state.offer.qty, undefined, fee);
    let msg = `السلام عليكم ${SITE_NAME}،\nأريد طلب:\n` + (type==="grouped"
      ? state.group.kids.map((c,i)=> state.group.qty[i] ? `\n• ${c.title}\n  الكمية: ${state.group.qty[i]} × ${fmt(c.price)} = ${fmt(state.group.qty[i]*c.price)}` : "").join("")
      : `\n• ${p.title}${state.variation?" — "+variationLabel(p,state.variation):""}\n  الكمية: ${state.offer.qty} × ${fmt(Math.round(state.offer.price/(state.offer.qty-(state.offer.free||0))))} = ${fmt(state.offer.price)}`);
    if(bumpSel) msg += `\n\n• ${bumpSel.title} (إضافة سريعة)\n  الكمية: 1 × ${fmt(bumpSel.price)} = ${fmt(bumpSel.price)}`;
    if(state.offer.free) msg += `\n  🎁 العرض: اشترِ 2 واحصل على الثالثة مجاناً`;
    if(p.old) msg += `\n  (السعر الأصلي: ${fmt(p.old)} ✂️)`;
    if(discount>0) msg += `\n  🎟️ خصم الكود (${AppliedCoupon.code}): -${fmt(discount)}`;
    else if(couponFreeShip()) msg += `\n  🎟️ كود التوصيل المجاني (${AppliedCoupon.code})`;
    if(couponGiftTitle()) msg += `\n  🎁 هدية الكود (${AppliedCoupon.code}): ${couponGiftTitle()}`;
    msg += `\n\nالتوصيل (${state.dtype==="stop"?"مكتب Stop Desk":"إلى المنزل"} — ${state.wilaya.name}${commune?"، "+commune:""}${desk?" — المكتب: "+desk:""}): ${fmt(fee)}`;
    msg += `\n*الإجمالي: ${fmt(total)}*`;
    msg += `\n\nالاسم: ${name}\nالهاتف: ${phone}`;
    Object.entries(extraValues).forEach(([label,val])=>{ msg += `\n${label}: ${val}`; });
    msg += `\n\n💵 الدفع عند الاستلام`;
    if(waAutoOn()) Guard.openWa(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`, __pre);
    Thanks.show({ name, total, up: { customer:{ name, phone, wilaya: state.wilaya.name, commune, dtype: state.dtype, desk }, slugs: __order.items.map(x=>x.slug), cats:[p.cat], total, grp: __grp, page: PageSrc || ("p/" + slug) }, lines: (type==="grouped" ? state.group.kids.filter((c,i)=>state.group.qty[i]).map(c=>c.title) : [p.title + (state.offer.qty>1?" ×"+state.offer.qty:"")]).concat(bumpSel ? [bumpSel.title] : []), wa: `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}` });
  });

  // أضف إلى السلة
  document.getElementById("add-cart").onclick = ()=>{
    if(outOfStock){ toast("⚠️ نفدت كمية هذا المنتج حالياً"); return }
    if(type==="variable"){
      if(!state.variation){ toast("اختر " + (missingAttrs().join(" و ") || "خياراً متوفراً")); const vb = document.getElementById("variants"); if(vb) vb.scrollIntoView({behavior:"smooth", block:"center"}); return }
      Cart.add(p.slug, state.offer.qty, state.offer.price / state.offer.qty, state.variation.id, variationLabel(p, state.variation)); return;
    }
    if(type==="grouped"){
      if(!(state.offer && state.offer.qty>0)){ toast("اختر كمية منتج واحد على الأقل"); return }
      state.group.kids.forEach((c,i)=>{ if(state.group.qty[i]>0) Cart.add(c.slug, state.group.qty[i], Number(c.price)||0); }); return;
    }
    Cart.add(p.slug, state.offer.qty, state.offer.price / state.offer.qty);
  };

  // «يشاهدون الآن»: أُزيل — كان رقماً عشوائياً غير حقيقي (لجنة الخبراء v1.89.132). المتجر لا يملك عدّاداً حقيقياً للزوار فلا يُعرض شيء.
  const vn = document.getElementById("viewers");
  if(vn){ const tag = vn.closest(".tag"); if(tag) tag.remove(); else vn.remove(); }
  try{
    trackEvent("ViewContent", { slug: p.slug, title: p.title, value: Number(p.price) || 0 });
    const of0 = document.getElementById("order-form");
    if(of0){ let sent = false; of0.addEventListener("focusin", ()=>{ if(sent) return; sent = true; trackEvent("InitiateCheckout", { slug: p.slug, title: p.title, value: Number(p.price) || 0 }); }); }
  }catch(e){}
}

/* ── بطاقة منتج (مشتركة بين الشبكة الرئيسية والأكثر مبيعاً) ── */
function isOutOfStock(p){
  const t = productType(p);
  if(t==="variable"){ const vs = activeVariations(p); return !vs.length || vs.every(varOut); }
  if(t==="grouped"){ const cs = groupChildren(p); return !cs.length || cs.every(isOutOfStock); }
  return p.stock!==undefined && p.stock!==null && Number(p.stock)<=0;
}
/* مصدر الطلب (أي صفحة جاء منها): من ?src= أو ?utm_content= ويُحفظ للجلسة؛ يُسجَّل في حقل «📄 الصفحة» داخل extra لمقارنة صفحات المنتج في الإحصاءات */
/* مصدر الحملة: utm_source/utm_campaign من رابط الإعلان أو المنشور يُحفظان 14 يوماً ويُسجَّلان في extra الطلب («📣 الحملة») ليحسب تبويب «السوشيال ← الحملات» الطلبات والإيراد لكل حملة */
const Attrib = (function(){ try{ const q = new URLSearchParams(location.search), s = q.get("utm_source"), c = q.get("utm_campaign"), ck = q.get("fbclid") ? "facebook" : q.get("ttclid") ? "tiktok" : q.get("gclid") ? "google" : ""; let old0 = null; try{ old0 = JSON.parse(localStorage.getItem("store_utm") || "null"); }catch(e){} if((s || c || ck) && !(s === "home" && old0 && old0.s && old0.s !== "home" && Date.now() - old0.t < 14*864e5)){ localStorage.setItem("store_utm", JSON.stringify({ s: s || ck, m: q.get("utm_medium") || "", c: c || "(بدون حملة)", k: (q.get("fbclid") || q.get("ttclid") || q.get("gclid") || "").slice(0, 120), t: Date.now() })); } const o = JSON.parse(localStorage.getItem("store_utm") || "null"); if(o && Date.now() - o.t < 14*864e5 && o.s !== "home" && o.c) return Object.assign({ "📣 الحملة": (o.s ? o.s + "/" : "") + o.c }, o.k ? { "🔗 معرّف النقرة": o.k } : {}); }catch(e){} return {}; })();
const PageSrc = (function(){ try{ const q = new URLSearchParams(location.search), s = q.get("src") || q.get("utm_content"); if(s) sessionStorage.setItem("store_src", s); return sessionStorage.getItem("store_src") || ""; }catch(e){ return ""; } })();
/* رابط المنتج في البطاقات: صفحة «المسار» المختارة (صفحة هبوط) إن وُجدت وإلا صفحته الرسمية؛ ومع اختبار A/B (p.ab = {b, pct}) يُوزَّع الزوار على النسختين بنسبة pct% للثانية ويثبت اختيار كل زائر؛ ويُضاف رمز تتبع UTM */
function productHref(p){
  let page = p.route || "", v = "";
  if(p.ab && p.ab.b){
    const k = "store_ab_" + p.slug; let g = "";
    try{ g = localStorage.getItem(k) || ""; }catch(e){}
    if(g !== "A" && g !== "B"){ g = Math.random()*100 < (Number(p.ab.pct)||50) ? "B" : "A"; try{ localStorage.setItem(k, g); }catch(e){} }
    if(g === "B") page = p.ab.b;
    v = g;
  }
  const src = page ? "lp/" + page : "p/" + p.slug, to = page ? src : p.slug;      // المنتج بلا مسار ⟵ الرابط النظيف في الجذر (النسخ الجذرية جاهزة)
  return REL + to + "/?utm_source=home&utm_medium=product-card&utm_campaign=" + encodeURIComponent(p.slug) + "&utm_content=" + encodeURIComponent(src) + (v ? "&ab=" + v : "");
}
function productCardHTML(p, opts){
  opts = opts || {};
  const ptype = productType(p), disc = (ptype==="simple" && p.old) ? Math.round((1-p.price/p.old)*100) : 0;
  const oos = isOutOfStock(p);
  return `
    <div class="thumb">${oos?`<div class="ribbon-oos">نفدت الكمية 🚫</div>`:""}${(!oos && opts.ribbon)?`<span class="ribbon-best">${opts.ribbon}</span>`:""}${(!oos && disc)?`<span class="badge-off">-${disc}%</span>`:""}${(p.cover||(p.images&&p.images[0]))?`<img loading="lazy" decoding="async" width="500" height="500" src="${REL}${p.cover||p.images[0]}" srcset="${encodeURI(REL+(p.cover||p.images[0]).replace(/\.webp$/,".w480.webp"))} 480w, ${encodeURI(REL+(p.cover||p.images[0]).replace(/\.webp$/,".w720.webp"))} 720w, ${encodeURI(REL+(p.cover||p.images[0]))} 1100w" sizes="(max-width:700px) 92vw, 330px" onerror="if(this.srcset){this.removeAttribute('srcset');this.src=this.src}" alt="${p.title}">`:`<div class="noimg" role="img" aria-label="${p.title}" style="width:100%;aspect-ratio:1/1;background:#ece8df"></div>`}</div>
    <div class="body">
      <h3>${p.title}</h3>
      ${(p.reviews && Number(p.reviews.count) > 0) ? `<div class="stars">★ ${Number(p.reviews.avg||5).toFixed(1)} <small>(${Number(p.reviews.count)} تقييم)</small></div>` : ""}
      <div class="price-row"><span class="price">${ptype!=="simple" && hasPriceRange(p) ? "من " : ""}${fmt(ptype==="simple" ? p.price : minPrice(p))}</span>${(ptype==="simple" && p.old)?`<span class="old">${fmt(p.old)}</span>`:""}</div>
      <div class="cta">${oos?"نفدت الكمية":(document.querySelector(".aly-grid")?"عرض المنتج":"اطلب الآن — الدفع عند الاستلام")}</div>
    </div>`;
}

/* ── الرئيسية ── */
function initHome(){
  const grid = document.getElementById("grid");
  const chips = document.getElementById("chips");
  let filter = "all";
  const chipBtns = {};
  let rt = 0;
  function render(){
    const tk = ++rt; grid.innerHTML = "";
    const list = PRODUCTS.filter(p=>filter==="all"||p.cat===filter);
    /* أول 6 بطاقات فوراً والباقي دفعات صغيرة في وقت الخمول: لا مهمة واحدة طويلة تجمّد الصفحة على الهاتف */
    const add = (from, to)=>{
      const f = document.createDocumentFragment();
      list.slice(from, to).forEach(p=>{
        const a = document.createElement("a");
        a.className = "card" + (isOutOfStock(p)?" oos":""); a.href = productHref(p);
        a.innerHTML = productCardHTML(p);
        f.appendChild(a);
      });
      grid.appendChild(f);
    };
    const later = fn=>{ window.requestIdleCallback ? requestIdleCallback(fn, { timeout: 700 }) : setTimeout(fn, 60); };
    add(0, 6);
    let i = 6;
    const step = ()=>{ if(tk!==rt || i>=list.length) return; add(i, i+6); i += 6; if(i<list.length) later(step); };
    if(list.length>6) later(step);
  }
  const all = document.createElement("button");
  all.className = "chip active"; all.textContent = "الكل";
  all.onclick = ()=>{ filter="all"; setActive(all); render() };
  chips.appendChild(all);
  chipBtns.all = all;
  Object.entries(CATEGORIES).forEach(([k,label])=>{
    if(!PRODUCTS.some(p=>p.cat===k)) return;
    const c = document.createElement("button");
    c.className = "chip"; c.textContent = label;
    c.onclick = ()=>{ filter=k; setActive(c); render() };
    chips.appendChild(c);
    chipBtns[k] = c;
  });
  function setActive(btn){ chips.querySelectorAll(".chip").forEach(x=>x.classList.remove("active")); btn.classList.add("active") }
  render();

  /* تفعيل تصفية فئة معيّنة من خارج initHome (بطاقات «تسوّق حسب الفئة») */
  window.goToCategory = function(key){
    const btn = chipBtns[key] || chipBtns.all;
    if(btn) btn.click();
    const el = document.getElementById("products");
    if(el) el.scrollIntoView({behavior:"smooth", block:"start"});
  };
}

/* ── صفحة المتجر shop.html: كل المنتجات، أو تصنيف ?cat=مفتاح، أو فئة ?c=best|hot|sale|new، أو منتجات مختارة ?p=slug1,slug2 ── */
async function initShop(){
  const grid = document.getElementById("shop-grid"); if(!grid) return;
  const q = new URLSearchParams(location.search), cat = q.get("cat") || "", col = q.get("c") || "", ps = (q.get("p") || "").split(",").map(x=>x.trim()).filter(Boolean);
  const cols = (await loadCollections()).filter(c=>c.enabled!==false);
  const cur = col ? cols.find(c=>c.key===col) : null;
  let list = PRODUCTS.filter(p=>p.active!==false), title = "المتجر", sub = "كل منتجاتنا — والدفع دائماً عند الاستلام";
  if(cat){ list = list.filter(p=>p.cat===cat); title = CATEGORIES[cat] || cat; sub = "كل منتجات هذا التصنيف"; }
  else if(col){ list = list.filter(p=>(p.tags||[]).includes(col)); title = cur ? (cur.title || cur.label) : col; sub = cur ? (cur.sub || "") : ""; }
  else if(ps.length){ list = ps.map(sl=>list.find(p=>p.slug===sl)).filter(Boolean); title = "منتجات مختارة"; sub = ""; }
  const T = document.getElementById("shop-title"), S = document.getElementById("shop-sub"), C = document.getElementById("shop-chips");
  if(T) T.textContent = title; if(S) S.textContent = sub;
  if(cat && document.querySelector(".aly-grid")){      // لافتة الفئة بصورتها (قالب اسم متجرك)
    const hi = REL + "assets/img/tpl/store-cat-" + cat + ".webp", im = new Image(), box = document.querySelector(".shop-page .sec-title");
    im.onload = ()=>{ if(box) box.style.setProperty("--shop-hero", "url('" + hi + "')"); }; im.src = hi;
  }
  try{ document.title = title + " | " + ((typeof CONFIG!=="undefined" && CONFIG.SITE && CONFIG.SITE.name) || document.title.split("|")[0].trim()); }catch(e){}
  if(C){
    const a = (href, label, on)=>`<a class="chip${on?" active":""}" href="${href}">${label}</a>`;
    C.innerHTML = a("shop.html", "الكل", !cat && !col && !ps.length) + Object.entries(CATEGORIES).filter(([k])=>PRODUCTS.some(p=>p.active!==false && p.cat===k)).map(([k,l])=>a("shop.html?cat="+encodeURIComponent(k), l, k===cat)).join("") +
      cols.filter(c=>collectionProducts(c.key).length).map(c=>a("shop.html?c="+encodeURIComponent(c.key), c.label, c.key===col)).join("");
  }
  grid.innerHTML = "";
  if(!list.length){ grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--muted);padding:2rem 0">لا توجد منتجات هنا حالياً.</p>'; return; }
  list.forEach(p=>{ const a = document.createElement("a"); a.className = "card" + (isOutOfStock(p)?" oos":""); a.href = productHref(p); a.innerHTML = productCardHTML(p, cur && cur.ribbon ? {ribbon:cur.ribbon} : undefined); grid.appendChild(a); });
}
/* ── صفحة حسابي account.html: تفتح نافذة الدخول/التسجيل مباشرة ── */
function initAccountPage(){
  const box = document.getElementById("acct-box"); if(!box) return;
  const draw = ()=>{ const p = Account.profile(); box.innerHTML = p
    ? `<p>أهلاً <b>${Account.esc(p.name || "")}</b> 👋</p><button class="btn btn-gold" type="button" id="acct-open">👤 فتح حسابي وطلباتي</button>`
    : `<p>أنشئ حسابك مرة واحدة لتتبّع طلباتك وإعادة الطلب ببياناتك المحفوظة.</p><div style="display:flex;gap:.7rem;justify-content:center;flex-wrap:wrap"><button class="btn btn-gold" type="button" data-t="reg">✨ حساب جديد</button><button class="btn btn-ghost" type="button" data-t="login" style="color:var(--green);border-color:var(--line)">🔑 تسجيل الدخول</button></div>`;
    box.querySelectorAll("button").forEach(b=>b.onclick = ()=>{ Account.tab = b.dataset.t || Account.tab; Account.open(); if(b.dataset.t && !Account.profile()) Account.guest(b.dataset.t); }); };
  draw(); setTimeout(()=>{ try{ Account.open(); }catch(e){} }, 400);
}

/* ── تبويبات الرئيسية: الأكثر مبيعاً / الأكثر طلباً / التخفيضات / المنتجات الجديدة ──
   عضوية المنتج في تبويب = p.tags (تُعدَّل من لوحة الإدارة ← تعديل المنتج). التبويب الفارغ يُخفى. */
const COLLECTIONS_DEFAULT = [{"key": "best", "label": "🔥 الأكثر مبيعاً", "title": "الأكثر مبيعاً", "sub": "المنتجات المفضّلة لدى عملائنا", "ribbon": "🔥 الأكثر مبيعاً", "bg": "#F4EFE6", "accent": "#8a6a1a", "enabled": true}, {"key": "hot", "label": "⚡ الأكثر طلباً", "title": "الأكثر طلباً", "sub": "الأكثر طلباً هذه الأيام", "ribbon": "⚡ الأكثر طلباً", "bg": "#FBEBDD", "accent": "#b4531a", "enabled": true}, {"key": "sale", "label": "🏷️ التخفيضات", "title": "التخفيضات", "sub": "أسعار مخفّضة لفترة محدودة", "ribbon": "🏷️ تخفيض", "bg": "#FBE4E4", "accent": "#b83232", "enabled": true}, {"key": "new", "label": "✨ المنتجات الجديدة", "title": "المنتجات الجديدة", "sub": "وصل حديثاً إلى المتجر", "ribbon": "✨ جديد", "bg": "#E4F1EA", "accent": "#157a55", "enabled": true}];
let __collCache = null;
async function loadCollections(){      // assets/data/collections.json (تُعدَّل من لوحة الإدارة ← المنتجات ← تبويبات الرئيسية)
  if(__collCache) return __collCache;
  try{
    const r = await fetch((typeof REL!=="undefined"?REL:"") + "assets/data/collections.json", {cache:"no-store"});
    const j = r.ok ? await r.json() : null;
    __collCache = (j && Array.isArray(j.tabs) && j.tabs.length) ? j.tabs : COLLECTIONS_DEFAULT;
  }catch(e){ __collCache = COLLECTIONS_DEFAULT; }
  return __collCache;
}
function inkOn(hex){ const m = /^#?([0-9a-f]{6})$/i.exec(hex||""); if(!m) return "#fff"; const n = parseInt(m[1],16), f = c=>{ c/=255; return c<=.03928 ? c/12.92 : Math.pow((c+.055)/1.055,2.4); }; const L = .2126*f(n>>16&255)+.7152*f(n>>8&255)+.0722*f(n&255); return L > .4 ? "#1C2420" : "#fff"; }
function collectionProducts(key){ return PRODUCTS.filter(p=>p.active!==false && (p.tags||[]).includes(key)); }
async function renderBestsellers(slugs){
  const COLLECTIONS = (await loadCollections()).filter(c=>c.enabled!==false);
  const wrap = document.getElementById("bestsellers-grid");
  if(!wrap) return;
  const sec = document.getElementById("bestsellers");
  const cols = PRODUCTS.some(p=>(p.tags||[]).length) ? COLLECTIONS.filter(c=>collectionProducts(c.key).length) : [];
  const draw = (c, list)=>{
    wrap.innerHTML = "";
    list.forEach(p=>{
      const a = document.createElement("a");
      a.className = "card" + (isOutOfStock(p)?" oos":""); a.href = productHref(p);
      a.innerHTML = productCardHTML(p, {ribbon:c.ribbon});
      wrap.appendChild(a);
    });
  };
  if(!cols.length){   // لا وسوم بعد: السلوك القديم (قائمة ثابتة)
    draw(COLLECTIONS[0] || COLLECTIONS_DEFAULT[0], (slugs||[]).map(s=>PRODUCTS.find(x=>x.slug===s)).filter(Boolean));
    return;
  }
  let bar = document.getElementById("coll-tabs");
  if(!bar){
    bar = document.createElement("div"); bar.id = "coll-tabs"; bar.className = "coll-tabs"; bar.setAttribute("role", "tablist");
    const head = sec && sec.querySelector(".sec-title"); head ? head.insertAdjacentElement("afterend", bar) : wrap.parentNode.insertBefore(bar, wrap);
  }
  const show = key=>{
    const c = cols.find(x=>x.key===key) || cols[0];
    bar.querySelectorAll("button").forEach(b=>{ const on = b.dataset.k === c.key; b.classList.toggle("on", on); b.setAttribute("aria-selected", on); b.style.background = on ? c.accent : ""; b.style.borderColor = on ? c.accent : ""; b.style.color = on ? inkOn(c.accent) : ""; });
    if(sec){ sec.style.background = c.bg; sec.style.setProperty("--coll", c.accent); const h = sec.querySelector(".sec-title h2"), sp = sec.querySelector(".sec-title p"), k = sec.querySelector(".sec-title .kicker"); if(h) h.textContent = c.title; if(sp) sp.textContent = c.sub; if(k) k.style.color = c.accent; }
    draw(c, collectionProducts(c.key));
  };
  bar.innerHTML = cols.map(c=>`<button type="button" role="tab" data-k="${c.key}">${c.label}</button>`).join("");
  bar.onclick = e=>{ const b = e.target.closest("button[data-k]"); if(b){ show(b.dataset.k); b.scrollIntoView({inline:"center", block:"nearest", behavior:"smooth"}); } };
  show(cols[0].key);
}

/* ── حركات الظهور عند التمرير (الصفحة الرئيسية فقط) ── */
function initReveal(){
  const els = document.querySelectorAll(".reveal");
  if(!els.length) return;
  if(!("IntersectionObserver" in window)){ els.forEach(el=>el.classList.add("show")); return; }
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(en=>{ if(en.isIntersecting){ en.target.classList.add("show"); io.unobserve(en.target); } });
  }, {threshold:.14, rootMargin:"0px 0px -40px 0px"});
  els.forEach(el=>io.observe(el));
}

/* ── السلة (درج) ── */
function fillCartWilayas(){
  const sel = document.getElementById("cwilaya");
  if(!sel || sel.options.length > 1) return;
  // استبدال حقل البلدية بقائمة منسدلة (متوافقة مع الهاتف)
  let cSel = null;
  const cInp = document.getElementById("ccommune");
  if(cInp){
    cSel = document.createElement("select");
    cSel.id = "ccommune"; cSel.setAttribute("aria-label", "البلدية");
    cSel.innerHTML = '<option value="">— اختر البلدية —</option>';
    cInp.replaceWith(cSel);
    cSel.onchange = ()=>{ kidSwitch(sel, cSel); updateCartStop(); Cart.render(); };
  }
  // تعطيل خيار Stop Desk إذا لا يوجد مكتب في البلدية المختارة
  function updateCartStop(){
    const w = WILAYAS.find(x=>x.id==sel.value);
    const commune = cSel ? cSel.value : "";
    const allDesks = shipDesks(w, null);
    const hasDesk = (commune ? allDesks.filter(d=>d.commune===commune) : allDesks).length > 0;
    document.querySelectorAll('input[name="cdtype"]').forEach(r=>{
      if(r.value === "stop"){
        r.disabled = !hasDesk;
        const lbl = r.closest("label");
        if(lbl){
          lbl.style.opacity = hasDesk ? 1 : .45;
          lbl.title = hasDesk ? "" : "لا يوجد مكتب Stop Desk في هذه البلدية";
        }
        if(!hasDesk && r.checked){
          const home = document.querySelector('input[name="cdtype"][value="home"]');
          if(home) home.checked = true;
        }
      } else { r.disabled = false; const l = r.closest("label"); if(l){ l.style.opacity = 1; l.title = ""; } }
    });
    shipRadios("cdtype", w, commune);
  }
  WILAYAS.forEach(w=>{
    if(w.hide) return;
    const o = document.createElement("option");
    o.value = w.id; o.textContent = `${String(w.id).padStart(2,"0")} - ${w.name}` + (w.xw ? " (غير متوفر)" : ""); if(w.xw){ o.disabled = true; o.style.color = "#9aa3a0"; }
    sel.appendChild(o);
  });
  sel.onchange = ()=>{
    if(cSel){
      fillCommuneSel(cSel, WILAYAS.find(x=>x.id==sel.value));
    }
    updateCartStop();
    Cart.render();
  };
  document.querySelectorAll('input[name="cdtype"]').forEach(r=>r.onchange=()=>Cart.render());
}

function initCartDrawer(){
  const bg = document.getElementById("drawer-bg"), dr = document.getElementById("drawer");
  document.querySelectorAll(".cart-btn").forEach(b=>b.onclick=()=>{ dr.classList.add("open"); bg.classList.add("open"); Cart.render() });
  bg.onclick = ()=>{ dr.classList.remove("open"); bg.classList.remove("open") };
  // حقل كود الخصم — يُحقن قبل مربع إجمالي السلة (drawer موجود في كل صفحات الموقع)
  const totBox = document.querySelector("#drawer .tot");
  if(totBox) injectCouponBox("cart", totBox, ()=>Cart.subtotal(), Cart.render, couponCartItems);
}


/* ── صفحة السلة cart.html: تعرض السلة نفسها (#drawer بكل معرّفاتها ومنطق Cart) مضمَّنة في الصفحة بدل الدرج المنزلق — لا منطق سلة مكرَّر ── */
function initCartPage(){
  const box = document.getElementById("cart-page"), dr = document.getElementById("drawer"), bg = document.getElementById("drawer-bg"); if(!box || !dr) return;
  box.appendChild(dr); dr.classList.add("inline", "open"); if(bg){ bg.classList.remove("open"); bg.style.display = "none"; }
  const h = dr.querySelector("h3"); if(h) h.style.display = "none";
  Cart.render();
}

/* ── تتبّع الزيارات + «يشاهدون الآن» الحقيقي (يُقرأ في لوحة الإدارة) ──
   زيارة واحدة لكل جلسة وصفحة، ونبض كل 45 ثانية فقط والصفحة ظاهرة (وبحد أقصى 20 دقيقة) لتوفير حصة Apps Script.
   لا يعمل داخل معاينة لوحة الإدارة (iframe) ولا بدون API_URL. */
(function(){
  try{
    if(window.parent !== window || typeof CONFIG === "undefined" || typeof API === "undefined" || !API.hit || (!CONFIG.API_URL && !(API.sb && API.sb.enabled()) && !(API.php && API.php.on()))) return;
    const cs = currentProductSlugFromUrl();
    const page = cs ? cs : (/\/(index\.html)?$/.test(location.pathname) ? "home" : "other");
    const k = "store_hit_" + page;
    if(!sessionStorage.getItem(k)){ sessionStorage.setItem(k, "1"); API.hit(page); }
    let beats = 0;
    API.ping(page);
    const iv = setInterval(()=>{ if(document.hidden) return; if(++beats > 26){ clearInterval(iv); return; } API.ping(page); }, 45000);
  }catch(e){ /* التتبّع لا يجب أن يعطّل الموقع أبداً */ }
})();


/* ══════════════════════════════════════════════════════════════════════
   حسابي (تسجيل الزبون) + تثبيت الموقع على الهاتف (PWA)
   الخلفية حسب النسخة: Supabase | PHP | على الجهاز فقط (انظر API.cust في api.js). الطلب يُربط بالحساب تلقائياً عند الإرسال.
   ══════════════════════════════════════════════════════════════════════ */
const PWA = {
  ev: null,
  base(){ return typeof REL !== "undefined" ? REL : ""; },
  standalone(){ try{ return matchMedia("(display-mode: standalone)").matches || navigator.standalone === true; }catch(e){ return false; } },
  ios(){ return /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1); },
  inApp(){ return /FBAN|FBAV|Instagram|TikTok|musical_ly|Line\//i.test(navigator.userAgent); },   // متصفحات داخل التطبيقات لا تدعم التثبيت
  init(){
    if(window.parent !== window) return;                                  // ليس داخل معاينة الإدارة
    try{
      const h = document.head, add = (tag, attrs)=>{ const e = document.createElement(tag); Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v)); h.appendChild(e); };
      if(!document.querySelector('link[rel="manifest"]')) add("link", { rel:"manifest", href: this.base() + "manifest.webmanifest" });
      if(!document.querySelector('meta[name="theme-color"]')) add("meta", { name:"theme-color", content:"#173F35" });
      if(!document.querySelector('link[rel="apple-touch-icon"]')) add("link", { rel:"apple-touch-icon", href: this.base() + "assets/img/apple-touch-icon.png" });
      add("meta", { name:"apple-mobile-web-app-capable", content:"yes" });
      add("meta", { name:"apple-mobile-web-app-title", content: SITE_NAME.split(" ")[0] });
      if("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register(this.base() + "sw.js").catch(()=>{});
    }catch(e){}
    addEventListener("beforeinstallprompt", e=>{ e.preventDefault(); PWA.ev = e; });
    addEventListener("appinstalled", ()=>{ PWA.ev = null; try{ toast("✅ تم تثبيت الموقع على هاتفك"); }catch(e){} });
  },
  async install(){
    if(!this.ev) return "manual";
    this.ev.prompt();
    const c = await this.ev.userChoice.catch(()=>({ outcome:"dismissed" }));
    this.ev = null; return c.outcome;
  },
  /* خطوات التثبيت اليدوي بحسب الجهاز */
  steps(){
    if(this.inApp()) return "أنت تتصفّح من داخل تطبيق (فيسبوك/إنستغرام…): اضغط <b>⋮</b> أو <b>…</b> ثم <b>«فتح في المتصفح»</b>، وبعدها ثبّت الموقع.";
    if(this.ios()) return "في آيفون: افتح الموقع في <b>Safari</b>، اضغط زر المشاركة <b>⬆️</b> ثم <b>«إضافة إلى الشاشة الرئيسية»</b>.";
    return "اضغط <b>⋮</b> أعلى المتصفح ثم <b>«تثبيت التطبيق»</b> أو <b>«إضافة إلى الشاشة الرئيسية»</b>.";
  },
};

const Account = {
  tab: "reg",
  mode(){ return API.cust.mode(); },
  profile(){ return API.cust.profile(); },
  esc(s){ return String(s == null ? "" : s).replace(/[&<>"']/g, c=>({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c])); },
  ERR: {
    phone_taken: "هذا الرقم مسجّل من قبل — سجّل الدخول بدلاً من إنشاء حساب جديد.",
    invalid_credentials: "الهاتف أو كلمة السر غير صحيحة.",
    too_many_attempts: "محاولات كثيرة خاطئة — انتظر 10 دقائق ثم أعد المحاولة.",
    invalid_phone: "رقم الهاتف غير صالح (مثال: 0555123456).",
    invalid_name: "الاسم قصير جداً.",
    invalid_password: "كلمة السر يجب ألا تقل عن 6 أحرف.",
    rate_limited: "طلبات كثيرة — حاول لاحقاً.",
    network: "تعذّر الاتصال — تحقق من الإنترنت وأعد المحاولة.",
  },
  err(e){ const m = (e && e.message) || ""; return this.ERR[m] || "حدث خطأ غير متوقع — أعد المحاولة."; },
  STATUS: { nouvelle:["قيد المراجعة","#8a6d1d"], confirmee:["مؤكَّد","#1c6b8f"], expediee:["في الطريق إليك 🚚","#6a3fb0"], livree:["تم التسليم ✅","#157a55"], annulee:["ملغى","#999"], echec:["تعذّر التوصيل","#D64545"] },

  init(){
    if(window.parent !== window) return;
    const hd = document.querySelector("header.site .container"); if(!hd || hd.querySelector(".acc-btn")) return;
    if(!hd.hasAttribute("data-noacc")){      // الهيدر قد يُخفي زر الحساب (إعدادات الهيدر)
      const b = document.createElement("button");
      b.className = "acc-btn"; b.type = "button"; b.setAttribute("aria-label", "حسابي"); b.innerHTML = "👤";
      b.onclick = ()=>this.open();
      const cart = hd.querySelector(".cart-btn"); cart ? hd.insertBefore(b, cart) : hd.appendChild(b);
    }
    this.mark();
    const fl = document.querySelector("footer.site .fgrid > div:nth-child(2) p");      // روابط سريعة في ذيل الصفحة
    if(fl && !fl.querySelector(".ft-trk")) fl.insertAdjacentHTML("beforeend", '<br><a href="#" class="ft-trk">📦 تتبّع طلبك</a><br><a href="#" class="ft-acc">👤 حسابي</a>');
    else if(!fl){ const fc = document.querySelector("footer.site .container"); if(fc && !fc.querySelector(".ft-trk")) fc.insertAdjacentHTML("beforeend", '<div style="margin-top:.5rem;font-size:.85rem"><a href="#" class="ft-trk" style="color:#C7D3CD">📦 تتبّع طلبك</a> · <a href="#" class="ft-acc" style="color:#C7D3CD">👤 حسابي</a></div>'); }
    const ft = document.querySelector(".ft-trk"), fa = document.querySelector(".ft-acc");
    if(ft) ft.onclick = e=>{ e.preventDefault(); Track.open(); };
    if(fa) fa.onclick = e=>{ e.preventDefault(); this.open(); };
    [900, 2600].forEach(t=>setTimeout(()=>this.prefill(), t));
  },
  mark(){ const b = document.querySelector(".acc-btn"); if(b) b.classList.toggle("on", !!this.profile()); },

  /* تعبئة نموذج الطلب ببيانات الحساب (للحقول الفارغة فقط) */
  prefill(){
    const p = this.profile(); if(!p) return;
    const setv = (ids, v)=>{ if(!v) return; for(const id of ids){ const el = document.getElementById(id); if(el && !el.value){ el.value = v; el.dispatchEvent(new Event("input", { bubbles:true })); } } };
    setv(["name","cname"], p.name); setv(["phone","cphone"], p.phone);
    try{
      const w = p.wilaya && WILAYAS.find(x=>x.name === p.wilaya);
      if(w) ["wilaya","cwilaya"].forEach(id=>{ const el = document.getElementById(id); if(el && !el.value && el.options && el.options.length > 1){ el.value = w.id; el.onchange && el.onchange(); el.dispatchEvent(new Event("change", { bubbles:true })); } });
    }catch(e){}
    if(p.commune) ["commune","ccommune"].forEach(id=>{ const el = document.getElementById(id); if(el && !el.value){ if(el.tagName === "SELECT"){ if([...el.options].some(o=>o.value === p.commune)) el.value = p.commune; } else el.value = p.commune; } });
  },

  ensure(){
    let bg = document.getElementById("acc-bg"); if(bg) return bg;
    bg = document.createElement("div"); bg.id = "acc-bg"; bg.className = "acc-bg";
    bg.innerHTML = '<div class="acc-box" role="dialog" aria-modal="true" aria-label="حسابي"><button class="acc-x" type="button" aria-label="إغلاق">✕</button><div id="acc-body"></div></div>';
    document.body.appendChild(bg);
    bg.addEventListener("click", e=>{ if(e.target === bg) this.close(); });
    bg.querySelector(".acc-x").onclick = ()=>this.close();
    addEventListener("keydown", e=>{ if(e.key === "Escape") this.close(); });
    return bg;
  },
  open(){ this.ensure().classList.add("open"); document.documentElement.style.overflow = "hidden"; this.profile() ? this.home() : this.guest(); },
  close(){ const bg = document.getElementById("acc-bg"); if(bg) bg.classList.remove("open"); document.documentElement.style.overflow = ""; },
  body(html){ const b = document.getElementById("acc-body"); b.innerHTML = html; return b; },

  /* ── زائر: تسجيل جديد / دخول ── */
  guest(tab){
    if(tab) this.tab = tab;
    const local = this.mode() === "local", reg = local || this.tab === "reg";
    const wOpts = '<option value="">— الولاية (اختياري) —</option>' + (typeof WILAYAS !== "undefined" ? WILAYAS.filter(w=>!w.hide).map(w=>`<option value="${this.esc(w.name)}">${String(w.id).padStart(2,"0")} - ${this.esc(w.name)}</option>`).join("") : "");
    const b = this.body(`
      <h3>👤 حسابي</h3>
      <p class="acc-sub">${reg ? "أنشئ حسابك مرة واحدة: تتبّع طلباتك وأعد الطلب ببياناتك المحفوظة، وثبّت الموقع على هاتفك." : "سجّل الدخول لمتابعة طلباتك."}</p>
      ${local ? "" : `<div class="acc-tabs"><button type="button" data-t="reg" class="${reg ? "on" : ""}">تسجيل جديد</button><button type="button" data-t="login" class="${reg ? "" : "on"}">لدي حساب</button></div>`}
      <form id="acc-form" novalidate>
        ${reg ? '<label>الاسم الكامل<input name="name" autocomplete="name" required></label>' : ""}
        <label>رقم الهاتف<input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="05XXXXXXXX" required dir="ltr"></label>
        ${local ? "" : `<label>كلمة السر${reg ? " (6 أحرف على الأقل)" : ""}<input name="password" type="password" autocomplete="${reg ? "new-password" : "current-password"}" minlength="6" required dir="ltr"></label>`}
        ${reg ? `<div class="acc-row"><label>الولاية<select name="wilaya">${wOpts}</select></label><label>البلدية<input name="commune" autocomplete="address-level2"></label></div>` : ""}
        <div class="acc-msg" id="acc-msg"></div>
        <button class="btn btn-gold acc-go" type="submit">${reg ? "✨ إنشاء الحساب" : "دخول"}</button>
        <button class="acc-trk-link" type="button" id="acc-trk-link">📦 تتبّع طلب بدون حساب</button>
        ${local ? '<p class="acc-note">🔒 بياناتك محفوظة على هذا الجهاز فقط لتسريع طلباتك القادمة.</p>' : '<p class="acc-note">🔒 كلمة سرك مشفّرة ولا يراها أحد. نستعمل رقمك لتأكيد الطلبات وتتبّعها فقط.</p>'}
      </form>`);
    b.querySelectorAll(".acc-tabs button").forEach(x=>x.onclick = ()=>this.guest(x.dataset.t));
    b.querySelector("#acc-form").onsubmit = ev=>{ ev.preventDefault(); this.submit(reg, ev.target); };
    b.querySelector("#acc-trk-link").onclick = ()=>{ this.close(); Track.open(); };
  },
  async submit(reg, f){
    const v = Object.fromEntries(new FormData(f).entries()), msg = document.getElementById("acc-msg"), btn = f.querySelector(".acc-go");
    const phone = PhoneDZ.on ? PhoneDZ.norm(v.phone) : String(v.phone || "").replace(/[^\d+]/g, "");
    const fail = t=>{ msg.textContent = t; msg.className = "acc-msg bad"; };
    if(reg && String(v.name || "").trim().length < 2) return fail(this.ERR.invalid_name);
    if(phone.replace(/\D/g, "").length < 9) return fail(this.ERR.invalid_phone);
    if(PhoneDZ.on && !PhoneDZ.ok(PhoneDZ.norm(phone))) return fail(PhoneDZ.MSG);
    if(this.mode() !== "local" && String(v.password || "").length < 6) return fail(this.ERR.invalid_password);
    btn.disabled = true; msg.textContent = "⏳ لحظة…"; msg.className = "acc-msg";
    try{
      if(this.mode() === "local"){
        API.cust.save({ profile: { name: v.name.trim(), phone, wilaya: v.wilaya || "", commune: (v.commune || "").trim() } });
      }else{
        const r = await API.cust.call(reg ? "register" : "login", reg ? { name: v.name.trim(), phone, password: v.password, wilaya: v.wilaya || "", commune: (v.commune || "").trim() } : { phone, password: v.password });
        API.cust.save({ token: r.token, profile: r.profile });
      }
      this.mark(); this.prefill(); if(reg) await Gifts.claim("reg"); Track.linkPending(); this.done(reg);
    }catch(e){ fail(this.err(e)); btn.disabled = false; }
  },

  /* ── بعد النجاح: دعوة تثبيت الموقع على الهاتف ── */
  installBox(){
    if(PWA.standalone()) return "";
    return `<div class="acc-install"><div class="ai-t">📲 ثبّت الموقع على هاتفك</div><p>أيقونة على شاشتك الرئيسية: تفتح المتجر مباشرة، وتبقى مرتبطاً بحسابك وطلباتك.</p>
      <button class="btn btn-gold" type="button" id="acc-inst">تثبيت الآن</button><div class="ai-steps" id="acc-steps"></div></div>`;
  },
  bindInstall(root){
    const b = root.querySelector("#acc-inst"); if(!b) return;
    b.onclick = async ()=>{
      const o = await PWA.install();
      if(o === "accepted"){ b.closest(".acc-install").innerHTML = '<div class="ai-t">✅ جارٍ التثبيت…</div>'; }
      else if(o === "manual"){ const s = root.querySelector("#acc-steps"); s.innerHTML = PWA.steps(); s.style.display = "block"; }
    };
  },
  async done(isNew){
    const p = this.profile(), gifts = await Gifts.cardsHtml();
    const b = this.body(`<div class="acc-done"><div class="acc-ok">✅</div><h3>${isNew ? "أهلاً بك" : "مرحباً بعودتك"} ${this.esc((p.name || "").split(" ")[0])}!</h3>
      <p class="acc-sub">${isNew ? "تم إنشاء حسابك، وستُملأ بياناتك تلقائياً في طلباتك القادمة." : "تم تسجيل دخولك."}</p>
      ${gifts}${this.installBox()}<button class="btn btn-ghost acc-cont" type="button">متابعة إلى حسابي ←</button></div>`);
    this.bindInstall(b); Gifts.bind(b); b.querySelector(".acc-cont").onclick = ()=>this.home();
  },

  /* ── حسابي: الطلبات + البيانات ── */
  async home(){
    const p = this.profile(); if(!p) return this.guest();
    const local = this.mode() === "local";
    this.body('<h3>👤 حسابي</h3><p class="acc-sub">⏳ جارِ التحميل…</p>');
    let orders = [], offline = false;
    if(!local && API.cust.token()){
      try{ const r = await API.cust.call("me", { token: API.cust.token() }); orders = r.orders || []; API.cust.save({ token: API.cust.token(), profile: r.profile }); this.mark(); }
      catch(e){
        if(e.message === "unauthorized"){ API.cust.save(null); this.mark(); return this.guest("login"); }
        offline = true;
      }
    }
    const pr = this.profile() || p;
    const rows = orders.map(o=>{ const s = this.STATUS[o.status] || [o.status, "#666"];
      return `<div class="acc-ord"><div class="ao-h"><b dir="ltr">${this.esc(o.id)}</b><span style="color:${s[1]}">${s[0]}</span></div>
        <div class="ao-i">${this.esc(o.items).replace(/\n/g, "<br>")}</div>
        <div class="ao-f"><span>${new Date(o.date).toLocaleDateString("ar-DZ")}</span><b>${fmt(Number(o.total) || 0)}</b></div>
        ${o.tracking ? `<div class="ao-t">رقم التتبع: <b dir="ltr">${this.esc(o.tracking)}</b></div>` : ""}</div>`; }).join("");
    const wOpts = '<option value="">—</option>' + (typeof WILAYAS !== "undefined" ? WILAYAS.filter(w=>!w.hide).map(w=>`<option value="${this.esc(w.name)}"${w.name === pr.wilaya ? " selected" : ""}>${this.esc(w.name)}</option>`).join("") : "");
    const gifts = await Gifts.cardsHtml();
    const b = this.body(`
      <h3>👤 ${this.esc(pr.name)}</h3><p class="acc-sub" dir="ltr" style="text-align:right">${this.esc(pr.phone)}</p>
      ${gifts}${this.installBox()}
      <button class="btn btn-ghost acc-trk" type="button" style="width:100%;margin-bottom:.4rem">📦 تتبّع طلب برقم التتبع</button>
      ${local ? "" : `<h4>🧾 طلباتي</h4>${offline ? '<p class="acc-sub">تعذّر تحميل الطلبات الآن — تحقق من الإنترنت.</p>' : (rows || '<p class="acc-sub">لا توجد طلبات مربوطة بحسابك بعد. كل طلب تُرسله وأنت مسجّل يظهر هنا مع حالته.</p>')}
      <form id="acc-link" class="acc-link"><input name="oid" placeholder="رقم الطلب أو رقم التتبع (من رسالة واتساب)" dir="ltr"><button class="btn btn-ghost" type="submit">ربط</button></form><div class="acc-msg" id="acc-lmsg"></div>`}
      <details class="acc-prof"><summary>⚙️ بياناتي</summary>
        <form id="acc-edit" novalidate>
          <label>الاسم<input name="name" value="${this.esc(pr.name)}"></label>
          <div class="acc-row"><label>الولاية<select name="wilaya">${wOpts}</select></label><label>البلدية<input name="commune" value="${this.esc(pr.commune)}"></label></div>
          ${local ? "" : '<label>كلمة سر جديدة (اختياري)<input name="new_password" type="password" autocomplete="new-password" dir="ltr"></label><label>كلمة السر الحالية (لتغييرها)<input name="old_password" type="password" autocomplete="current-password" dir="ltr"></label>'}
          <div class="acc-msg" id="acc-emsg"></div><button class="btn btn-gold" type="submit">حفظ</button>
        </form></details>
      <button class="acc-out" type="button">تسجيل الخروج</button>`);
    this.bindInstall(b); Gifts.bind(b);
    b.querySelector(".acc-trk").onclick = ()=>{ this.close(); Track.open(); };
    b.querySelector("#acc-edit").onsubmit = async ev=>{
      ev.preventDefault(); const v = Object.fromEntries(new FormData(ev.target).entries()), m = b.querySelector("#acc-emsg");
      try{
        if(local) API.cust.save({ profile: Object.assign({}, pr, { name: v.name.trim(), wilaya: v.wilaya, commune: v.commune.trim() }) });
        else { const r = await API.cust.call("update", { token: API.cust.token(), name: v.name.trim(), wilaya: v.wilaya, commune: v.commune.trim(), new_password: v.new_password || "", old_password: v.old_password || "" }); API.cust.save({ token: API.cust.token(), profile: r.profile || r }); }
        m.textContent = "✅ تم الحفظ"; m.className = "acc-msg ok"; this.mark();
      }catch(e){ m.textContent = this.err(e); m.className = "acc-msg bad"; }
    };
    const lf = b.querySelector("#acc-link");
    if(lf) lf.onsubmit = async ev=>{
      ev.preventDefault(); const oid = lf.oid.value.trim(), m = b.querySelector("#acc-lmsg"); if(!oid) return;
      try{ const r = await API.cust.call("link_order", { token: API.cust.token(), order_id: oid }); const ok = r === true || (r && r.linked);
        if(ok) return this.home(); m.textContent = "لم نجد هذا الطلب برقم هاتف حسابك."; m.className = "acc-msg bad";
      }catch(e){ m.textContent = this.err(e); m.className = "acc-msg bad"; }
    };
    b.querySelector(".acc-out").onclick = async ()=>{
      const t = API.cust.token(); API.cust.save(null); this.mark();
      if(t) { try{ await API.cust.call("logout", { token: t }); }catch(e){} }
      this.guest("login");
    };
  },
};



/* ══════════════ هدايا الزبائن الجدد (ترحيب عند التسجيل + تثبيت التطبيق) ══════════════
   الإعدادات في assets/data/welcome.json (تُعدَّل من لوحة الإدارة ← أكواد الخصم). تعمل كأكواد خصم من نوع:
   percent | fixed | freeship (توصيل مجاني) | gift (منتج هدية). لا تُحتسب إلا لمن يملك حساباً، وتُستعمل مرة واحدة. */
const Gifts = {
  _cfg: null,
  async cfg(){
    if(this._cfg) return this._cfg;
    try{ const r = await fetch(PWA.base() + "assets/data/welcome.json", { cache:"no-store" }); this._cfg = r.ok ? await r.json() : { enabled:false }; }
    catch(e){ this._cfg = { enabled:false }; }
    return this._cfg;
  },
  KINDS: { reg:"register", install:"install" },
  all(){ try{ return JSON.parse(localStorage.getItem("store_gifts") || "{}") || {}; }catch(e){ return {}; } },
  mine(){ const p = API.cust.profile(); return p ? (this.all()[p.phone] || {}) : {}; },
  save(v){ const p = API.cust.profile(); if(!p) return; const a = this.all(); a[p.phone] = v; try{ localStorage.setItem("store_gifts", JSON.stringify(a)); }catch(e){} },
  conf(c, kind){ const g = c && c[this.KINDS[kind]]; return (c && c.enabled !== false && g && g.enabled !== false) ? g : null; },
  record(kind, g, st){
    const exp = new Date(st.ts + (Number(g.days) || 14) * 86400000).toISOString();
    const rec = { code: String(g.code || (kind === "reg" ? "WELCOME" : "APPGIFT")).toUpperCase(), type: g.type || "percent", value: Number(g.value) || 0, minOrder: Number(g.minOrder) || 0, expiresAt: exp, active: true, product: g.product || "", __gift: kind };
    if(rec.type === "gift"){ const pr = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug === g.product) : null; rec.giftTitle = pr ? pr.title : (g.product || "هدية"); }
    return rec;
  },
  status(kind, g){
    const st = this.mine()[kind];
    if(!st) return kind === "install" && !PWA.standalone() ? "locked" : "none";
    if(st.used) return "used";
    return Date.now() > st.ts + (Number(g.days) || 14) * 86400000 ? "expired" : "active";
  },
  /* خلفية Supabase/PHP: كل زبون يحصل من الخادم على كود شخصي (لهاتفه فقط، مرة واحدة)؛ وإلا يبقى الكود العام المحلي */
  serverMode(){ return API.cust.mode() !== "local" && !!API.cust.token(); },
  async serverGifts(){ try{ const r = await API.cust.call("my_gifts", { token: API.cust.token() }); return (r && r.gifts) ? r.gifts : (r && !r.ok && typeof r === "object" ? r : {}); }catch(e){ return {}; } },
  async claim(kind){
    if(this.serverMode()){
      try{ const r = await API.cust.call("claim_gift", { token: API.cust.token(), kind }); return !!(r && r.ok && !r.used); }catch(e){ return false; }
    }
    const c = await this.cfg(), g = this.conf(c, kind); if(!g || !API.cust.profile()) return false;
    const m = this.mine(); if(m[kind]) return false;
    m[kind] = { ts: Date.now() }; this.save(m); return true;
  },
  /* تستعملها نافذة الكوبون: هدايا المستخدم الفعّالة فقط كسجلات كوبون */
  async records(){
    const c = await this.cfg(), out = [], m = this.mine();
    for(const k of ["reg", "install"]){ const g = this.conf(c, k); if(g && m[k] && this.status(k, g) === "active") out.push(this.record(k, g, m[k])); }
    return out;
  },
  markUsed(rec){
    if(!rec || !rec.__gift) return;
    const m = this.mine(); if(m[rec.__gift]){ m[rec.__gift].used = Date.now(); this.save(m); }
  },
  text(g){
    const pr = (typeof PRODUCTS !== "undefined") ? PRODUCTS.find(x=>x.slug === g.product) : null;
    const what = g.type === "percent" ? "خصم " + (Number(g.value) || 0) + "% على طلبك" : g.type === "fixed" ? "خصم " + fmt(Number(g.value) || 0) + " على طلبك" : g.type === "freeship" ? "توصيل مجاني 🚚" : "منتج هدية: " + (pr ? pr.title : (g.product || ""));
    return what + (Number(g.minOrder) ? " (لطلبات من " + fmt(Number(g.minOrder)) + ")" : "");
  },
  async cardsHtml(){
    if(!API.cust.profile()) return "";
    if(this.serverMode()){
      const sg = await this.serverGifts(), esc = Account.esc.bind(Account), c = await this.cfg(); let h = "";
      for(const k of ["reg", "install"]){
        const g = sg[k], gc = this.conf(c, k);
        const title = esc((gc && gc.title) || (k === "reg" ? "🎁 هدية التسجيل" : "🎁 هدية تثبيت التطبيق"));
        let st, body;
        if(!g){ if(k === "install" && gc && !PWA.standalone()){ st = "locked"; body = "🔒 تُفعَّل هديتك عندما تفتح الموقع من <b>أيقونة التطبيق</b> على هاتفك بعد التثبيت."; } else continue; }
        else if(g.used){ st = "used"; body = "✔ استعملتَ هذه الهدية. شكراً لك!"; }
        else if(new Date(g.expiresAt) <= new Date()){ st = "expired"; body = "انتهت صلاحية هذه الهدية."; }
        else{ st = "active"; body = esc(this.text(g)) + '<br><span class="g-code">كودك الشخصي: <b dir="ltr">' + esc(g.code) + '</b></span> · صالح حتى ' + new Date(g.expiresAt).toLocaleDateString("ar-DZ") + ' · لك وحدك ويُستعمل مرة واحدة' +
          '<br><button class="btn btn-gold g-apply" type="button" data-code="' + esc(g.code) + '">تطبيق على طلبي</button>'; }
        h += '<div class="acc-gift ' + st + '"><div class="g-t">' + title + '</div><div class="g-b">' + body + '</div></div>';
      }
      return h;
    }
    const c = await this.cfg(), esc = Account.esc.bind(Account); let h = "";
    for(const k of ["reg", "install"]){
      const g = this.conf(c, k); if(!g) continue;
      const st = this.status(k, g); if(st === "none") continue;
      const title = esc(g.title || (k === "reg" ? "🎁 هدية التسجيل" : "🎁 هدية تثبيت التطبيق")), m = this.mine()[k];
      let body;
      if(st === "locked") body = "🔒 تُفعَّل هديتك عندما تفتح الموقع من <b>أيقونة التطبيق</b> على هاتفك بعد التثبيت.";
      else if(st === "used") body = "✔ استعملتَ هذه الهدية. شكراً لك!";
      else if(st === "expired") body = "انتهت صلاحية هذه الهدية.";
      else body = esc(this.text(g)) + '<br><span class="g-code">الكود: <b dir="ltr">' + esc(String(g.code || "").toUpperCase()) + '</b></span> · صالح حتى ' + new Date(m.ts + (Number(g.days) || 14) * 86400000).toLocaleDateString("ar-DZ") +
        '<br><button class="btn btn-gold g-apply" type="button" data-k="' + k + '">تطبيق على طلبي</button>';
      h += '<div class="acc-gift ' + st + '"><div class="g-t">' + title + '</div><div class="g-b">' + body + '</div></div>';
    }
    return h;
  },
  bind(root){
    root.querySelectorAll(".g-apply").forEach(b=>b.onclick = async ()=>{
      let code;
      if(b.dataset.code) code = b.dataset.code;
      else { const c = await this.cfg(), g = this.conf(c, b.dataset.k); if(!g) return; code = String(g.code || "").toUpperCase(); }
      const input = document.getElementById("prod-coupon-input") || document.getElementById("cart-coupon-input");
      if(!input){ toast("🎁 أضف منتجاً إلى السلة ثم أدخل الكود " + code); return; }
      input.value = code; input.closest(".coupon-box").querySelector("button").click();
      Account.close();
      if(input.id === "cart-coupon-input") (function(e){ if(e) e.click(); })(document.querySelector(".cart-btn"));
    });
  },
  /* أول فتح للتطبيق المثبّت (أو حدث التثبيت) ⟵ تُمنح هدية التثبيت */
  async checkInstall(){
    const go = async ()=>{
      if(!PWA.standalone()) return;
      const p = API.cust.profile(), c = await this.cfg(), g = this.conf(c, "install"); if(!g) return;
      if(!p){ if(!sessionStorage.getItem("store_gift_hint")){ sessionStorage.setItem("store_gift_hint", "1"); setTimeout(()=>toast("🎁 سجّل حسابك لتحصل على هدية تثبيت التطبيق"), 1500); } return; }
      if(await this.claim("install")) setTimeout(()=>toast("🎁 شكراً لتثبيتك التطبيق! هديتك في «حسابي»"), 1200);
    };
    go(); addEventListener("appinstalled", ()=>setTimeout(go, 800));
  },
};

/* ══════════════ تتبّع الطلب برقم التتبع (عام بلا تسجيل) ══════════════
   الرابط ?t=TRACKING يفتح النافذة مباشرة (يرسله لك مركز إشعارات واتساب). يتطلب Supabase أو نسخة PHP. */
const Track = {
  STEPS: [["confirmee", "تم تسجيل الطلب ✅"], ["expediee", "في الطريق إليك 🚚"], ["livree", "تم التسليم 🎉"]],
  cur: "",
  fromUrl(){
    try{ const t = new URLSearchParams(location.search).get("t"); if(t && /^[A-Za-z0-9._-]{4,40}$/.test(t)){ try{ localStorage.setItem("store_pending_track", t); }catch(e){} this.open(t); } }catch(e){}
  },
  ensure(){
    let bg = document.getElementById("trk-bg"); if(bg) return bg;
    bg = document.createElement("div"); bg.id = "trk-bg"; bg.className = "acc-bg";
    bg.innerHTML = '<div class="acc-box" role="dialog" aria-modal="true" aria-label="تتبّع الطلب"><button class="acc-x" type="button" aria-label="إغلاق">✕</button><div id="trk-body"></div></div>';
    document.body.appendChild(bg);
    bg.addEventListener("click", e=>{ if(e.target === bg) bg.classList.remove("open"); });
    bg.querySelector(".acc-x").onclick = ()=>bg.classList.remove("open");
    return bg;
  },
  open(t){
    const bg = this.ensure(); bg.classList.add("open");
    const b = document.getElementById("trk-body");
    b.innerHTML = '<h3>📦 تتبّع طلبك</h3><p class="acc-sub">أدخل رقم التتبع الذي وصلك على واتساب.</p>' +
      '<form id="trk-form" class="acc-link"><input name="t" placeholder="مثال: yal-123456" dir="ltr" value="' + Account.esc(t || "") + '" required><button class="btn btn-gold" type="submit">تتبّع</button></form><div id="trk-res"></div>';
    b.querySelector("#trk-form").onsubmit = ev=>{ ev.preventDefault(); this.lookup(ev.target.t.value.trim()); };
    if(t) this.lookup(t);
  },
  async lookup(t){
    const box = document.getElementById("trk-res"); this.cur = t;
    if(!/^[A-Za-z0-9._-]{4,40}$/.test(t)){ box.innerHTML = '<div class="acc-msg bad">رقم التتبع غير صالح.</div>'; return; }
    box.innerHTML = '<p class="acc-sub">⏳ جارِ البحث…</p>';
    let r = null;
    try{ r = await API.track(t); }catch(e){ box.innerHTML = '<div class="acc-msg bad">' + (e.message === "rate_limited" ? "محاولات كثيرة — انتظر دقيقة." : "تعذّر الاتصال — أعد المحاولة.") + '</div>'; return; }
    if(r === null){ box.innerHTML = '<div class="acc-msg bad">خدمة التتبع غير متاحة في هذا الموقع حالياً.</div>'; return; }
    if(!r.found){ box.innerHTML = '<div class="acc-msg bad">لم نجد طلباً بهذا الرقم. تأكد منه أو تواصل معنا على واتساب.</div>'; return; }
    const idx = this.STEPS.findIndex(x=>x[0] === r.status), bad = r.status === "annulee" || r.status === "echec";
    const steps = bad ? '<div class="trk-bad">' + (r.status === "annulee" ? "تم إلغاء هذا الطلب." : "تعذّر توصيل الطلب — سنتواصل معك.") + '</div>'
      : '<ol class="trk-steps">' + this.STEPS.map((x, i)=>'<li class="' + (i <= idx ? "done" : "") + (i === idx ? " now" : "") + '">' + x[1] + '</li>').join("") + '</ol>';
    box.innerHTML = steps + '<div class="trk-meta">رقم التتبع: <b dir="ltr">' + Account.esc(t) + '</b><br>الوجهة: ' + Account.esc((r.wilaya || "") + (r.commune ? " — " + r.commune : "")) +
      (r.dtype === "stop" ? " (مكتب)" : "") + '<br>التاريخ: ' + new Date(r.date).toLocaleDateString("ar-DZ") + '</div>' +
      (API.cust.profile() && API.cust.mode() !== "local" ? '<button class="btn btn-ghost trk-link" type="button" style="width:100%;margin-top:.6rem">🔗 أضف هذا الطلب إلى حسابي</button>'
        : '<button class="btn btn-gold trk-reg" type="button" style="width:100%;margin-top:.6rem">👤 سجّل حسابك لتتابع كل طلباتك</button>');
    const lk = box.querySelector(".trk-link"); if(lk) lk.onclick = async ()=>{ lk.disabled = true; const ok = await this.link(t); lk.textContent = ok ? "✅ أُضيف إلى حسابي" : "لم نستطع ربطه (يلزم تطابق هاتف الحساب مع هاتف الطلب)"; };
    const rg = box.querySelector(".trk-reg"); if(rg) rg.onclick = ()=>{ document.getElementById("trk-bg").classList.remove("open"); Account.open(); };
  },
  async link(t){
    try{ const r = await API.cust.call("link_order", { token: API.cust.token(), order_id: t }); localStorage.removeItem("store_pending_track"); return r === true || !!(r && r.linked); }catch(e){ return false; }
  },
  /* بعد تسجيل الدخول: ربط رقم التتبع القادم من الرابط تلقائياً */
  async linkPending(){
    let t = ""; try{ t = localStorage.getItem("store_pending_track") || ""; }catch(e){}
    if(t && API.cust.token()) await this.link(t);
  },
};

PWA.init();
(function(){ const go = ()=>{ try{ Account.init(); Gifts.checkInstall(); Track.fromUrl(); }catch(e){} }; document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", go) : go(); })();


/* ══════════════ حماية الطلبات (تُفعَّل من لوحة الإدارة ← نموذج الطلب) ══════════════
   antibot: حقل مخفي + رمز نموذج موقَّع من الخادم + تحقق من الهاتف والاسم + حدّ للطلبات من نفس الـ IP.
   dup: منع طلب المنتج نفسه مرتين من نفس الـ IP خلال ساعات محددة. الفحص الحقيقي على الخادم (Supabase/PHP)،
   وبلا خلفية يُكتفى بفحص على هذا الجهاز. لا يُخزَّن عنوان الـ IP نفسه بل بصمة مجزّأة. */

/* ── صفحة الشكر بعد إتمام الطلب: لوحة فوق الصفحة بملخص الطلب وخطوات ما بعده (تُفتح بعد إرسال الطلب وفتح واتساب) ── */
const Thanks = {
  esc: s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])),
  css(){
    if(document.getElementById("thx-css")) return;
    const st = document.createElement("style"); st.id = "thx-css";
    st.textContent = "#thx{position:fixed;inset:0;z-index:100001;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(2,8,5,.8);backdrop-filter:blur(7px);animation:thxIn .35s ease}@keyframes thxIn{from{opacity:0}to{opacity:1}}#thx .thx-box{width:min(480px,100%);max-height:92vh;overflow:auto;text-align:center;color:#ecfdf5;background:linear-gradient(145deg,rgba(12,54,29,.99),rgba(3,16,9,.99));border:1px solid rgba(134,239,172,.32);border-radius:26px;padding:28px 22px 22px;box-shadow:0 30px 80px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,255,255,.14);animation:thxUp .45s cubic-bezier(.2,.8,.2,1)}@keyframes thxUp{from{transform:translateY(24px) scale(.97);opacity:0}to{transform:none;opacity:1}}#thx .thx-ic{width:74px;height:74px;margin:0 auto 12px;border-radius:50%;display:grid;place-items:center;background:rgba(74,222,128,.18);border:1px solid rgba(134,239,172,.5);box-shadow:inset 0 1px 0 rgba(255,255,255,.25)}#thx .thx-ic svg{width:38px;height:38px;stroke:#bef264;fill:none;stroke-width:2.6;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:40;stroke-dashoffset:40;animation:thxCk .6s .25s ease forwards}@keyframes thxCk{to{stroke-dashoffset:0}}#thx h2{margin:.2rem 0 .3rem;font-size:1.5rem;color:#fff}#thx p{margin:.2rem 0;color:#c5dccd;font-size:.97rem;line-height:1.7}#thx .thx-sum{margin:14px 0;padding:12px 14px;text-align:start;background:rgba(255,255,255,.06);border:1px solid rgba(134,239,172,.22);border-radius:16px}#thx .thx-sum li{list-style:none;padding:3px 0;color:#ecfdf5;font-weight:700}#thx .thx-sum b{color:#bef264}#thx .thx-tot{display:flex;justify-content:space-between;margin-top:8px;padding-top:8px;border-top:1px dashed rgba(134,239,172,.3);font-weight:900}#thx .thx-st{display:grid;gap:6px;margin:10px 0 16px;text-align:start;font-size:.9rem;color:#c5dccd}#thx .thx-st span{display:flex;gap:8px;align-items:flex-start}#thx .thx-st i{flex:none;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-weight:900;font-size:.8rem;background:rgba(74,222,128,.2);border:1px solid rgba(134,239,172,.4);color:#d9f99d}#thx .thx-act{display:flex;gap:10px;flex-wrap:wrap}#thx .thx-act a,#thx .thx-act button{flex:1 1 140px;display:flex;align-items:center;justify-content:center;text-align:center;padding:13px 14px;border-radius:14px;font:inherit;font-weight:900;text-decoration:none;cursor:pointer;color:#fff;background:rgba(255,255,255,.07);border:1px solid rgba(134,239,172,.35);box-shadow:inset 0 1px 0 rgba(255,255,255,.18),inset 0 -6px 12px rgba(0,0,0,.2),0 6px 16px rgba(0,0,0,.25);backdrop-filter:blur(8px);transition:transform .2s,background .2s}#thx .thx-act a:hover,#thx .thx-act button:hover{transform:translateY(-2px);background:rgba(74,222,128,.22)}#thx .thx-act .pri{background:rgba(74,222,128,.24);border-color:#86efac}";
    document.head.appendChild(st);
  },
  show(o){
    try{
      this.css(); const old = document.getElementById("thx"); if(old) old.remove();
      const e = this.esc, el = document.createElement("div"); el.id = "thx"; el.setAttribute("role","dialog"); el.setAttribute("aria-label","شكراً لطلبك");
      const L = (o.lines || []).slice(0, 6).map(x=>"<li>• " + e(x) + "</li>").join(""), tot = (typeof fmt === "function" && o.total != null) ? fmt(o.total) : "";
      el.innerHTML = '<div class="thx-box"><div class="thx-ic"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div><h2>شكراً لك' + (o.name ? " " + e(String(o.name).split(" ")[0]) : "") + '، تم استلام طلبك</h2><p>طلبك مسجَّل لدينا، وسنتصل بك لتأكيده خلال ساعات قليلة.</p>' +
        (L ? '<ul class="thx-sum" style="margin-inline:0;padding-inline:14px">' + L + (tot ? '<div class="thx-tot"><span>الإجمالي (الدفع عند الاستلام)</span><b>' + e(tot) + '</b></div>' : "") + "</ul>" : "") +
        '<div class="thx-st"><span><i>1</i>سنؤكّد معك الطلب هاتفياً أو عبر واتساب.</span><span><i>2</i>نجهّز طلبك ونشحنه إلى ولايتك.</span><span><i>3</i>تعاين وتدفع عند الاستلام فقط.</span></div>' +
        '<div class="thx-act"><a class="pri" href="' + (typeof REL !== "undefined" ? REL : "") + 'index.html">متابعة التسوق</a>' + (o.wa ? '<a href="' + e(o.wa) + '" target="_blank" rel="noopener">إرسال الطلب على واتساب</a>' : "") + '<button type="button" id="thx-x">إغلاق</button></div></div>';
      document.body.appendChild(el);
      try{ if(document.documentElement.classList.contains("pb-embed") && window.frameElement){ const r = window.frameElement.getBoundingClientRect(), pv = window.parent.innerHeight, top = Math.max(0, -r.top), vis = Math.max(320, Math.min(r.height - top, pv - Math.max(r.top, 0))); el.style.cssText += ";position:absolute;inset:auto;left:0;right:0;top:" + top + "px;height:" + vis + "px;align-items:flex-start;overflow-y:auto;overscroll-behavior:contain"; } }catch(_){}      /* داخل إطار صفحة الهبوط: يتوسّط الجزء الظاهر من الشاشة لا الإطار الطويل كله */
      try{ if(o.up && window.Upsell) Upsell.mountPost(el, o.up); }catch(_){}      // Upsell بعد الشراء (assets/js/upsell.js)
      try{ if(document.documentElement.classList.contains("pb-embed")){ const topIt = ()=>el.querySelectorAll("a[href]:not([target])").forEach(a=>{ a.target = "_top"; }); topIt(); setTimeout(topIt, 800); setTimeout(topIt, 2500); } }catch(_){}      /* داخل إطار صفحة الهبوط: «متابعة التسوق» وروابط الاقتراحات تفتح في الصفحة الكاملة لا داخل الإطار */
      const close = ()=>{ el.remove(); document.removeEventListener("keydown", kd); }, kd = ev=>{ if(ev.key === "Escape") close(); };
      document.addEventListener("keydown", kd); el.querySelector("#thx-x").onclick = close; el.addEventListener("mousedown", ev=>{ if(ev.target === el) close(); });
      try{ if(navigator.vibrate) navigator.vibrate(30); }catch(_){}
    }catch(err){ console.warn("Thanks", err); }
  }
};
const Guard = {
  cfg: null, tok: "",
  /* دائماً فعّال: الخادم يفحص قائمة الحظر (من لوحة الإدارة) عند كل طلب؛ أي عطل شبكة لا يمنع الطلب */
  active(){ return true; },
  MSG: { duplicate_order:"لقد أرسلتَ طلباً لهذا المنتج مؤخراً ✅ سنتواصل معك قريباً. إن أردت تعديله راسلنا على واتساب.", bot:"تعذّر إرسال الطلب. أعد تحميل الصفحة وحاول مرة أخرى.", rate_limited:"طلبات كثيرة من نفس الجهاز — حاول لاحقاً أو راسلنا على واتساب.", invalid_phone:"رقم الهاتف أو الاسم غير صالح — تأكد منهما.", blocked:"تعذّر قبول هذا الطلب حالياً. للاستفسار راسلنا على واتساب." },
  async init(g){
    this.cfg = g || {}; if(!this.active()) return;
    if(this.cfg.antibot){
      document.querySelectorAll("#order-form, #drawer").forEach(host=>{
        if(host.querySelector(".hp-field")) return;
        const d = document.createElement("div"); d.className = "hp-field"; d.setAttribute("aria-hidden", "true");
        d.style.cssText = "position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden";
        d.innerHTML = '<label>Website<input type="text" name="website_url" tabindex="-1" autocomplete="off"></label>';
        host.appendChild(d);
      });
      this.refreshToken();
    }
  },
  async refreshToken(){ try{ this.tok = (await API.formToken()) || ""; }catch(e){ this.tok = ""; } },
  hp(){ const el = document.querySelector(".hp-field input"); return el ? el.value : ""; },
  recent(){ try{ return JSON.parse(localStorage.getItem("store_recent_orders") || "{}") || {}; }catch(e){ return {}; } },
  async submit(order){
    const slugs = (order.items || []).map(i=>i.slug).filter(Boolean), hrs = Math.max(1, Number(this.cfg.hours) || 24);
    if(this.cfg.dup){                                              // فحص محلي (يغطي من لا خلفية له)
      const r = this.recent(), now = Date.now();
      if(slugs.some(sl=>r[sl] && now - r[sl] < hrs * 3600000)) return { ok:false, msg: this.MSG.duplicate_order };
    }
    if(this.cfg.antibot && !this.tok) await this.refreshToken();
    const res = await API.submitOrderChecked(Object.assign({}, order, this.cfg.antibot ? { hp: this.hp(), ftok: this.tok } : {}));
    if(res && res.error && this.MSG[res.error]) { if(res.error === "bot") this.refreshToken(); return { ok:false, msg: this.MSG[res.error] }; }
    const r = this.recent(), now = Date.now(); slugs.forEach(sl=>{ r[sl] = now; }); try{ localStorage.setItem("store_recent_orders", JSON.stringify(r)); }catch(e){}
    if(this.cfg.antibot) this.refreshToken();
    return { ok:true };
  },
  openWa(url, pre){ if(pre){ try{ pre.location.href = url; return; }catch(e){} } open(url, "_blank"); },
};


/* ══════════════ رقم الهاتف الجزائري: 10 أرقام تبدأ بـ 05 أو 06 أو 07، أرقام فقط ══════════════
   يعمل افتراضياً (CONFIG.SITE.country = "DZ" افتراضياً) ويُعطَّل من لوحة الإدارة ← نموذج الطلب أو لبلد آخر. تُحوَّل +213/00213 تلقائياً إلى 0. */
const PhoneDZ = {
  on: ((typeof CONFIG !== "undefined" && CONFIG.SITE && CONFIG.SITE.country) || "DZ") === "DZ",
  MSG: "رقم الهاتف يجب أن يتكون من 10 أرقام ويبدأ بـ 05 أو 06 أو 07 (أرقام فقط، بلا حروف أو رموز)",
  norm(v){ let d = String(v || "").replace(/\D/g, ""); if(d.startsWith("00213")) d = "0" + d.slice(5); else if(d.startsWith("213") && d.length > 10) d = "0" + d.slice(3); return d.slice(0, 14); },      /* لا يُقصّ الرقم الزائد إلى 10 أرقام بصمت (كان 11 رقماً يصير رقماً آخر صالح الشكل): يبقى ظاهراً فيُرفض */
  ok(v){ return /^0[567]\d{8}$/.test(String(v || "")); },
  hint(el){
    let h = el.parentNode.querySelector(".phone-hint"); if(!h){ h = document.createElement("div"); h.className = "phone-hint"; h.style.cssText = "font-size:.78rem;min-height:1.1em;margin-top:.2rem;font-weight:700"; el.insertAdjacentElement("afterend", h); }
    return h;
  },
  check(el){
    const v = el.value, h = this.hint(el);
    if(!v){ h.textContent = ""; return; }
    if(v.length >= 2 && !/^0[567]/.test(v)){ h.textContent = "⚠️ يجب أن يبدأ الرقم بـ 05 أو 06 أو 07"; h.style.color = "var(--red)"; }
    else if(v.length > 10){ h.textContent = "⚠️ الرقم أطول من 10 أرقام (" + v.length + ") — تأكد منه"; h.style.color = "var(--red)"; }
    else if(v.length < 10){ h.textContent = v.length + " / 10 أرقام"; h.style.color = "var(--muted)"; }
    else if(this.ok(v)){ h.textContent = "✓ رقم صالح"; h.style.color = "var(--ok)"; }
  },
  bind(){
    ["phone", "cphone"].forEach(id=>{
      const el = document.getElementById(id); if(!el || el.dataset.dz) return; el.dataset.dz = "1";
      el.setAttribute("inputmode", "numeric"); el.setAttribute("autocomplete", "tel-national"); el.setAttribute("placeholder", el.getAttribute("placeholder") || "05XXXXXXXX");
      el.addEventListener("input", ()=>{ if(!this.on) return; const n = this.norm(el.value); if(el.value !== n) el.value = n; this.check(el); });
      el.addEventListener("blur", ()=>{ if(this.on && el.value && !this.ok(el.value)){ const h = this.hint(el); h.textContent = "⚠️ " + this.MSG; h.style.color = "var(--red)"; } });
    });
  },
  setup(cfg){ this.on = ((typeof CONFIG !== "undefined" && CONFIG.SITE && CONFIG.SITE.country) || "DZ") === "DZ" && !(cfg && cfg.phoneDz === false); this.bind(); },
};
(function(){ const go = ()=>{ try{ PhoneDZ.bind(); }catch(e){} }; document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", go) : go(); setTimeout(go, 1500); })();

/* رابط الدعوة ?register=1 (رسائل واتساب): يفتح نافذة إنشاء الحساب تلقائياً لمن لم يسجّل بعد */
(function(){ try{
  if(!/[?&]register=1/.test(location.search)) return;
  const go = ()=>{ try{ if(typeof Account !== "undefined" && !Account.profile()) Account.open(); }catch(e){} };
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", ()=>setTimeout(go, 1200)) : setTimeout(go, 1200);
}catch(e){} })();

/* وضع التضمين ?embed=1 (يستعمله منشئ الصفحات): يُظهر عروض المنتج ونموذج الطلب الأصلي فقط، ويبلغ الصفحة الأم بارتفاعه */
(function(){ try{
  if(!/[?&]embed=1/.test(location.search)) return;
  document.documentElement.classList.add("pb-embed");
  const st = document.createElement("style");
  const WW = "#pb-embed-wrap ", FF = WW+".order-wide,"+WW+"#order-form";
  st.textContent = "html.pb-embed,html.pb-embed body{overflow:hidden!important}html.pb-embed body>*:not(#pb-embed-wrap):not(#thx):not(script):not(style){display:none!important}html.pb-embed,html.pb-embed body{background:transparent!important;background-image:none!important;color-scheme:light}html.pb-embed body::before,html.pb-embed body::after{display:none!important;content:none!important;background:none!important}html.pb-embed body{padding:0!important;margin:0!important}#pb-embed-wrap{padding:6px;--o-bg:#ffffff;--o-tc:#1f2937;--o-bd:#e5e7eb;--o-ac:#16a34a;--o-bt:#ffffff;--o-fb:#f9fafb;--o-tb:#e5e7eb;--o-cb:#f9fafb;--o-wb:#25d366;--o-r:14px}#pb-embed-wrap .order-wide{margin-top:.6rem}#pb-embed-wrap #add-cart,#pb-embed-wrap .cart-btn{display:none!important}"
  /* الشكل الافتراضي: ألوان طبيعية فاتحة؛ كل لون متغيّر o-* يغيّره المستعمل من إعدادات العنصر */
  + FF+"{background:var(--o-bg)!important;background-image:none!important;color:var(--o-tc)!important;border:1px solid var(--o-bd)!important;border-radius:var(--o-r)!important;box-shadow:none!important}"
  + WW+"label,"+WW+"h3,"+WW+".field,"+WW+"#prod-coupon-msg,"+WW+".total-box small,"+WW+".total-box b,"+WW+".total-box #fee,"+WW+".dtype label,"+WW+".dtype span{color:var(--o-tc)!important}"
  + WW+".field input,"+WW+".field select,"+WW+".field textarea,"+WW+".coupon-box input{background:var(--o-fb)!important;color:var(--o-tc)!important;border:1px solid var(--o-bd)!important}"
  + WW+".offer,"+WW+".dtype,"+WW+".total-box,"+WW+".cod-note{background:var(--o-cb)!important;background-image:none!important;color:var(--o-tc)!important;border:1px solid var(--o-bd)!important;box-shadow:none!important}"
  + WW+".total-box{border-color:var(--o-tb)!important}"
  + WW+".offer *{color:inherit!important}"
  + WW+".offer.active,"+WW+".offer.on,"+WW+".offer.sel{border-color:var(--o-ac)!important;background:color-mix(in srgb,var(--o-ac) 10%,var(--o-cb))!important}"
  + WW+".dtype label{background:var(--o-bg)!important;border:1px solid var(--o-bd)!important}"
  + WW+".dtype label:has(input:checked){border-color:var(--o-ac)!important;background:color-mix(in srgb,var(--o-ac) 12%,var(--o-bg))!important}"
  + WW+".coupon-box button{background:var(--o-cb)!important;color:var(--o-tc)!important;border:1px solid var(--o-bd)!important}"
  + WW+".btn-order{background:var(--o-ac)!important;background-image:none!important;color:var(--o-bt)!important;border:0!important;box-shadow:none!important;border-radius:calc(var(--o-r) - 2px)!important}"
  + WW+".btn-wa{background:color-mix(in srgb,var(--o-wb) 9%,transparent)!important;background-image:none!important;color:color-mix(in srgb,var(--o-wb) 62%,#000)!important;border:1.5px solid var(--o-wb)!important;box-shadow:none!important;border-radius:calc(var(--o-r) - 2px)!important;min-height:38px!important;padding:.3rem .8rem!important;font-size:.85rem!important;font-weight:700!important;margin:.45rem auto 0!important;width:86%!important;opacity:.95}"
  + WW+".cod-note{color:var(--o-tc)!important;opacity:.85}"
  + WW+".btn-order *,"+WW+".btn-wa *{color:inherit!important}"
  + WW+".coupon-box button{background-image:none!important;box-shadow:none!important}"
  + WW+".field small,"+WW+".field .hint,"+WW+".gp-open{color:var(--o-tc)!important;opacity:.7}"
  + "#pb-embed-wrap #med-note{background:color-mix(in srgb,#f59e0b 14%,var(--o-cb))!important;color:var(--o-tc)!important;border:1px solid #f59e0b!important;box-shadow:none!important}#pb-embed-wrap #med-note *{color:inherit!important}";
  document.head.appendChild(st);
  /* إعدادات نموذج الطلب القادمة من عنصر «نموذج الطلب» في مطوّر الصفحات (متغيّر oc): ألوان وعنوان ونص الزر */
  let oc = null; try{ const m = location.search.match(/[?&]oc=([^&]+)/); if(m) oc = JSON.parse(decodeURIComponent(m[1])); }catch(e){}
  if(oc && typeof oc === "object"){
    if(oc.sc === "zones") __OCSC = "zones"; else if(oc.sc === "def") __OCSC = "";
    else if(oc.sc === "free"){ const nn = v=>(v === undefined || v === null || v === "" || isNaN(Number(v)) || Number(v) < 0) ? null : Math.round(Number(v)); __OCSC = "free"; __OCPF = { home:nn(oc.sh), stop:nn(oc.ss) }; }      /* سعر حر ثابت لهذه الصفحة فقط */
    else if(typeof oc.sc === "string" && /^[a-z0-9_]{2,24}$/i.test(oc.sc)) __OCSC = oc.sc;      /* مفتاح شركة توصيل (تعريفتها من ship-co.json) لهذه الصفحة فقط */
    if(oc.ol === "l" || oc.ol === "c" || oc.ol === "i") document.documentElement.classList.add("ol-"+oc.ol);      /* شكل العروض: قائمة / بطاقات (الافتراضي حسب عرض الإطار) */
    const ok = v=>/^(#[0-9a-f]{3,8}|rgba?\([0-9 .,%]+\)|[a-z]{3,20})$/i.test(String(v||"").trim()) ? String(v).trim() : "";
    const V = {bg:"bg",tc:"tc",bd:"bd",ac:"ac",bt:"bt",fb:"fb",tb:"tb",cb:"cb",wb:"wb"}, r = Number(oc.r);
    const W = "#pb-embed-wrap ";
    let c = "";
    const vars = Object.keys(V).map(k=>{ const v = ok(oc[k]); return v ? "--o-"+V[k]+":"+v+";" : ""; }).join("");
    { const z = Number(oc.z); if(isFinite(z) && oc.z !== "" && oc.z != null && z !== 100) c += "#pb-embed-wrap{zoom:"+(Math.max(70,Math.min(150,z))/100)+"}"; }
    if(isFinite(r) && oc.r !== "" && oc.r != null) c += "#pb-embed-wrap{--o-r:"+Math.max(0,Math.min(60,r))+"px}";
    { const bw = Number(oc.bw); if(isFinite(bw) && oc.bw !== "" && oc.bw != null) c += W+".order-wide,"+W+"#order-form{border-width:"+Math.max(0,Math.min(40,bw))+"px!important}"; }
    if(vars) c += "#pb-embed-wrap{"+vars+"}html.pb-embed{--gold:"+(ok(oc.ac)||"#16a34a")+"}";
    if(Array.isArray(oc.x)){ const M = {of:["#offers"], cm:[".field:has(#commune)"], gp:[".gp"], dt:[".dtype"], cp:[".coupon-box","#prod-coupon-msg"], wa:[".btn-wa"], nt:[".cod-note"], ou:["#offers .offer .u"], ob:["#offers .offer .best"], oq:["#offers .offer .q"]}; const hs = []; oc.x.forEach(k=>{ (M[k]||[]).forEach(q=>hs.push(W+q)); }); if(hs.length) c += hs.join(",")+"{display:none!important}"; }
    if(oc.w === "100") c += W+".frow{grid-template-columns:1fr!important}"; else if(oc.w === "50") c += "@media(min-width:561px){"+W+".frow{grid-template-columns:1fr 1fr!important}}";
    if(c){ const s2 = document.createElement("style"); s2.textContent = c; document.head.appendChild(s2); }
    const nz = t=>String(t).replace(/[^\p{L}\p{N}]/gu,""), same = (e,t)=>nz(e.textContent) === nz(t);
    const txt = ()=>{ try{
      if(oc.t){ const h = document.querySelector(W+"#order-form h3, "+W+".order-wide h3"); if(h && !same(h, oc.t)) h.textContent = String(oc.t); }
      { const bn = document.querySelector(W+".btn-order"); if(bn){ const sp = bn.querySelector("#btn-total"), noT = Array.isArray(oc.x) && oc.x.indexOf("bt") > -1, gl = (oc.L && oc.L.gt) ? String(oc.L.gt) : "الإجمالي"; if(noT){ if(sp){ const t = (oc.b ? String(oc.b) : bn.textContent.replace(/\s*—[\s\S]*$/, "")).trim(); bn.textContent = t; } } else if(sp && (oc.b || oc.L)){ const lead = (oc.b ? String(oc.b) : bn.textContent.replace(/\s*—[\s\S]*$/, "").trim()) + " — " + gl + ": "; if(bn.__oc !== lead || bn.firstChild === sp || (()=>{ let cur = ""; for(let n = bn.firstChild; n && n !== sp; n = n.nextSibling) cur += n.textContent; return nz(cur) !== nz(lead); })()){ while(bn.firstChild && bn.firstChild !== sp) bn.removeChild(bn.firstChild); bn.insertBefore(document.createTextNode(lead), sp); bn.__oc = lead; } } } }
      if(oc.L && typeof oc.L === "object"){
        const L = oc.L, lab = (id,t)=>{ const e = document.querySelector(W+'label[for="'+id+'"]'); if(e && t){ const nt = String(t) + (/\*\s*$/.test(e.textContent) ? " *" : ""); if(e.textContent !== nt) e.textContent = nt; } };
        lab("name", L.nm); lab("phone", L.ph); lab("wilaya", L.wl); lab("commune", L.cm);
        if(L.cp){ const i = document.getElementById("prod-coupon-input"); if(i && i.placeholder !== L.cp) i.placeholder = String(L.cp); }
        if(L.o1||L.o2||L.on||L.ofr||L.ou||L.ov||L.of||L.osp||L.obs){
          document.querySelectorAll(W+"#offers .offer").forEach(of=>{
            const q = of.querySelector(".q"), u = of.querySelector(".u"), bs = of.querySelector(".best");
            if(q){ if(q.__o === undefined) q.__o = q.textContent.trim(); const o = q.__o, m = /^(\d+) قطع$/.exec(o); const t = o==="قطعة واحدة"?L.o1 : o==="قطعتان"?L.o2 : m?(L.on&&String(L.on).replace("{n}",m[1])) : /الثالثة/.test(o)?L.ofr : ""; if(t && !same(q,t)) q.textContent = String(t); }
            if(u){ if(u.__o === undefined) u.__o = u.innerHTML; let h = u.__o; if(L.ou) h = h.replace("للقطعة", L.ou.replace(/[<>&]/g,"")); if(L.ov) h = h.replace("وفر", L.ov.replace(/[<>&]/g,"")); if(L.of) h = h.replace("مجاناً داخل العرض", L.of.replace(/[<>&]/g,"")); if(L.osp) h = h.replace("🚚 شحن مجاني", L.osp.replace(/[<>&]/g,"")); if(u.innerHTML !== h) u.innerHTML = h; }
            if(bs && L.obs && !same(bs,L.obs)) bs.textContent = String(L.obs);
          });
        }
        if(L.gp){ const e = document.querySelector(W+".gp-open"); if(e){ const t = String(L.gp); if(!same(e,t)) e.textContent = t; } }
        if(L.sw){ const e = document.querySelector(W+'#wilaya option[value=""]'); if(e && !same(e,L.sw)) e.textContent = String(L.sw); }
        if(L.sc){ const e = document.querySelector(W+'#commune option[value=""]'); if(e && !same(e,L.sc)) e.textContent = String(L.sc); }
        if(L.ap){ const e = document.querySelector(W+"#prod-coupon-btn"); if(e && !same(e,L.ap)) e.textContent = String(L.ap); }
        if(L.ac){ const e = document.getElementById("add-cart"); if(e && !same(e,L.ac)) e.textContent = String(L.ac); }
        if(L.wa){ const e = document.querySelector(W+".btn-wa"); if(e && !same(e,L.wa)) e.textContent = String(L.wa); }
        if(L.nt){ const e = document.querySelector(W+".cod-note"); if(e && !same(e,L.nt)) e.textContent = String(L.nt); }
        const sm = document.querySelectorAll(W+".total-box small"); if(L.fe && sm[0] && !same(sm[0],L.fe)) sm[0].textContent = String(L.fe); if(L.gt && sm[1] && !same(sm[1],L.gt)) sm[1].textContent = String(L.gt);
        const dl = document.querySelectorAll(W+".dtype label span"); if(L.dh && dl[0] && !same(dl[0],L.dh)) dl[0].textContent = String(L.dh); if(L.ds && dl[1] && !same(dl[1],L.ds)) dl[1].textContent = String(L.ds);
      }
    }catch(e){} };
    setInterval(txt, 700); setTimeout(txt, 200);
  }
  window.addEventListener("message", e=>{ if(e.origin!==location.origin || !e.data || typeof e.data.pbOffer!=="number") return; const b = document.querySelectorAll("#offers .offer")[e.data.pbOffer]; if(b) b.click(); });
  window.addEventListener("message", e=>{ if(e.origin!==location.origin || !e.data || typeof e.data.pbCoupon!=="string") return; const i = document.getElementById("prod-coupon-input"), b = i && i.closest(".coupon-box") && i.closest(".coupon-box").querySelector("button"); if(i && b){ i.value = e.data.pbCoupon.slice(0,40); b.click(); } });
  window.addEventListener("message", e=>{ if(e.origin!==location.origin || !e.data || !e.data.pbSubmit) return; const b = document.querySelector("#order-form .btn-order, .order-wide .btn-order") || document.querySelector(".btn-order"); if(b) b.click(); });
  document.addEventListener("click", e=>{ const o = e.target.closest && e.target.closest("#offers .offer"); if(!o) return; try{ parent.postMessage({ pbOfferSel: [...o.parentElement.children].indexOf(o) }, location.origin); }catch(_){} }, true);
  const go = ()=>{
    const form = document.querySelector(".order-wide") || document.querySelector(".pb-ofraw") || document.getElementById("order-form"); if(!form) return;
    const wrap = document.createElement("div"); wrap.id = "pb-embed-wrap";
    const off = document.getElementById("offers"); if(off) wrap.appendChild(off);
    wrap.appendChild(form); document.body.appendChild(wrap);
    const send = ()=>{ try{ parent.postMessage({ pbEmbedH: Math.ceil(wrap.getBoundingClientRect().height) + 12 }, location.origin); }catch(e){} };
    try{ new ResizeObserver(send).observe(wrap); }catch(e){}
    send(); setTimeout(send, 600); setTimeout(send, 2000);
    let lastT = null; const sendT = ()=>{ const b = document.querySelector("#order-form #btn-total, .order-wide #btn-total") || document.getElementById("btn-total"), t = b ? b.textContent.trim() : ""; if(t === lastT) return; lastT = t; try{ parent.postMessage({ pbTotal: t }, location.origin); }catch(e){} };
    setInterval(sendT, 500); sendT();
    /* لا يُكشف الإطار إلا بعد بناء النموذج وتطبيق ألوانه (كان يظهر النموذج الأسود القديم ثم الطويل ثم الجديد)؛ order-embed.html يُخفيه مبكراً ويكشفه هنا */
    try{ setTimeout(()=>{ try{ window.__pbReveal && window.__pbReveal(); }catch(e){} }, 320); }catch(e){}
  };
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", go) : go();
}catch(e){} })();

/* ════════ الهيدر/الفوتر وزر المشاركة — assets/js/chrome.js (+ social-icons.js)؛ تُدار من لوحة التحكم ← الهيدر / الفوتر ════════ */
(function(){
  if(window.parent !== window) return;       // لا شيء داخل الإطارات (معاينة اللوحة)
  const go = ()=>{
    try{
      const rel = typeof REL!=="undefined" ? REL : "";
      const ld = (f, cb)=>{ const s = document.createElement("script"); s.src = rel + "assets/js/" + f + "?v=11"; s.onload = cb; document.head.appendChild(s); };
      ld("social-icons.js", ()=>{ ld("chrome.js", ()=>{ try{ Chrome.init(); }catch(e){} }); ld("float-icons.js", ()=>{ try{ FloatIcons.init(rel); }catch(e){} }); });
    }catch(e){}
  };
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", ()=>setTimeout(go, 50)) : setTimeout(go, 50);
})();

/* ════════ أيقونات عصرية فقط: تُحوَّل الإيموجي والرموز القديمة في واجهة الموقع إلى SVG (assets/js/modern-icons.js)؛ محتوى الزبون (وصف المنتج وأقسام المطوّر) لا يُمسّ ════════ */
(function(){
  try{
    const rel = typeof REL!=="undefined" ? REL : "", s = document.createElement("script");
    s.src = rel + "assets/js/modern-icons.js?v=1"; s.async = true;
    s.onload = ()=>{ try{ ModernIcons.style(); const go = ()=>ModernIcons.watch({ skip: ".lp-desc,.pb-sec,.pb-w,[data-keep-emoji]" }); document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", go) : go(); }catch(e){} };
    document.head.appendChild(s);
  }catch(e){}
})();

/* بطاقات المنتجات (قالب اسم متجرك): الصورة الشفافة (المنتج وحده) تقف على مشهد القالب، أما الصورة المعتمة (منتج بخلفية/مشهد جاهز) فتُعرض كاملة بتكبير عند التمرير — يُوسَم الثاني بـ img-full ويقرأ القالب الصنف */
(function () {
  /* الفحص بكسل-بكسل مكلف على الهاتف: لا يُجرى إلا للصور الظاهرة وفي وقت الخمول، ونتيجته تُحفظ لكل صورة فلا تتكرر */
  const seen = new WeakSet(), KEY = "store_imgfull_v1"; let cache = {}, st = 0;
  try { cache = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { cache = {}; }
  const save = () => { clearTimeout(st); st = setTimeout(() => { try { const k = Object.keys(cache); if (k.length > 400) k.slice(0, k.length - 400).forEach(x => delete cache[x]); localStorage.setItem(KEY, JSON.stringify(cache)); } catch (e) { } }, 800); };
  const mark = img => { const h = img.closest(".pb-pci,.thumb"); if (h) h.classList.add("img-full"); };
  const idle = fn => (window.requestIdleCallback || (f => setTimeout(f, 90)))(fn, { timeout: 2500 });
  const queue = []; let busy = 0;
  const work = img => {
    const key = img.currentSrc || img.src;
    try {
      const N = 32, c = document.createElement("canvas"); c.width = c.height = N; const x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(img, 0, 0, N, N);
      const d = x.getImageData(0, 0, N, N).data; let op = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 40) op++;
      const full = op / (N * N) > .8; cache[key] = full ? 1 : 0; save(); if (full) mark(img);
    } catch (e) { }
  };
  const pump = () => { if (busy) return; busy = 1; const step = () => { const im = queue.shift(); if (im) work(im); if (queue.length) idle(step); else busy = 0; }; idle(step); };
  const io = "IntersectionObserver" in window ? new IntersectionObserver(es => { es.forEach(e => { if (e.isIntersecting) { io.unobserve(e.target); queue.push(e.target); } }); if (queue.length) pump(); }, { rootMargin: "300px" }) : null;
  function check(img) {
    if (seen.has(img)) return; seen.add(img);
    const go = () => {
      const key = img.currentSrc || img.src;
      if (key in cache) { if (cache[key]) mark(img); return; }
      if (io) io.observe(img); else { queue.push(img); pump(); }
    };
    if (img.complete && img.naturalWidth) go(); else img.addEventListener("load", go, { once: true });
  }
  const scan = () => document.querySelectorAll(".pb-pci img,.aly-grid .card .thumb img").forEach(check);
  let t = 0; const later = () => { clearTimeout(t); t = setTimeout(scan, 150); };
  const boot = () => { scan(); try { new MutationObserver(later).observe(document.body, { childList: true, subtree: true }); } catch (e) { } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
/* السكربتات غير الحرجة (دبوس الموقع، مرآة الطلب، العروض الإضافية، السلة المتروكة، جرّب عليك، المنتج الرقمي): في صفحات المنتج تُحمَّل فوراً كما كانت، وفي غيرها (الرئيسية والمتجر) بعد اكتمال التحميل وخمول المتصفح أو عند أول تفاعل — فتخفّ مهام الإقلاع الطويلة */
(function(){ try{ var s=document.createElement("script"); s.src=(typeof REL!=="undefined"?REL:"")+"assets/js/anti-copy.js?v=1"; s.async=true; document.head.appendChild(s); }catch(e){} })();
window.__lazyLoad = function(fn){
  var done = 0, run = function(){ if(done) return; done = 1; try{ fn(); }catch(e){} };
  if(document.getElementById("order-form") || document.querySelector(".order-wide,.pb-ofraw") || /[?&]embed=1/.test(location.search)) return run();
  var ev = ["pointerdown","keydown","touchstart","wheel"], off = function(){ ev.forEach(function(n){ removeEventListener(n, hit, true); }); }, hit = function(){ off(); run(); };
  ev.forEach(function(n){ addEventListener(n, hit, { capture:true, passive:true, once:true }); });
  var idle = function(){ (window.requestIdleCallback || function(f){ setTimeout(f, 300); })(function(){ off(); run(); }, { timeout: 3500 }); };
  document.readyState === "complete" ? idle() : addEventListener("load", function(){ setTimeout(idle, 1200); }, { once:true });
};
/* دبوس الموقع على الخريطة (اختياري) */
__lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/geo-pin.js?v=3'; s.async=true; document.head.appendChild(s); });
/* مرآة الطلب إلى المنصة (مراقبة الأسعار والمخزون) */
__lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/platform-order.js?v=1'; s.async=false; document.head.appendChild(s); });
document.addEventListener('upsell:ready',function(){ try{ Cart.render(); }catch(e){} });
__lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/upsell.js?v=2'; s.async=true; document.head.appendChild(s); });
/* التقاط السلة المتروكة (يعمل فقط إن ضُبط PLATFORM_CART_KEY في config.js) */
__lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/abandoned-cart.js?v=1'; s.async=true; document.head.appendChild(s); });
/* «جرّب عليك» لمنتجات الأزياء (يعمل فقط إن ضُبط PLATFORM_TRYON_KEY ومنتج فيه tryon:true) */
if(!/[?&]embed=1/.test(location.search)) __lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/tryon-shopper.js?v=1'; s.async=true; document.head.appendChild(s); });
__lazyLoad(function(){ var s=document.createElement('script'); s.src=(typeof REL!=='undefined'?REL:'')+'assets/js/digital-checkout.js?v=1'; s.async=false; document.head.appendChild(s); });
